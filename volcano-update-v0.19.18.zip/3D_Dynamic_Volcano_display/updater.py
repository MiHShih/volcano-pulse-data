#!/usr/bin/env python3
"""火山脈動展示端的自動更新：啟動腳本開伺服器之前先跑一次（v0.19.12 起）。

  python3 updater.py              有新版就下載、核對、備份、套用；沒網路或任何一步失敗就照舊版，不影響啟動
  python3 updater.py --check      只看有沒有新版，不下載
  python3 updater.py --rollback   退回上一次自動更新之前的版本；之後不再自動升到被退掉的版本（刪掉 .update/hold.json 就會再升）
  python3 updater.py --selftest   在暫存資料夾用假的更新包測一輪，不連網路、不動這台的檔案

新版資訊放在資料 repo 的 release 分支（tools/release.py 發佈）：latest.json 寫版本、更新包檔名、SHA-256、大小、
最低可直接升級的版本。更新包只套用 3D_Dynamic_Volcano_display/ 底下的檔案，不覆蓋 config.json（每台自己的設定）
與 data/ 裡的紀錄檔；三支啟動腳本也不自動換（Windows 執行中的 .bat 被改會出錯），要換時用手動更新包。
config.json 加上 "auto_update": false 就不自動更新；"update_url" 可以改新版資訊的網址。
紀錄寫在 .update/update.log，上一版的備份在 .update/backup/。只用 Python 內建模組，寫法要讓 Python 3.8 也能跑
（語法錯誤會讓展示機從此不再自動更新，又沒辦法遠端修）。

v0.19.18：套用前寫 .update/applying（要換與新增的檔案），全部換完才刪；開機看到它就先從備份還原（停電、強制關機）。
更新包解壓、版本核對都通過才清掉上一版的備份，清的時候一起刪掉 last.json（備份與 last.json 對不上時退回會刪錯檔案）。
退回時備份是空的就拒絕；退回後記在 .update/hold.json，之後只升到比它新的版本；退回時保留目前的 updater.py。
"""
import hashlib
import json
import os
import re
import shutil
import sys
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

HERE = Path(__file__).resolve().parent
PREFIX = '3D_Dynamic_Volcano_display/'  # 更新包裡程式資料夾的名稱（tools/pack.py 的 NAME）
DEFAULT_URL = 'https://raw.githubusercontent.com/MiHShih/volcano-pulse-data/release/latest.json'
KEEP = {'config.json', 'data/update.log', 'data/launchd.log'}  # 每台自己的檔案，不覆蓋；比對不分大小寫（Windows、Mac 的檔名不分大小寫）
SELF = 'updater.py'  # 退回時不換回舊版（舊版 updater 不認得 hold.json，下次開機又會升回去）
WORK = HERE / '.update'
UA = {'User-Agent': 'volcano-pulse-updater/1.0'}


def vtuple(v):
    return tuple(int(x) for x in re.findall(r'\d+', str(v))[:3])


def local_version(root=HERE):
    m = re.search(r"^const VERSION = '(.+)';", (root / 'app.js').read_text('utf-8'), re.M)
    return m.group(1) if m else '0'


def log(msg):
    line = f"{datetime.now(timezone.utc):%Y-%m-%d %H:%M:%S} UTC {msg}"
    print('自動更新：' + msg)
    try:
        WORK.mkdir(exist_ok=True)
        with open(WORK / 'update.log', 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except OSError:
        pass


def settings(root=HERE):
    try:
        c = json.loads((root / 'config.json').read_text('utf-8'))
        return c if isinstance(c, dict) else {}
    except (OSError, ValueError):
        return {}


def write_json(path, obj):
    """先寫暫存檔再換名字，寫到一半斷電也不會留下半個檔案"""
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False), 'utf-8')
    os.replace(str(tmp), str(path))


def get(url, limit, timeout=20):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f'檔案比預期大（超過 {limit:,} bytes）')
    return data


def check_latest(info):
    """latest.json 的格式檢查，不合格丟 ValueError。"""
    ok = (isinstance(info, dict) and isinstance(info.get('version'), str) and vtuple(info['version'])
          and isinstance(info.get('file'), str) and re.fullmatch(r'[A-Za-z0-9._-]+\.zip', info['file'])
          and isinstance(info.get('sha256'), str) and re.fullmatch(r'[0-9a-f]{64}', info['sha256'])
          and isinstance(info.get('size'), int) and 0 < info['size'] < 2_000_000_000)
    if not ok:
        raise ValueError('latest.json 格式不對')
    return info


def entries(z):
    """更新包裡要套用的檔案：(壓縮檔內名稱, 相對路徑)。路徑不安全就整包拒絕。"""
    keep = {k.lower() for k in KEEP}
    out = []
    for i in z.infolist():
        n = i.filename
        if not n.startswith(PREFIX) or n.endswith('/'):
            continue  # 啟動腳本在最上層，不自動換
        rel = n[len(PREFIX):]
        parts = rel.split('/')
        if not rel or '\\' in rel or rel.startswith('/') or ':' in parts[0] or any(p in ('', '.', '..') for p in parts):
            raise ValueError(f'更新包裡有不安全的路徑：{n}')
        if rel.lower() in keep or parts[0].lower() == '.update':
            continue
        out.append((n, rel))
    return out


def apply(zpath, new_version, root=HERE):
    """先解到暫存資料夾並核對版本，通過了才清掉上一版的備份；寫下套用中標記，備份會被覆蓋的檔案，再一個一個換上去。
    中途出錯就把已換的還原；整個程式中斷（斷電）的話，下次開機由 recover() 依標記還原。"""
    work = root / '.update'
    stage, backup = work / 'stage', work / 'backup'
    shutil.rmtree(stage, ignore_errors=True)
    old_version = local_version(root)
    with zipfile.ZipFile(zpath) as z:
        files = entries(z)
        if not any(rel == 'app.js' for _, rel in files):
            raise ValueError('更新包裡沒有 app.js')
        for n, rel in files:
            dst = stage / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            with z.open(n) as src, open(dst, 'wb') as f:
                shutil.copyfileobj(src, f)
    got = local_version(stage)
    if got != new_version:
        raise ValueError(f'更新包的版本是 {got}，不是 latest.json 寫的 {new_version}')
    # 到這裡才動上一版的備份：備份換掉了，舊的 last.json 就對不上，一起刪掉（之後只能退回到這次套用之前）
    shutil.rmtree(backup, ignore_errors=True)
    (work / 'last.json').unlink(missing_ok=True)
    rels = [rel for _, rel in files]
    added = [rel for rel in rels if not (root / rel).exists()]
    marker = work / 'applying'
    write_json(marker, {'from': old_version, 'to': new_version, 'files': rels, 'added': added})
    done = []
    try:
        for rel in rels:
            dst = root / rel
            if rel not in added:
                b = backup / rel
                b.parent.mkdir(parents=True, exist_ok=True)
                tmp = b.with_name(b.name + '.tmp')
                shutil.copy2(dst, tmp)
                os.replace(str(tmp), str(b))  # 備份完整了才出現，還原時不會拿到寫一半的備份
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(stage / rel), str(dst))
            done.append(rel)
    except Exception:
        restore(root, [r for r in done if r not in added], [r for r in done if r in added])
        marker.unlink(missing_ok=True)
        raise
    write_json(work / 'last.json', {'from': old_version, 'to': new_version, 'added': added,
                                    'time': datetime.now(timezone.utc).isoformat()})
    marker.unlink()
    (work / 'hold.json').unlink(missing_ok=True)
    shutil.rmtree(stage, ignore_errors=True)
    return old_version, len(files)


def restore(root, changed, added):
    backup = root / '.update' / 'backup'
    for rel in changed:
        if (backup / rel).exists():
            shutil.copy2(backup / rel, root / rel)
    for rel in added:
        (root / rel).unlink(missing_ok=True)


def recover(root=HERE):
    """上次套用到一半程式就中斷（停電、強制關機）：照 .update/applying 的清單從備份還原，回到套用前的版本。
    還原失敗就留著標記，回傳 False（這次不自動更新，下次開機再試）"""
    marker = root / '.update' / 'applying'
    if not marker.exists():
        return True
    try:
        a = json.loads(marker.read_text('utf-8'))
        added = a.get('added', [])
        restore(root, [r for r in a.get('files', []) if r not in added], added)
        (root / '.update' / 'last.json').unlink(missing_ok=True)
        marker.unlink()
        log(f"上次套用 v{a.get('to')} 時中斷，已從備份還原成 v{a.get('from')}")
        return True
    except Exception as e:
        log(f'上次套用時中斷，從備份還原失敗（{type(e).__name__}：{str(e)[:120]}）；這次不自動更新，請手動安裝更新包')
        return False


def held_version(root=HERE):
    try:
        v = json.loads((root / '.update' / 'hold.json').read_text('utf-8')).get('version')
        return v if isinstance(v, str) and vtuple(v) else None
    except (OSError, ValueError, AttributeError):
        return None


def rollback(root=HERE):
    p = root / '.update' / 'last.json'
    if not p.exists():
        log('沒有上一次自動更新的紀錄，不能退回')
        return 1
    last = json.loads(p.read_text('utf-8'))
    backup = root / '.update' / 'backup'
    changed = [str(b.relative_to(backup)).replace('\\', '/') for b in backup.rglob('*') if b.is_file()] if backup.exists() else []
    if not changed:
        log('上一版的備份是空的，不能退回；請手動安裝要用的版本的更新包')
        return 1
    # 保留目前的 updater.py：換回舊版的話，它不認得 hold.json，下次開機又會升回去
    restore(root, [r for r in changed if r.lower() != SELF], [r for r in last.get('added', []) if r.lower() != SELF])
    p.unlink()
    if last.get('to'):
        write_json(root / '.update' / 'hold.json', {'version': last['to'], 'time': datetime.now(timezone.utc).isoformat()})
    log(f"已退回 v{last.get('from')}（原本自動更新到 v{last.get('to')}）；之後只自動升到比 v{last.get('to')} 新的版本")
    return 0


def run(argv, root=HERE):
    if '--selftest' in argv:
        return selftest()
    if not recover(root):
        return 0
    if '--rollback' in argv:
        return rollback(root)
    conf = settings(root)
    if conf.get('auto_update') is False and '--check' not in argv:
        print('自動更新：config.json 設定為不自動更新，略過')
        return 0
    url = conf.get('update_url') or DEFAULT_URL
    have = local_version(root)
    try:
        info = check_latest(json.loads(get(url, 100_000)))
    except Exception as e:  # 沒網路、網址錯、格式不對：照舊版啟動
        log(f'查不到新版資訊，照目前的 v{have} 啟動（{type(e).__name__}：{str(e)[:120]}）')
        return 0
    new = info['version']
    if vtuple(new) <= vtuple(have):
        print(f'自動更新：已是最新版 v{have}')
        return 0
    held = held_version(root)
    if held and vtuple(new) <= vtuple(held):
        print(f'自動更新：v{new} 退回過，等比 v{held} 新的版本（目前 v{have}；刪掉 .update/hold.json 就會再升）')
        return 0
    if vtuple(have) < vtuple(info.get('min_version') or '0'):
        log(f"目前 v{have} 太舊，不能直接升級到 v{new}；請先手動安裝 v{info['min_version']} 的更新包")
        return 0
    if '--check' in argv:
        print(f'自動更新：有新版 v{new}（目前 v{have}）')
        return 0
    try:
        data = get(urljoin(url, info['file']), info['size'], timeout=60)
        if len(data) != info['size'] or hashlib.sha256(data).hexdigest() != info['sha256']:
            raise ValueError('下載的檔案跟 latest.json 寫的大小或 SHA-256 不符')
        (root / '.update').mkdir(exist_ok=True)
        zpath = root / '.update' / info['file']
        zpath.write_bytes(data)
        old, n = apply(zpath, new, root)
        zpath.unlink(missing_ok=True)
        log(f'已從 v{old} 更新到 v{new}（{n} 個檔案）；要退回請執行 python3 updater.py --rollback')
    except Exception as e:
        log(f'更新失敗，照目前的 v{have} 啟動（{type(e).__name__}：{str(e)[:160]}）')
    return 0


def selftest():
    """在暫存資料夾裝一台假的展示機，用 file:// 網址的假更新包跑過：正常套用、已是最新、退回與暫停升級、更新的版本照常升級、
    版本不符時保住上一版的備份、套用到一半中斷後開機還原、空備份拒絕退回、config.json 大小寫。不連網路、不動這台的檔案"""
    import io
    import tempfile
    global WORK
    ok_n, bad = 0, []

    def check(cond, name):
        nonlocal ok_n
        if cond:
            ok_n += 1
        else:
            bad.append(name)

    def read(p):
        return p.read_text('utf-8') if p.exists() else None

    with tempfile.TemporaryDirectory() as t:
        t = Path(t)
        root, rel = t / 'site', t / 'release'
        WORK = root / '.update'  # log() 寫到假展示機
        root.mkdir()
        rel.mkdir()
        (root / 'data').mkdir()
        files0 = {'app.js': "const VERSION = '0.1.0';\n", 'a.txt': 'a1', 'updater.py': '# updater v1', 'config.json': '{"update_url": "%s"}',
                  'data/update.log': 'log', 'data/x.json': 'x1'}
        for k, v in files0.items():
            (root / k).write_text(v if k != 'config.json' else v % (rel / 'latest.json').as_uri(), 'utf-8')
        conf0 = read(root / 'config.json')

        def publish(version, files, claim=None, name=None):
            buf = io.BytesIO()
            with zipfile.ZipFile(buf, 'w') as z:
                for k, v in files.items():
                    z.writestr(PREFIX + k, v)
                z.writestr('start-volcano.command', 'launcher')
            data = buf.getvalue()
            name = name or f'volcano-update-v{version}.zip'
            (rel / name).write_bytes(data)
            write_json(rel / 'latest.json', {'version': claim or version, 'file': name, 'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data)})

        quiet = io.StringIO()
        out0 = sys.stdout
        sys.stdout = quiet
        try:
            # 1 正常套用：換檔、新增、不碰 config.json（更新包寫成 Config.json 也一樣）與紀錄檔、不換啟動腳本
            publish('0.2.0', {'app.js': "const VERSION = '0.2.0';\n", 'a.txt': 'a2', 'b.txt': 'b2', 'updater.py': '# updater v2',
                              'Config.json': '{}', 'data/update.log': 'new log', 'data/x.json': 'x2'})
            run([], root)
            check(local_version(root) == '0.2.0' and read(root / 'a.txt') == 'a2' and read(root / 'b.txt') == 'b2'
                  and read(root / 'data/x.json') == 'x2', '套用：換檔與新增')
            check(read(root / 'config.json') == conf0 and read(root / 'data/update.log') == 'log'
                  and not (root / 'start-volcano.command').exists(), '套用：不覆蓋 config.json（不分大小寫）、紀錄檔、啟動腳本')
            check(not (root / '.update/applying').exists() and (root / '.update/last.json').exists()
                  and not (root / '.update/stage').exists(), '套用：完成後清掉套用中標記與暫存，留下 last.json')
            # 2 已是最新
            run([], root)
            check(local_version(root) == '0.2.0', '已是最新：不動')
            # 3 退回：換回舊檔、刪掉新增的檔案、保留新版 updater.py、記下暫停的版本；下次開機不再升回去
            check(rollback(root) == 0 and local_version(root) == '0.1.0' and read(root / 'a.txt') == 'a1'
                  and not (root / 'b.txt').exists() and read(root / 'updater.py') == '# updater v2', '退回：換回舊版、保留新版 updater.py')
            check(held_version(root) == '0.2.0' and not (root / '.update/last.json').exists(), '退回：記在 hold.json、刪掉 last.json')
            run([], root)
            check(local_version(root) == '0.1.0', '退回後：同一版不會再自動升回去')
            check(rollback(root) == 1 and local_version(root) == '0.1.0', '退回後再退回：沒有紀錄就拒絕')
            # 4 比暫停的版本新：照常升級，清掉 hold.json
            publish('0.3.0', {'app.js': "const VERSION = '0.3.0';\n", 'a.txt': 'a3'})
            run([], root)
            check(local_version(root) == '0.3.0' and read(root / 'a.txt') == 'a3' and held_version(root) is None, '更新的版本：照常升級')
            # 5 版本不符：不套用，上一版的備份與 last.json 都還在、還能退回
            publish('0.4.0', {'app.js': "const VERSION = '0.3.9';\n", 'a.txt': 'a4'})
            run([], root)
            check(local_version(root) == '0.3.0' and read(root / '.update/backup/a.txt') == 'a1' and (root / '.update/last.json').exists(),
                  '版本不符：不套用、保住上一版的備份')
            # 6 套用到一半中斷（模擬斷電：換到第二個檔案時整個程式停掉），下次開機先從備份還原
            publish('0.5.0', {'app.js': "const VERSION = '0.5.0';\n", 'a.txt': 'a5', 'c.txt': 'c5'})

            class Crash(BaseException):
                pass
            move0, calls = shutil.move, []

            def crash_move(src, dst):
                calls.append(dst)
                if len(calls) == 2:
                    raise Crash()
                return move0(src, dst)
            shutil.move = crash_move
            try:
                run([], root)
            except Crash:
                pass
            finally:
                shutil.move = move0
            check((root / '.update/applying').exists() and not (root / '.update/last.json').exists()
                  and local_version(root) == '0.5.0' and read(root / 'a.txt') == 'a3', '中斷：新舊檔案混在一起、留下套用中標記，last.json 已失效')
            check(rollback(root) == 1 and local_version(root) == '0.5.0', '中斷後：last.json 已失效，--rollback 拒絕、不刪檔案')
            check(recover(root) and local_version(root) == '0.3.0' and read(root / 'a.txt') == 'a3'
                  and not (root / 'c.txt').exists() and not (root / '.update/applying').exists(), '中斷後開機：先從備份還原成套用前的版本')
            run([], root)
            check(local_version(root) == '0.5.0' and read(root / 'c.txt') == 'c5', '還原後：這次開機重新套用成功')
            # 7 空備份：拒絕退回，不刪任何檔案
            write_json(root / '.update/last.json', {'from': '0.3.0', 'to': '0.5.0', 'added': ['c.txt']})
            shutil.rmtree(root / '.update/backup', ignore_errors=True)
            check(rollback(root) == 1 and read(root / 'c.txt') == 'c5' and local_version(root) == '0.5.0', '空備份：拒絕退回、不刪檔案')
        finally:
            sys.stdout = out0
            WORK = HERE / '.update'
    for n in bad:
        print(f'失敗：{n}')
    print(f'updater.py 自我檢查：{ok_n} 項通過、{len(bad)} 項失敗')
    return 1 if bad else 0


if __name__ == '__main__':
    sys.exit(run(sys.argv[1:]))
