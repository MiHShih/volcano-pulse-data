"""展示端的本機網頁伺服器：跟 python3 -m http.server 一樣，只多告訴瀏覽器網頁、程式與資料檔每次都要檢查有沒有新版。

原本的 http.server 沒有快取規則，Chrome 會自己估一段時間直接用快取（沒改過越久的檔案估得越久），
套用更新包後可能新的 app.js 配舊的 map-terrain.js。加上 Cache-Control: no-cache 後瀏覽器每次都問一次，
檔案沒變時伺服器只回 304，幾乎不花時間；地形圖磚與圖片照舊交給瀏覽器快取。
檔名用 http_server：操作手冊裡關伺服器的 pkill -f http.server 照樣比對得到。

執行：python3 http_server.py（預設 127.0.0.1:8000，可以加連接埠，例如 python3 http_server.py 8080）
視窗版的「離開」按鈕會送 POST /quit 關掉伺服器（v0.19.16）。
"""
import http.server
import sys
import threading
from functools import partial
from pathlib import Path

FRESH = ('/', '.html', '.js', '.mjs', '.css', '.json')


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        if self.path.split('?', 1)[0].endswith(FRESH):
            self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def do_POST(self):
        """視窗版的「離開」按鈕（v0.19.16）：關掉伺服器。只接受這個網頁送來的（看 Origin），別的網站送來的不理。"""
        port = self.server.server_address[1]
        if self.path != '/quit' or self.headers.get('Origin') not in (f'http://localhost:{port}', f'http://127.0.0.1:{port}'):
            return self.send_error(403)
        self.send_response(204)
        self.end_headers()
        threading.Thread(target=self.server.shutdown).start()  # 在別的執行緒呼叫，serve_forever 才停得下來


if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    root = Path(__file__).resolve().parent
    print(f'火山脈動：http://localhost:{port}/（{root}）', flush=True)
    http.server.ThreadingHTTPServer(('127.0.0.1', port), partial(Handler, directory=str(root))).serve_forever()
