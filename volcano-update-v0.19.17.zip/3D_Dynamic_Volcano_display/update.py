#!/usr/bin/env python3
"""全球火山 3D 地球：資料更新腳本（只用 Python 標準函式庫）。

用法：
  python3 update.py              A 段官方資料 + B 段 Claude 補充（讀 V1 火山活動日報輸出的火山補充檔）
  python3 update.py --no-claude  只跑 A 段
  python3 update.py --force-gvp  強制重抓 GVP 基本資料（平常 30 天抓一次）
  python3 update.py --selftest   自我檢查（不連網、不動 data/）

所有時間一律 UTC。任何來源失敗都保留上一份資料，錯誤寫進 data/update.log。
"""
import gzip
import html
import json
import logging
import math
import os
import re
import sys
import tempfile
import time
import unicodedata
import urllib.request
import xml.etree.ElementTree as ET
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'

GVP_WFS = ('https://webservices.volcano.si.edu/geoserver/GVP-VOTW/ows?service=WFS&version=2.0.0'
           '&request=GetFeature&typeName=GVP-VOTW:Smithsonian_VOTW_Holocene_Volcanoes'
           '&outputFormat=application/json')
# 官網優先；官網掛掉時改讀 Wayback 上的官網封存（內容仍是 GVP 官方文字）
GVP_CITATION_PAGES = ['https://volcano.si.edu/gvp_votw.cfm',
                      'https://web.archive.org/web/29991231000000id_/https://volcano.si.edu/gvp_votw.cfm']  # 最新一份封存
RSS_URL = 'https://volcano.si.edu/news/WeeklyVolcanoRSS.xml'
HANS_URL = 'https://volcanoes.usgs.gov/hans-public/api/volcano/getElevatedVolcanoes'

GVP_MAX_AGE_DAYS = 30
# 十年火山：IAVCEI 沒有每年更新的官方名單，所以每年比對一次維基百科條目表格第一欄，有差異只提醒、不自動改 decade.json
DECADE_WIKI = ('https://en.wikipedia.org/w/api.php?action=parse&page=Decade_Volcanoes&prop=wikitext'
               '&format=json&formatversion=2')
DECADE_PAGE = 'https://en.wikipedia.org/wiki/Decade_Volcanoes'
DECADE_CHECK_DAYS = 365
DECADE_BASELINE = ['Avachinsky + Koryaksky', 'Galeras', 'Mauna Loa', 'Mount Etna', 'Mount Merapi', 'Mount Nyiragongo',
                   'Mount Rainier', 'Mount Unzen', 'Mount Vesuvius', 'Sakurajima', 'Santa María (volcano)',
                   'Santorini caldera', 'Taal Volcano', 'Teide', 'Ulawun', 'Volcán de Colima']  # 2026-11-04 的表格
CLAUDE_DAYS = 7
# 航空火山灰警報：NOAA 航空氣象中心（AWC）彙整的各國火山灰 SIGMET（美國政府資料，公有領域），可以查過去 30 天任一時間有效的 SIGMET。
# 澳洲氣象局（BoM）的 9 個 VAAC 彙整頁條款禁止程式擷取，所以不用
AWC_SIGMET = 'https://aviationweather.gov/api/data/isigmet?format=json&hazard=va&date={}'
ASH_DAYS = 30  # AWC 只查得到 30 天內；展示端判斷噴發只看最近 7 天，30 天用在詳細卡的活動圖
# shortcut: 每 3 小時查一次「當時有效」的 SIGMET，效期不到 3 小時的可能漏掉（火山灰 SIGMET 多半 6 小時）；要更完整就改成每小時查
ASH_STEP = timedelta(hours=3)
ASH_PAUSE = 1  # 每次查詢間隔秒數（AWC 限制每分鐘 100 次）
PSN = re.compile(r'PSN\s+([NS])(\d{2})(\d{2})\s*([EW])(\d{3})(\d{2})')
# 各國官方警戒等級（HANS 以外）：日本氣象廳防災資訊網頁用的 JSON、PHIVOLCS 公報頁頁首、GeoNet API
JMA_WARN = 'https://www.jma.go.jp/bosai/volcano/data/warning.json'
JMA_LIST = 'https://www.jma.go.jp/bosai/volcano/const/volcano_list.json'
JMA_PAGE = 'https://www.jma.go.jp/bosai/map.html#contents=volcano'
PHIVOLCS_URL = 'https://wovodat.phivolcs.dost.gov.ph/bulletin/list-of-bulletin'
GEONET_URL = 'https://api.geonet.org.nz/volcano/val'
GEONET_PAGE = 'https://www.geonet.org.nz/volcano'
LEVEL_KM = 15  # 各機構的火山座標對到 GVP 火山的距離上限（Rotorua 離 Okataina 21 km，不能算同一座）
# 日本氣象廳警報名稱裡的關鍵字（噴火警戒等級 1 到 5 的名稱，以及沒有等級制度的火山用的名稱）；表裡沒有的照日文原文顯示
JMA_ZH = {'活火山であることに留意': '注意這是活火山', '火口周辺規制': '火口周邊管制', '入山規制': '禁止登山',
          '高齢者等避難': '高齡者等避難', '避難': '避難', '火口周辺危険': '火口周邊危險', '周辺海域警戒': '周邊海域警戒'}
PHIVOLCS_ZH = {0: '等級 0：正常', 1: '等級 1：輕微不穩定', 2: '等級 2：不穩定增加', 3: '等級 3：不穩定加劇（岩漿活動）',
               4: '等級 4：可能即將危險噴發', 5: '等級 5：危險噴發中'}
GEONET_ZH = {0: '等級 0：沒有不穩定', 1: '等級 1：輕微不穩定', 2: '等級 2：中度到明顯不穩定', 3: '等級 3：小規模噴發',
             4: '等級 4：中規模噴發', 5: '等級 5：大規模噴發'}
# 資料站設定：feed 是 V1 火山活動日報（claude-api-routines）輸出的火山補充檔
CONF = ROOT / 'publish.json'
FEED_MAX_AGE_HOURS = 36  # V1 每天 07:00 執行，超過這個時間代表它沒跑
YT_ID = re.compile(r'[A-Za-z0-9_-]{11}')  # YouTube 影片編號

log = logging.getLogger('update')


# ---------- 共用 ----------

def now():
    return datetime.now(timezone.utc)


def iso(dt):
    return dt.strftime('%Y-%m-%dT%H:%M:%SZ')


def fetch(url, timeout=120):
    req = urllib.request.Request(url, headers={'User-Agent': 'volcano-globe-updater/1.0 (personal research use)'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read()
    return gzip.decompress(raw) if raw[:2] == b'\x1f\x8b' else raw


def load(name, default):
    try:
        return json.loads((DATA / name).read_text('utf-8'))
    except FileNotFoundError:
        return default


def save(name, obj):
    """先寫暫存檔再改名，網頁不會讀到寫一半的檔案。"""
    p = DATA / name
    tmp = p.with_name(p.name + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1), 'utf-8')
    os.replace(tmp, p)


def text_of(html_fragment):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', html_fragment))).strip()


# ---------- 解析（純函式，自我檢查會直接測） ----------

def parse_gvp(raw):
    vols = []
    for f in json.loads(raw)['features']:
        p = f['properties']
        vols.append({
            'vnum': int(p['Volcano_Number']), 'name': p['Volcano_Name'], 'country': p['Country'],
            'type': p['Primary_Volcano_Type'], 'last_eruption': p['Last_Eruption_Year'],
            'evidence': p['Evidence_Category'], 'lat': p['Latitude'], 'lon': p['Longitude'],
            'elev': p.get('Elevation'),  # 山頂海拔（公尺），本日關注判斷灰雲比山頂高多少
        })
    if len(vols) < 1000:
        raise ValueError(f'GVP 只有 {len(vols)} 筆，疑似不完整')
    return vols


def parse_gvp_citation(page):
    """取官網「How to cite」的第一筆（目前版本）引用文字。"""
    m = re.search(r'(Global Volcanism Program, \d{4}\. \[Database\] Volcanoes of the World '
                  r'\(v\. ([\d.]+); ([^)]+)\)\. Distributed by [^<]+?)\s*<a href="https://doi\.org/([^"]+)"', page)
    if not m:
        raise ValueError('找不到 GVP 引用文字')
    return {'citation': m.group(1), 'version': m.group(2), 'version_date': m.group(3), 'doi': m.group(4)}


def parse_rss(raw):
    """回傳 (報告開始日, 結束日, 活動紀錄)。活動日期取標題的報告期間；pubDate 時間不可靠（12 小時制）。"""
    root = ET.fromstring(raw)  # 依 XML 宣告處理 ISO-8859-1
    recs, periods = [], set()
    for it in root.find('channel').findall('item'):
        title = (it.findtext('title') or '').strip()
        guid = (it.findtext('guid') or '').strip()
        vn = re.search(r'vn_(\d+)', guid)
        p = re.search(r'Report for (\d{1,2}) ([A-Za-z]+)(?: (\d{4}))?-(\d{1,2}) ([A-Za-z]+) (\d{4})', title)
        if not vn or not p:
            log.warning('RSS 項目無法解析，略過：%s', title)
            continue
        d1, m1, y1, d2, m2, y2 = p.groups()
        end = datetime.strptime(f'{d2} {m2} {y2}', '%d %B %Y').date()
        start = datetime.strptime(f'{d1} {m1} {y1 or y2}', '%d %B %Y').date()
        if start > end:  # 跨年週報且開始日沒寫年份
            start = start.replace(year=start.year - 1)
        periods.add((start, end))
        body = text_of(it.findtext('description') or '')
        src = re.search(r'\s*Sources?: (.+)$', body)
        vnum = int(vn.group(1))
        recs.append({
            'id': f'rss:{vnum}:{end}', 'vnum': vnum, 'source': 'rss', 'verified': True,
            'date': end.isoformat(), 'period_start': start.isoformat(),
            'title': title.rsplit(' - ', 1)[-1], 'summary': body[:src.start()] if src else body,
            'agency': src.group(1) if src else '', 'url': guid,
        })
    if not recs:
        raise ValueError('RSS 沒有可用的項目')
    start, end = max(periods, key=lambda x: x[1])
    return start.isoformat(), end.isoformat(), recs


def parse_hans(raw):
    rows = json.loads(raw)
    if not isinstance(rows, list):
        raise ValueError('HANS 回傳格式不是陣列')
    # 空陣列是有效結果：代表目前沒有警戒升高的火山
    return [{
        'vnum': int(r['vnum']), 'name': r['volcano_name'], 'color_code': r['color_code'],
        'alert_level': r['alert_level'], 'observatory': r['obs_fullname'],
        'notice_id': r['notice_identifier'],
        'sent_utc': iso(datetime.fromtimestamp(int(r['sent_unixtime']), timezone.utc)),
        'url': r['notice_url'],
    } for r in rows]


def hans_changes(prev, cur, when):
    """HANS 每天都發例行更新，只把「新升高、等級改變、解除」記進活動歷史。"""
    old = {a['vnum']: a for a in prev}
    recs = []
    for a in cur:
        o = old.get(a['vnum'])
        level = f"{a['color_code']}/{a['alert_level']}"
        if o and (o['color_code'], o['alert_level']) == (a['color_code'], a['alert_level']):
            continue
        title = f"警戒變更：{o['color_code']}/{o['alert_level']} → {level}" if o else f'警戒升高中：{level}'
        recs.append({
            'id': f"hans:{a['vnum']}:{a['notice_id']}", 'vnum': a['vnum'], 'source': 'hans', 'verified': True,
            'date': a['sent_utc'][:10], 'title': title, 'level': level,
            'prev': f"{o['color_code']}/{o['alert_level']}" if o else None,  # 本日關注判斷是不是調高
            'summary': f"{a['observatory']} 目前航空色碼 {a['color_code']}，警戒等級 {a['alert_level']}。",
            'agency': a['observatory'], 'url': a['url'],
        })
    curset = {a['vnum'] for a in cur}
    for v, o in old.items():
        if v not in curset:
            recs.append({
                'id': f"hans:{v}:off:{when}", 'vnum': v, 'source': 'hans', 'verified': True, 'date': when,
                'title': '已不在 HANS 升高清單',
                'summary': f"{o['observatory']} 的警戒已降回非升高狀態（實際等級請見觀測站公告）。",
                'agency': o['observatory'], 'url': 'https://volcanoes.usgs.gov/hans-public/',
            })
    return recs


def merge(activity, new):
    seen, added = {a['id'] for a in activity}, []
    for r in new:  # 新的一批裡同一個 id 也只留第一筆（媒體區跟其他區可能是同一座火山同一天）
        if r['id'] not in seen:
            seen.add(r['id'])
            added.append(r)
    return activity + added, len(added)


def official_vnums(activity, alerts, since):
    """since 之後有官方紀錄的火山，加上目前 HANS 警戒升高中的火山。"""
    s = since.isoformat()
    return {a['vnum'] for a in activity if a['verified'] and a['date'] >= s} | {a['vnum'] for a in alerts}


def validate_claude(items, gvp_vnums, covered, today):
    """回傳 (保留, 丟棄[(項目, 原因)])。缺來源 URL、缺日期、編號不在 GVP、官方已涵蓋，一律丟棄。"""
    kept, dropped = [], []
    lo = today - timedelta(days=CLAUDE_DAYS)
    for it in items:
        url = str(it.get('source_url') or '').strip()
        summary = str(it.get('summary') or '').strip()
        try:
            vnum = int(it.get('vnum'))
        except (TypeError, ValueError):
            vnum = None
        try:
            d = date.fromisoformat(str(it.get('date') or '')[:10])
        except ValueError:
            d = None
        reason = ('缺來源 URL' if not url.startswith(('http://', 'https://')) else
                  '缺日期或格式錯誤' if d is None else
                  f'日期不在最近 {CLAUDE_DAYS} 天' if not lo <= d <= today else
                  '火山編號不在 GVP 資料' if vnum not in gvp_vnums else
                  '官方來源已涵蓋，以官方為準' if vnum in covered else
                  '缺摘要' if not summary else None)
        if reason:
            dropped.append((it, reason))
            continue
        kept.append({
            'id': f'claude:{vnum}:{d}', 'vnum': vnum, 'source': 'claude', 'verified': False,
            'date': d.isoformat(), 'title': '未經官方確認', 'summary': summary,
            'agency': str(it.get('source_name') or '').strip(), 'url': url,
            'reported_name': str(it.get('volcano_name') or '').strip(),
            'eruption': it.get('eruption') is True,  # 沒回報或格式不對一律當作不是噴發
        })
    return kept, dropped


# ---------- A 段：官方資料 ----------

def record_error(meta, key, e):
    log.error('%s 失敗，保留上一份資料：%s', key, e)
    meta.setdefault(key, {}).update({'error': str(e), 'error_utc': iso(now())})


def update_gvp(meta, force):
    m = meta.get('gvp', {})
    age_ok = m.get('fetched_utc') and now() - datetime.fromisoformat(m['fetched_utc'].replace('Z', '+00:00')) < timedelta(days=GVP_MAX_AGE_DAYS)
    # v0.19.6 起多了山頂高度：舊的清單沒有這個欄位就重抓一次
    if age_ok and not force and (DATA / 'volcanoes.json').exists() and 'elev' in (load('volcanoes.json', [{}]) or [{}])[0]:
        return True
    try:
        vols = parse_gvp(fetch(GVP_WFS, timeout=300))
        save('volcanoes.json', vols)
        meta.setdefault('gvp', {}).update({'fetched_utc': iso(now()), 'count': len(vols), 'error': None})
        log.info('GVP：%d 座 Holocene 火山', len(vols))
    except Exception as e:
        record_error(meta, 'gvp', e)
        return False
    for url in GVP_CITATION_PAGES:
        try:
            cite = parse_gvp_citation(fetch(url, timeout=60).decode('utf-8', 'replace'))
        except Exception as e:
            log.warning('GVP 版本頁讀取失敗（%s）：%s', url, e)
            continue
        meta['gvp'].update(cite, citation_source=url, citation_checked_utc=iso(now()))
        log.info('GVP 版本：v%s（%s）DOI %s，取自 %s', cite['version'], cite['version_date'], cite['doi'], url)
        break
    return True


def parse_decade_wiki(raw):
    """維基百科 Decade Volcanoes 條目：取名單表格每一列第一格的連結名稱。"""
    t = json.loads(raw)['parse']['wikitext']
    i = t.find('{|')
    j = t.find('\n|}', i)
    if i < 0 or j < 0:
        raise ValueError('找不到名單表格')
    names = []
    for row in t[i:j].split('\n|-')[1:]:
        cells = [ln for ln in row.strip('\n').split('\n') if ln.startswith('|')]
        links = re.findall(r'\[\[([^\]|]+)', cells[0]) if cells else []
        if links:
            names.append(' + '.join(links))
    if len(names) < 10:
        raise ValueError(f'只讀到 {len(names)} 座，表格格式可能改了')
    return names


def check_decade(meta):
    """每年一次：跟上次（第一次是 DECADE_BASELINE）比對，結果寫進 meta.decade_check，網頁「來源」分頁會顯示。"""
    m = meta.get('decade_check', {})
    last = m.get('checked_utc')
    if last and now() - datetime.fromisoformat(last.replace('Z', '+00:00')) < timedelta(days=DECADE_CHECK_DAYS):
        return
    try:
        names = parse_decade_wiki(fetch(DECADE_WIKI, timeout=60))
    except Exception as e:
        record_error(meta, 'decade_check', e)  # 沒有更新 checked_utc，下次執行會再試
        return
    prev = m.get('names') or DECADE_BASELINE
    added, removed = sorted(set(names) - set(prev)), sorted(set(prev) - set(names))
    meta['decade_check'] = {'checked_utc': iso(now()), 'source': DECADE_PAGE, 'count': len(names), 'names': names,
                            'status': 'diff' if added or removed else 'same', 'added': added, 'removed': removed,
                            'error': None}
    if added or removed:
        log.warning('十年火山：維基百科名單 %d 座，跟上次不同：新增 %s、移除 %s。請確認後再決定要不要修改 decade.json',
                    len(names), added or '無', removed or '無')
    else:
        log.info('十年火山：維基百科名單 %d 座，跟上次相同', len(names))


def update_rss(meta):
    try:
        start, end, recs = parse_rss(fetch(RSS_URL))
    except Exception as e:
        record_error(meta, 'rss', e)
        return None
    meta['rss'] = {'fetched_utc': iso(now()), 'report_start': start, 'report_end': end,
                   'count': len(recs), 'error': None}
    log.info('RSS：週報 %s～%s，%d 筆', start, end, len(recs))
    return recs


def update_hans(meta):
    """回傳 (目前警戒, 活動紀錄)；失敗回傳 None。"""
    try:
        cur = parse_hans(fetch(HANS_URL))
    except Exception as e:
        record_error(meta, 'hans', e)
        return None
    recs = hans_changes(load('alerts.json', []), cur, now().date().isoformat())
    save('alerts.json', cur)
    meta['hans'] = {'fetched_utc': iso(now()), 'count': len(cur), 'error': None,
                    'latest_sent_utc': max((a['sent_utc'] for a in cur), default=None)}
    log.info('HANS：%d 座警戒升高，%d 筆變動', len(cur), len(recs))
    return recs


# ---------- 航空火山灰警報、各國官方警戒等級 ----------

def nearest_vnum(vols, lat, lon, km):
    """座標 km 公里內最近的 GVP 火山編號，沒有就回傳 None。經度差先換到 ±180° 內，換日線兩側也對得到。"""
    best, bd = None, km
    for v in vols:
        dl = (v['lon'] - lon + 540) % 360 - 180
        d = 111.2 * math.hypot(v['lat'] - lat, dl * math.cos(math.radians(lat)))
        if d <= bd:
            best, bd = v['vnum'], d
    return best


def parse_sigmets(raw, vols):
    """AWC 的國際 SIGMET（JSON）→ 火山灰紀錄。取消（CNL）、演習（EXER）、測試不收；用 SIGMET 裡的火山位置（PSN）對到 30 km 內的 GVP 火山。
    沒有結果時 AWC 回 HTTP 204、內容是空的，當作沒有警報。"""
    rows = json.loads(raw) if raw.strip() else []
    if not isinstance(rows, list):
        raise ValueError('AWC 回傳格式不是陣列')
    out = []
    for s in rows:
        text = str(s.get('rawSigmet') or '')
        if s.get('hazard') != 'VA' or re.search(r'\b(?:CNL|EXER|TEST)\b', text):
            continue
        m = PSN.search(text)
        vn = m and nearest_vnum(vols, (int(m[2]) + int(m[3]) / 60) * (1 if m[1] == 'N' else -1),
                                (int(m[5]) + int(m[6]) / 60) * (1 if m[4] == 'E' else -1), 30)
        if not vn:
            log.warning('火山灰 SIGMET 對不到 GVP 火山，略過：%s', text[:120])
            continue
        t0, t1 = int(s['validTimeFrom']), int(s['validTimeTo'])
        spd = str(s.get('spd') or '').strip()
        out.append({'id': f"{s.get('firId')}:{t0}:{vn}", 'vnum': vn,  # 同一份 SIGMET 常有兩筆（序號加 F），用 FIR、生效時間與火山去重
                    'from': iso(datetime.fromtimestamp(t0, timezone.utc)), 'to': iso(datetime.fromtimestamp(t1, timezone.utc)),
                    'top_ft': s['top'] if isinstance(s.get('top'), int) and s['top'] > 0 else None,
                    'dir': str(s.get('dir') or '').strip(), 'spd_kt': int(spd) if spd.isdigit() else None,
                    'fir': str(s.get('firName') or s.get('firId') or '')})
    return out


def update_ash(meta, vols):
    """每 3 小時查一次當時有效的火山灰 SIGMET，補到上次查詢之後（第一次或保留天數改變時補滿 ASH_DAYS 天），
    存成 ash.json（最近 ASH_DAYS 天）。全部查詢失敗就保留上一份。"""
    prev = load('ash.json', [])
    t_now = now()
    lo = t_now - timedelta(days=ASH_DAYS)
    last = meta.get('ash', {}).get('fetched_utc')
    full = not (last and prev) or meta.get('ash', {}).get('days') != ASH_DAYS
    t = lo + timedelta(hours=4) if full else max(lo, datetime.fromisoformat(last.replace('Z', '+00:00')) - timedelta(hours=6))  # 剛好 30 天前 AWC 會拒絕
    times = []
    while t < t_now:
        times.append(t)
        t += ASH_STEP
    times.append(t_now)
    got, err, fails = {}, None, 0
    for i, t in enumerate(times):
        if i:
            time.sleep(ASH_PAUSE)
        try:
            got.update((r['id'], r) for r in parse_sigmets(fetch(AWC_SIGMET.format(iso(t)), timeout=60), vols))
        except Exception as e:
            err, fails = e, fails + 1
    if fails == len(times):
        record_error(meta, 'ash', err)
        return
    keep = {r['id']: r for r in prev if r['to'] >= iso(lo)}
    keep.update(got)
    rows = sorted(keep.values(), key=lambda r: (r['from'], r['id']), reverse=True)
    if rows != prev:
        save('ash.json', rows)
    meta['ash'] = {'fetched_utc': iso(t_now), 'days': ASH_DAYS, 'count': len(rows), 'volcanoes': len({r['vnum'] for r in rows}),
                   'error': f'{len(times)} 次查詢有 {fails} 次失敗：{err}' if fails else None}
    log.info('火山灰警報：最近 %d 天 %d 筆、%d 座火山（查詢 %d 次%s）', ASH_DAYS, len(rows), meta['ash']['volcanoes'], len(times),
             f'，失敗 {fails} 次：{err}' if fails else '')


def level_row(vnum, agency, local, level, label, orig, elevated, when, url):
    return {'vnum': vnum, 'agency': agency, 'local': local, 'level': level, 'label': label, 'orig': orig,
            'elevated': elevated, 'time': when, 'url': url}


def keep_worst(rows):
    """同一座 GVP 火山對到好幾筆（例如 Ngauruhoe 與 Tongariro）時，留警戒最高的一筆。"""
    out = {}
    for r in rows:
        o = out.get(r['vnum'])
        if not o or (r['elevated'], r['level'] or 0) > (o['elevated'], o['level'] or 0):
            out[r['vnum']] = r
    return list(out.values())


def parse_jma(warn_raw, list_raw, vols):
    """日本氣象廳：warning.json 是發布中與最近變更的噴火警報、預報（沒列出的火山是等級 1 或沒有警報），volcano_list.json 有各火山座標。"""
    pos = {str(x['code']): (float(x['latlon'][0]), float(x['latlon'][1])) for x in json.loads(list_raw) if x.get('latlon')}
    if len(pos) < 100:
        raise ValueError(f'JMA 火山清單只有 {len(pos)} 座，疑似不完整')
    rows = []
    for rep in json.loads(warn_raw):
        when = iso(datetime.fromisoformat(rep['reportDatetime']).astimezone(timezone.utc))
        for vi in rep.get('volcanoInfos', []):
            if vi.get('type') != '噴火警報・予報（対象火山）':
                continue
            for it in vi.get('items', []):
                name = unicodedata.normalize('NFKC', str(it.get('name') or ''))  # 全形轉半形：レベル３（入山規制） → レベル3(入山規制)
                lv = re.match(r'レベル(\d)\((.+?)\)', name)
                key = lv.group(2) if lv else name
                label = (f'等級 {lv.group(1)}：' if lv else '') + JMA_ZH.get(key, key)
                for a in it.get('areas', []):
                    p = pos.get(str(a.get('code')))
                    vn = p and nearest_vnum(vols, p[0], p[1], LEVEL_KM)
                    if not vn:
                        log.warning('JMA 火山對不到 GVP 編號，略過：%s', a.get('name'))
                        continue
                    rows.append(level_row(vn, 'JMA', a.get('name', ''), int(lv.group(1)) if lv else None, label, it.get('name', ''),
                                          '活火山であることに留意' not in name, when, JMA_PAGE))
    return keep_worst(rows)


def parse_phivolcs(page, vols):
    """PHIVOLCS 公報列表頁的頁首「Alert Level Status: Taal - 1 Kanlaon - 2 ...」。"""
    m = re.search(r'Alert Level Status:(.{0,300})', text_of(page))
    pairs = re.findall(r'([A-Z][A-Za-z-]+) - (\d)', m.group(1)) if m else []
    if not pairs:
        raise ValueError('找不到 PHIVOLCS 的警戒等級')
    d = re.search(r'Summary of 24Hr Observation (\d{1,2} [A-Za-z]+ \d{4})', text_of(page))
    when = iso(datetime.strptime(d.group(1), '%d %B %Y').replace(tzinfo=timezone.utc)) if d else None
    names = {v['name'].lower(): v['vnum'] for v in vols if v['country'] == 'Philippines'}
    rows = []
    for name, lv in pairs:
        vn = names.get(name.lower())
        if not vn:
            log.warning('PHIVOLCS 火山對不到 GVP 編號，略過：%s', name)
            continue
        lv = int(lv)
        rows.append(level_row(vn, 'PHIVOLCS', name, lv, PHIVOLCS_ZH.get(lv, f'等級 {lv}'), f'Alert Level {lv}', lv >= 1, when,
                              PHIVOLCS_URL))
    return keep_worst(rows)


def parse_geonet(raw, vols):
    """GeoNet 的 Volcanic Alert Level（0 到 5）與航空色碼。"""
    rows = []
    for f in json.loads(raw)['features']:
        p, (lon, lat) = f['properties'], f['geometry']['coordinates'][:2]
        vn = nearest_vnum(vols, lat, lon, LEVEL_KM)
        if not vn:
            continue  # 例如 Northland、Rotorua 不在 GVP 全新世火山名單
        lv = int(p['level'])
        rows.append(level_row(vn, 'GeoNet', p.get('volcanoTitle', ''), lv, GEONET_ZH.get(lv, f'等級 {lv}'),
                              f"Volcanic Alert Level {lv}・{p.get('activity', '')}・Aviation Colour Code {p.get('acc', '')}",
                              lv >= 1, None, GEONET_PAGE))
    if not rows:
        raise ValueError('GeoNet 沒有可用的火山')
    return keep_worst(rows)


def track_changes(rows, prev, when):
    """跟上一份比：等級或說明變了就記下前一次的等級（prev_level、prev_label）與改變時間（changed_utc），沒變就沿用。
    上一份沒有這座火山（第一次抓到）時不算改變，因為不知道之前是幾級。"""
    old = {(r['agency'], r['vnum']): r for r in prev}
    out = []
    for r in rows:
        o = old.get((r['agency'], r['vnum']))
        if o and (o['level'], o['label']) != (r['level'], r['label']):
            r = {**r, 'prev_level': o['level'], 'prev_label': o['label'], 'changed_utc': when}
        elif o and o.get('changed_utc'):
            r = {**r, 'prev_level': o.get('prev_level'), 'prev_label': o.get('prev_label'), 'changed_utc': o['changed_utc']}
        out.append(r)
    return out


def update_levels(meta, vols):
    """三個機構各自抓；抓不到的機構沿用上一份，都抓不到就不改 levels.json。"""
    prev = load('levels.json', [])
    m = meta.setdefault('levels', {})
    srcs = (('JMA', lambda: parse_jma(fetch(JMA_WARN, 60), fetch(JMA_LIST, 60), vols)),
            ('PHIVOLCS', lambda: parse_phivolcs(fetch(PHIVOLCS_URL, 60).decode('utf-8', 'replace'), vols)),
            ('GeoNet', lambda: parse_geonet(fetch(GEONET_URL, 60), vols)))
    rows, ok = [], 0
    for agency, get in srcs:
        try:
            got = get()
            ok += 1
            m[agency] = {'fetched_utc': iso(now()), 'count': len(got), 'elevated': sum(r['elevated'] for r in got), 'error': None}
        except Exception as e:
            log.error('%s 警戒等級失敗，沿用上一份：%s', agency, e)
            m.setdefault(agency, {}).update({'error': str(e), 'error_utc': iso(now())})
            got = [r for r in prev if r.get('agency') == agency]
        rows += got
    if not ok:
        return
    rows = track_changes(rows, prev, iso(now()))
    rows.sort(key=lambda r: (r['agency'], r['vnum']))
    if rows != prev:
        save('levels.json', rows)
    log.info('各國警戒等級：%s', '、'.join(f"{a} {m[a].get('elevated', '?')} 座高於平常" for a, _ in srcs))


# ---------- B 段：Claude 補充（讀 V1 火山補充檔） ----------

def read_feed():
    """回傳 (items, generated_utc)；publish.json 沒設定 feed 時回傳 None。讀不到或格式不對丟例外。"""
    try:
        path = json.loads(CONF.read_text('utf-8')).get('feed')
    except FileNotFoundError:
        return None
    if not path:
        return None
    d = json.loads(Path(path).expanduser().read_text('utf-8'))
    if not isinstance(d, dict) or d.get('schema') != 1 or not isinstance(d.get('items'), list):
        raise ValueError('補充檔格式不對（schema 不是 1 或沒有 items）')
    return [i for i in d['items'] if isinstance(i, dict)], d.get('generated_utc')


OBS_DAYS = 30
OBS_SECTIONS = ('tw', 'near', 'global', 'other', 'media')  # V1 的台灣相關、鄰近島弧、全球重大、全球其他、重要媒體報導
# 跟 claude-api-routines 的 autoreport/v1.py 同一份清單，那邊改了這裡也要改
OBS_ACTIVITY = ('火山灰噴發', '小規模噴煙', '熔岩', '熔岩穹丘', '火山碎屑流', '地震或變形增強', '噴氣或氣體增加', '暫停或平靜')
OBS_HAZARDS = ('人員傷亡', '撤離', '火山泥流', '落灰影響生活', '航班或機場受影響', '建物或設施損壞')


def update_obs(meta, items, gvp_vnums, today):
    """V1 每天的條目累積成最近 OBS_DAYS 天的每日動態 obs.json（活動類型、規模、災害、分區），
    給詳細卡的 30 天活動圖與概況的「本日關注」用。補充檔只有 7 天，所以跟上一份合併；
    不管官方是不是已經涵蓋都留著（「官方為準」只用在噴發判斷）。meta['obs']['since'] 是開始保存的日期。"""
    prev = load('obs.json', [])
    lo = (today - timedelta(days=OBS_DAYS)).isoformat()
    rows = {r['id']: r for r in prev if r['date'] >= lo}
    for it in items:
        try:
            vnum = int(it.get('vnum'))
            pub = date.fromisoformat(str(it.get('date') or '')[:10]).isoformat()
        except (TypeError, ValueError):
            continue
        try:
            d = date.fromisoformat(str(it.get('activity_date') or '')[:10]).isoformat()
        except ValueError:
            d = pub
        url, summ = str(it.get('source_url') or '').strip(), str(it.get('summary') or '').strip()
        if (it.get('section') not in OBS_SECTIONS or vnum not in gvp_vnums or not lo <= d <= today.isoformat()
                or not url.startswith(('http://', 'https://')) or not summ):
            continue
        rid = f'{vnum}:{d}:{url}'
        lst = lambda k, ok: [x for x in (it.get(k) or []) if x in ok] if isinstance(it.get(k), list) else []
        rows[rid] = {'id': rid, 'vnum': vnum, 'date': d, 'pub': pub, 'section': it['section'], 'event': str(it.get('event') or '')[:20],
                     'activity': lst('activity', OBS_ACTIVITY), 'scale': str(it.get('scale') or '')[:4],
                     'hazards': lst('hazards', OBS_HAZARDS), 'hazard_note': str(it.get('hazard_note') or '').strip()[:200],
                     'alert_change': str(it.get('alert_change') or '').strip()[:200], 'summary': summ[:300],
                     'url': url, 'agency': str(it.get('source_name') or '').strip()}
    out = sorted(rows.values(), key=lambda r: (r['date'], r['id']), reverse=True)
    if out != prev:
        save('obs.json', out)
    m = meta.setdefault('obs', {})
    m.update({'since': m.get('since') or min((r['pub'] for r in out), default=None), 'count': len(out)})


def update_claude(meta, activity, alerts, vols):
    today = now().date()
    covered = official_vnums(activity, alerts, today - timedelta(days=CLAUDE_DAYS))
    prev = meta.get('claude', {})
    try:
        feed = read_feed()
    except Exception as e:
        log.error('讀不到 V1 火山補充檔，略過 B 段：%s', e)
        meta['claude'] = {**prev, 'status': 'failed', 'error': f'讀不到 V1 火山補充檔：{e}', 'error_utc': iso(now())}
        return activity
    if feed is None:
        log.warning('publish.json 沒有設定 feed，略過 B 段')
        meta['claude'] = {**prev, 'status': 'skipped', 'error': '沒有設定 V1 火山補充檔', 'error_utc': iso(now())}
        return activity
    items, gen = feed
    try:
        age = (now() - datetime.fromisoformat(str(gen).replace('Z', '+00:00'))).total_seconds() / 3600
    except ValueError:
        age = None
    update_obs(meta, items, {v['vnum'] for v in vols}, today)
    kept, dropped = validate_claude(items, {v['vnum'] for v in vols}, covered, today)
    reasons = {}
    for _, why in dropped:
        reasons[why] = reasons.get(why, 0) + 1
    activity, n = merge(activity, kept)
    if n:
        save('activity.json', activity)
    stale = age is None or age > FEED_MAX_AGE_HOURS
    meta['claude'] = {'run_utc': iso(now()), 'feed_utc': gen, 'status': 'stale' if stale else 'ok',
                      'returned': len(items), 'kept': len(kept), 'dropped': len(dropped), 'added': n,
                      'error': None if not stale else
                      f'補充檔已 {age:.0f} 小時沒有更新，V1 可能沒有執行' if age is not None else '補充檔沒有產生時間'}
    why = f"（{'、'.join(f'{k} {v}' for k, v in reasons.items())}）" if reasons else ''
    log.info('Claude 補充（V1 補充檔 %s）：%d 則，保留 %d，丟棄 %d%s，新增 %d', gen, len(items), len(kept),
             len(dropped), why, n)
    if stale:
        log.warning(meta['claude']['error'])
    return activity


# ---------- 日統計與資料庫 ----------

DAILY_DAYS = 30
KIND_RANK = {'ash': 4, 'lava': 3, 'minor': 2, 'other': 1}


def kind_of(acts, event):
    """每日報告一則的主要活動：火山灰噴發＞熔岩＞小規模噴煙＞其他（地震、變形、氣體，或舊格式只有事件類別）。"""
    a = set(acts)
    if a & {'火山灰噴發', '火山碎屑流'}:
        return 'ash'
    if a & {'熔岩', '熔岩穹丘'}:
        return 'lava'
    if '小規模噴煙' in a:
        return 'minor'
    if a & {'地震或變形增強', '噴氣或氣體增加'} or (not acts and event in ('噴發', '活動增強')):
        return 'other'
    return None


def daily_rows(ash, obs, activity, today, days=DAILY_DAYS):
    """每座火山每天一列（有資料的才列）：航空火山灰警報則數與最高灰雲、每日報告寫的活動（主要一種與全部）、
    是不是噴發日、災害。詳細卡的 30 天活動圖直接讀這張表（v0.19.12 起），資料庫也存一份，之後可以統計更長的期間。
    噴發日：有火山灰警報，或報告寫到火山灰、熔岩、小規模噴煙（舊格式看事件類別「噴發」），或活動紀錄裡 Claude 補充的噴發。"""
    lo, hi = (today - timedelta(days=days - 1)).isoformat(), today.isoformat()
    rows = {}

    def row(vn, d):
        return rows.setdefault((d, vn), {'id': f'{d}:{vn}', 'date': d, 'vnum': vn, 'ash_n': 0, 'ash_top_ft': 0,
                                         'kind': None, 'activity': [], 'eruption': False, 'hazards': []})

    def put(r, k):
        if k and (not r['kind'] or KIND_RANK[k] > KIND_RANK[r['kind']]):
            r['kind'] = k

    for a in ash:
        d = str(a.get('from') or '')[:10]
        if lo <= d <= hi and isinstance(a.get('vnum'), int):
            r = row(a['vnum'], d)
            r['ash_n'] += 1
            r['ash_top_ft'] = max(r['ash_top_ft'], a.get('top_ft') or 0)
            r['eruption'] = True
    for o in obs:
        d = str(o.get('date') or '')
        if not (lo <= d <= hi and isinstance(o.get('vnum'), int)):
            continue
        r, acts = row(o['vnum'], d), [x for x in (o.get('activity') or []) if x in OBS_ACTIVITY]
        k = kind_of(acts, o.get('event'))
        put(r, k)
        r['activity'] += [x for x in acts if x not in r['activity']]
        if k in ('ash', 'lava', 'minor') or (not acts and o.get('event') == '噴發'):
            r['eruption'] = True
        if o.get('hazards'):
            h = '、'.join(o['hazards']) + (f"（{o['hazard_note']}）" if o.get('hazard_note') else '')
            if h not in r['hazards']:
                r['hazards'].append(h)
    for a in activity:
        if a.get('source') == 'claude' and a.get('eruption') and lo <= str(a.get('date') or '') <= hi:
            r = row(a['vnum'], a['date'])
            r['eruption'] = True
            put(r, 'other')
    out = sorted(rows.values(), key=lambda r: (r['date'], r['vnum']))
    for r in out:
        r['activity'].sort(key=OBS_ACTIVITY.index)
    return out


def update_daily(meta, today):
    rows = daily_rows(load('ash.json', []), load('obs.json', []), load('activity.json', []), today)
    save('daily.json', rows)
    meta['daily'] = {'days': DAILY_DAYS, 'count': len(rows)}
    log.info('日統計：最近 %d 天 %d 列', DAILY_DAYS, len(rows))
    return rows


ARCHIVE_README = """# 火山脈動資料庫（volcano-pulse-archive）

火山脈動資料站（Mac mini）每天 09:00 更新時寫入、推送。展示端不讀這裡，展示端讀公開的 volcano-pulse-data。
每個資料夾每月一個 JSON Lines 檔（`YYYY-MM.jsonl`，一行一筆，UTF-8），依 `id` 合併：同一個 id 以最新一次為準，舊的不刪。
用 Python 讀：`pd.read_json('daily/2026-11.jsonl', lines=True)`。

| 資料夾 | 內容 | id | 月份依據 |
|---|---|---|---|
| `v1/` | V1 每日報告（Claude 網路搜尋整理，未經官方確認）的每一則，欄位同 V1 火山補充檔：分區 section、事件 event、是否噴發 eruption、活動類型 activity、規模 scale、災害 hazards、hazard_note、觀測 seismic_obs/gas_obs/other_obs、摘要 summary、來源 source_url/source_name、發布日 date、活動日 activity_date | `vnum:發布日:網址` | 發布日 |
| `ash/` | 航空火山灰警報（NOAA AWC 國際 SIGMET）：起訖 from/to、灰雲頂 top_ft（英尺，照原文）、飄移方向與速度、FIR | AWC 的 SIGMET 編號 | 生效時間 from |
| `official/` | 官方活動紀錄：USGS HANS 警戒變動（source=hans）、GVP 週報（source=rss） | 原本的 id | 日期 date |
| `levels/` | 各國警戒等級（日本氣象廳、PHIVOLCS、GeoNet）每天的快照 | `日期:機構:vnum` | 快照日期 date |
| `daily/` | 每座火山每天一列的日統計（有資料的才列）：火山灰警報則數 ash_n、最高灰雲 ash_top_ft、每日報告的主要活動 kind（ash 火山灰、lava 熔岩、minor 小規模噴煙、other 其他）與全部活動 activity、是否噴發日 eruption、災害 hazards。最近 30 天每天重算，更早的固定不動 | `日期:vnum` | 日期 date |

注意：日期都是 UTC；`vnum` 是 Smithsonian GVP 火山編號；灰雲高度照警報原文，少數警報原文有誤（例如寫 180FT 實際應是 FL180）。
"""


def archive_path():
    try:
        path = json.loads(CONF.read_text('utf-8')).get('archive')
    except FileNotFoundError:
        return None
    return Path(path).expanduser() if path else None


def archive_merge(root, name, rows, month_of):
    """rows 依月份併進 root/name/YYYY-MM.jsonl（同一個 id 用新的取代、舊的不刪），內容有變才寫；回傳新增的 id 數。"""
    by = {}
    for r in rows:
        by.setdefault(month_of(r), []).append(r)
    added = 0
    for m, rs in sorted(by.items()):
        p = root / name / f'{m}.jsonl'
        old = {}
        if p.exists():
            for line in p.read_text('utf-8').splitlines():
                if line.strip():
                    o = json.loads(line)
                    old[o['id']] = o
        new = dict(old)
        for r in rs:
            added += r['id'] not in old
            new[r['id']] = r
        if new != old:
            p.parent.mkdir(parents=True, exist_ok=True)
            key = lambda r: (str(r.get('date') or r.get('from') or ''), r['id'])
            tmp = p.with_name(p.name + '.tmp')
            tmp.write_text(''.join(json.dumps(r, ensure_ascii=False, sort_keys=True) + '\n' for r in sorted(new.values(), key=key)), 'utf-8')
            os.replace(tmp, p)
    return added


def update_archive(meta, today, daily, v1_items=None):
    """把今天的資料併進私有資料庫 repo 的工作目錄（publish.py 負責 commit 與推送）；沒設定 archive 就略過，失敗不影響更新。"""
    root = archive_path()
    if not root:
        return
    if not (root / '.git').exists():
        log.warning('資料庫：%s 不是 git repo，略過', root)
        return
    try:
        if v1_items is None:
            feed = read_feed()
            v1_items = feed[0] if feed else []
        v1 = [{**it, 'id': f"{it['vnum']}:{str(it['date'])[:10]}:{it['source_url']}"} for it in v1_items
              if isinstance(it.get('vnum'), int) and str(it.get('date') or '')[:10] and str(it.get('source_url') or '').startswith('http')]
        t = today.isoformat()
        n = {'v1': archive_merge(root, 'v1', v1, lambda r: str(r['date'])[:7]),
             'ash': archive_merge(root, 'ash', [r for r in load('ash.json', []) if r.get('id')], lambda r: r['from'][:7]),
             'official': archive_merge(root, 'official', [r for r in load('activity.json', []) if r.get('source') in ('hans', 'rss')],
                                       lambda r: r['date'][:7]),
             'levels': archive_merge(root, 'levels', [{**r, 'id': f"{t}:{r['agency']}:{r['vnum']}", 'date': t} for r in load('levels.json', [])],
                                     lambda r: r['date'][:7]),
             'daily': archive_merge(root, 'daily', daily, lambda r: r['date'][:7])}
        rd = root / 'README.md'
        if not rd.exists() or rd.read_text('utf-8') != ARCHIVE_README:
            rd.write_text(ARCHIVE_README, 'utf-8')
        meta['archive'] = {'run_utc': iso(now()), 'added': n}
        log.info('資料庫：新增 %s', '、'.join(f'{k} {v}' for k, v in n.items()))
    except Exception as e:  # 資料庫只是備份，失敗不影響展示資料
        record_error(meta, 'archive', e)


# ---------- YouTube 直播清單（V1 輸出） ----------

# 固定直播：V1 只搜十年火山與 7 天內噴發的火山，這裡的另外固定加上、排在最前面（每座最多 3 支）。
# 直播重開會換影片編號，換了要改這裡（YouTube 網址 watch?v= 後面的 11 碼）
PINNED_LIVE = {
    '281032': [{'id': 'ze-EL4lKdLw', 'title': '小油坑即時影像', 'channel': 'TVO大屯火山觀測站', 'official': True}],  # 大屯火山群
}

def update_media(meta):
    """讀 publish.json 的 media（V1 輸出的直播清單），檢查後存成 data/media.json；讀不到就保留上一份。"""
    try:
        path = json.loads(CONF.read_text('utf-8')).get('media')
    except FileNotFoundError:
        path = None
    if not path:
        return
    try:
        d = json.loads(Path(path).expanduser().read_text('utf-8'))
        if not isinstance(d, dict) or d.get('schema') != 1 or not isinstance(d.get('live'), dict):
            raise ValueError('直播清單格式不對（schema 不是 1 或沒有 live）')
        live = {}
        for vn, lst in d['live'].items():
            ok = [{'id': x['id'], 'title': x['title'], 'channel': x['channel'], 'official': x.get('official') is True,
                   'viewers': x['viewers'] if isinstance(x.get('viewers'), int) else None,
                   'started': str(x.get('started') or '')[:10]}
                  for x in (lst if isinstance(lst, list) else [])
                  if isinstance(x, dict) and YT_ID.fullmatch(str(x.get('id', '')))
                  and isinstance(x.get('title'), str) and isinstance(x.get('channel'), str)]
            if ok and str(vn).isdigit():
                live[str(int(vn))] = ok[:3]
        for vn, lst in PINNED_LIVE.items():
            ids = {x['id'] for x in lst}
            live[vn] = ([{**x, 'viewers': None, 'started': ''} for x in lst] + [x for x in live.get(vn, []) if x['id'] not in ids])[:3]
    except Exception as e:
        record_error(meta, 'media', e)
        return
    save('media.json', {'generated_utc': d.get('generated_utc'), 'live': live})
    meta['media'] = {'generated_utc': d.get('generated_utc'), 'volcanoes': len(live),
                     'videos': sum(map(len, live.values())), 'error': None}
    log.info('YouTube 直播：%d 座火山、%d 支（清單 %s）', len(live), meta['media']['videos'], d.get('generated_utc'))


# ---------- 主流程 ----------

def close_logging():
    for h in list(log.handlers):
        log.removeHandler(h)
        h.close()


def setup_logging():
    close_logging()
    fmt = logging.Formatter('%(asctime)s UTC %(levelname)s %(message)s', '%Y-%m-%d %H:%M:%S')
    fmt.converter = lambda *a: now().timetuple()
    for h in (logging.FileHandler(DATA / 'update.log', encoding='utf-8'), logging.StreamHandler()):
        h.setFormatter(fmt)
        log.addHandler(h)
    log.setLevel(logging.INFO)


def main(argv):
    DATA.mkdir(exist_ok=True)
    setup_logging()
    log.info('==== 開始更新 ====')
    meta = load('meta.json', {})
    ok = update_gvp(meta, '--force-gvp' in argv)
    check_decade(meta)  # 只提醒，失敗不影響結束碼
    hans_recs = update_hans(meta)
    rss_recs = update_rss(meta)
    ok = ok and hans_recs is not None and rss_recs is not None
    activity, n = merge(load('activity.json', []), (hans_recs or []) + (rss_recs or []))
    if n:
        save('activity.json', activity)
    log.info('活動歷史新增 %d 筆，共 %d 筆', n, len(activity))
    vols = load('volcanoes.json', [])
    if vols:  # 火山灰警報與各國警戒只提供附加資訊，失敗不影響結束碼
        update_ash(meta, vols)
        update_levels(meta, vols)
    if '--no-claude' not in argv and vols:
        update_claude(meta, activity, load('alerts.json', []), vols)
    update_media(meta)
    daily = update_daily(meta, now().date())
    update_archive(meta, now().date(), daily)
    meta['updated_utc'] = iso(now())
    save('meta.json', meta)
    log.info('==== 完成%s ====', '' if ok else '（部分官方來源失敗，詳見上方）')
    return 0 if ok else 1


# ---------- 自我檢查 ----------

SAMPLE_RSS = '''<?xml version="1.0" encoding="ISO-8859-1"?>
<rss version="2.0" xmlns:georss="http://www.georss.org/georss"><channel><title>t</title>
<item><title>Purac\xe9 (Colombia) - Report for 31 December-6 January 2026 - Continuing Eruptive Activity</title>
<description>&lt;p&gt;Gas emissions continued.&lt;/p&gt;&lt;p&gt;Source: Servicio Geol\xf3gico Colombiano (SGC)&lt;/p&gt;</description>
<guid isPermaLink="true">https://volcano.si.edu/reports_weekly.cfm#vn_351060</guid>
<georss:point>2.3095 -76.3948</georss:point></item>
</channel></rss>'''.encode('latin-1')


def selftest():
    global DATA, fetch, CONF, ASH_PAUSE
    real_data, real_fetch, real_conf, real_pause = DATA, fetch, CONF, ASH_PAUSE
    ASH_PAUSE = 0  # 不連網，不用等
    fails = []

    def check(cond, msg):
        print(('  OK   ' if cond else '  FAIL ') + msg)
        cond or fails.append(msg)

    with tempfile.TemporaryDirectory() as td:
        DATA = Path(td)
        DATA.mkdir(exist_ok=True)
        CONF = DATA / 'publish.json'  # 不讀真正的資料站設定
        today = now().date()
        vols = [{'vnum': 211060 + i, 'name': f'V{i}', 'country': 'X', 'type': 't', 'last_eruption': None,
                 'evidence': 'e', 'lat': 0, 'lon': 0} for i in range(3)]
        old_act = [{'id': 'rss:211060:2026-01-01', 'vnum': 211060, 'source': 'rss', 'verified': True,
                    'date': today.isoformat(), 'title': 'old', 'summary': 'old', 'agency': '', 'url': 'u'}]
        save('volcanoes.json', vols)
        save('alerts.json', [{'vnum': 211061, 'name': 'V1', 'color_code': 'ORANGE', 'alert_level': 'WATCH',
                              'observatory': 'o', 'notice_id': 'n', 'sent_utc': '2026-01-01T00:00:00Z',
                              'url': 'u'}])
        save('activity.json', old_act)
        snap = lambda: {p.name: p.read_bytes() for p in DATA.glob('*.json') if p.name not in ('meta.json', 'daily.json')}  # daily 是推算的
        before = snap()

        print('1. 抓取失敗時不覆寫舊資料')
        def boom(url, timeout=0):
            raise OSError('模擬網路中斷')
        fetch = boom
        rc = main(['--no-claude', '--force-gvp'])
        check(snap() == before, '網路中斷：volcanoes / alerts / activity 內容完全沒變')
        check(rc == 1, '網路中斷：結束碼為 1')
        check('模擬網路中斷' in (DATA / 'update.log').read_text('utf-8'), '錯誤有寫進 update.log')
        check(load('meta.json', {}).get('rss', {}).get('error') == '模擬網路中斷', 'meta.json 記下錯誤')

        responses = {GVP_WFS: b'{"type":"FeatureCollection","features":[]}', RSS_URL: b'<rss><channel/></rss>',
                     HANS_URL: b'{"error":"oops"}'}
        fetch = lambda url, timeout=0: responses.get(url, b'')
        main(['--no-claude', '--force-gvp'])
        check(snap() == before, '回傳空資料或格式錯誤：舊資料完全沒變')
        check(not list(DATA.glob('*.tmp')), '沒有殘留 .tmp 暫存檔')

        print('2. Claude 補充資料驗證')
        d = today.isoformat()
        good = {'vnum': 211062, 'volcano_name': 'V2', 'date': d, 'summary': '有噴發', 'source_url': 'https://a.b/c',
                'source_name': 'Obs', 'eruption': True}
        items = [good,
                 {**good, 'source_url': ''},                       # 缺來源 URL
                 {k: v for k, v in good.items() if k != 'source_url'},
                 {**good, 'date': ''},                             # 缺日期
                 {**good, 'vnum': 999999},                         # 編號不存在
                 {**good, 'vnum': None},
                 {**good, 'date': (today - timedelta(days=30)).isoformat()},  # 太舊
                 {**good, 'vnum': 211060},                         # 官方已涵蓋
                 {**good, 'vnum': 211061}]                         # HANS 警戒中
        covered = official_vnums(old_act, load('alerts.json', []), today - timedelta(days=CLAUDE_DAYS))
        kept, dropped = validate_claude(items, {v['vnum'] for v in vols}, covered, today)
        check(len(kept) == 1 and kept[0]['vnum'] == 211062, '只保留 1 筆完整資料')
        check(kept[0]['verified'] is False, '保留的補充資料標記為未經官方確認')
        check(kept[0]['eruption'] is True, '保留 Claude 回報的噴發判定')
        k2, _ = validate_claude([{**good, 'eruption': 'yes'}, {k: v for k, v in good.items() if k != 'eruption'}],
                                {v['vnum'] for v in vols}, covered, today)
        check([r['eruption'] for r in k2] == [False, False], '噴發判定缺少或不是布林值時當作不是噴發')
        check(len(dropped) == 8, '缺 URL、缺日期、編號錯誤、太舊、官方已涵蓋，共 8 筆全部丟棄')
        merged, _ = merge(old_act, kept)
        check(merged[0] == old_act[0], '補充資料不會改動既有官方紀錄')

        print('3. 讀 V1 火山補充檔')
        base, meta = load('activity.json', []), {}
        check(update_claude(meta, base, [], vols) == base and meta['claude']['status'] == 'skipped',
              '沒有設定補充檔：跳過 B 段，活動資料不變')
        feed = DATA / 'feed.json'
        CONF.write_text(json.dumps({'feed': str(feed)}), 'utf-8')
        feed.write_text('{"schema": 1, "items": [', 'utf-8')
        check(update_claude(meta, base, [], vols) == base and meta['claude']['status'] == 'failed',
              '補充檔壞掉：標記失敗，活動資料不變')
        feed.write_text(json.dumps({'schema': 1, 'generated_utc': iso(now()),
                                    'items': [good, {**good, 'vnum': 211060}]}), 'utf-8')
        act = update_claude(meta, base, [], vols)
        check(meta['claude']['status'] == 'ok' and meta['claude']['kept'] == 1 and len(act) == len(base) + 1,
              '補充檔正常：官方已涵蓋的丟棄，其餘併入活動資料')
        check(act[-1]['verified'] is False and act[-1]['eruption'] is True, '併入的資料標記未經官方確認，保留噴發判定')
        check(update_claude(meta, act, [], vols) == act and meta['claude']['added'] == 0, '同一份補充檔再讀一次：不重複新增')
        feed.write_text(json.dumps({'schema': 1, 'generated_utc': iso(now() - timedelta(hours=60)), 'items': []}), 'utf-8')
        update_claude(meta, act, [], vols)
        check(meta['claude']['status'] == 'stale' and '60 小時' in meta['claude']['error'], '補充檔超過 36 小時：標記過舊')

        print('3b. YouTube 直播清單')
        media = DATA / 'media_in.json'
        CONF.write_text(json.dumps({'feed': str(feed), 'media': str(media)}), 'utf-8')
        media.write_text(json.dumps({'schema': 1, 'generated_utc': 'g', 'live': {
            '211060': [{'id': 'abcdefghijk', 'title': 'Etna volcano', 'channel': 'c', 'official': True, 'viewers': 5, 'x': 1},
                       {'id': 'bad id"><script>', 'title': 't', 'channel': 'c'}, {'id': 'abcdefghijm', 'title': 3}],
            'oops': [{'id': 'abcdefghijk', 'title': 't', 'channel': 'c'}]}}), 'utf-8')
        meta = {}
        update_media(meta)
        got = load('media.json', {})
        check(list(got.get('live', {})) == ['211060', *PINNED_LIVE] and [x['id'] for x in got['live']['211060']] == ['abcdefghijk'],
              '只收格式正確的影片編號與火山編號，另外加上固定直播')
        check(got['live']['281032'][0]['id'] == PINNED_LIVE['281032'][0]['id'] and got['live']['281032'][0]['official'] is True,
              '大屯火山群有小油坑的固定直播')
        check(set(got['live']['211060'][0]) == {'id', 'title', 'channel', 'official', 'viewers', 'started'},
              '只留需要的欄位')
        media.write_text('{"schema": 1, "live": ', 'utf-8')
        update_media(meta)
        check(load('media.json', {}) == got and meta['media'].get('error'), '清單壞掉：保留上一份並記下錯誤')

        print('4. 解析器')
        s, e, recs = parse_rss(SAMPLE_RSS)
        check((s, e) == ('2025-12-31', '2026-01-06'), 'RSS 跨年報告期間解析正確')
        check(recs[0]['vnum'] == 351060 and 'SGC' in recs[0]['agency'], 'RSS 從 guid 取編號、拆出來源機構')
        a = parse_hans(b'[{"obs_fullname":"AVO","volcano_name":"X","vnum":"311120","notice_identifier":"n2",'
                       b'"sent_unixtime":1793563510,"color_code":"RED","alert_level":"WARNING","notice_url":"u"}]')
        check(a[0]['vnum'] == 311120 and a[0]['sent_utc'] == '2026-11-01T20:05:10Z', 'HANS 字串編號轉整數、時間轉 UTC')
        ch = hans_changes([{**a[0], 'color_code': 'ORANGE', 'alert_level': 'WATCH'}], a, d)
        check(len(ch) == 1 and 'ORANGE/WATCH → RED/WARNING' in ch[0]['title'], 'HANS 只記錄警戒變動')
        cite = parse_gvp_citation('<p>Global Volcanism Program, 2026. [Database] Volcanoes of the World (v. 5.4.0; '
                                  '7 Aug 2026). Distributed by Smithsonian Institution, compiled by Venzke, E. '
                                  '<a href="https://doi.org/10.5479/si.GVP.VOTW5-2026.5.4">x</a>')
        check(cite['version'] == '5.4.0' and cite['doi'] == '10.5479/si.GVP.VOTW5-2026.5.4', 'GVP 引用文字解析')
        print('5. 十年火山每年比對')
        row = lambda n: f'\n|-\n|[[{n}]]\n|x'
        wiki = lambda ns: json.dumps({'parse': {'wikitext': '{| class="wikitable"\n|-\n!Volcano' + ''.join(row(n) for n in ns) + '\n|}'}}).encode()
        base = [n for n in DECADE_BASELINE if '+' not in n]
        check(parse_decade_wiki(wiki(base + ['Avachinsky]]-[[Koryaksky'])) == base + ['Avachinsky + Koryaksky'], '表格解析：一格兩座時合在一起')
        fetch = lambda url, timeout=0: wiki(DECADE_BASELINE[:-1] + ['Mount Fuji'])
        meta = {}
        check_decade(meta)
        dc = meta['decade_check']
        check(dc['status'] == 'diff' and dc['added'] == ['Mount Fuji'] and dc['removed'] == [DECADE_BASELINE[-1]], '名單變了：記下新增與移除')
        fetch = boom
        check_decade(meta)
        check(meta['decade_check']['checked_utc'] == dc['checked_utc'] and not meta['decade_check'].get('error'), '一年內不重複比對')
        meta['decade_check']['checked_utc'] = iso(now() - timedelta(days=400))
        check_decade(meta)
        check(meta['decade_check'].get('error') == '模擬網路中斷', '過了一年再比對；失敗時記下錯誤，下次再試')

        print('6. 火山灰警報與各國警戒等級')
        gv = [{'vnum': 263300, 'name': 'Semeru', 'country': 'Indonesia', 'lat': -8.108, 'lon': 112.922},
              {'vnum': 242030, 'name': 'Raoul Island', 'country': 'New Zealand', 'lat': -29.27, 'lon': -177.92},
              {'vnum': 273030, 'name': 'Mayon', 'country': 'Philippines', 'lat': 13.257, 'lon': 123.685},
              {'vnum': 282080, 'name': 'Aira', 'country': 'Japan', 'lat': 31.593, 'lon': 130.657},
              {'vnum': 241080, 'name': 'Tongariro', 'country': 'New Zealand', 'lat': -39.157, 'lon': 175.632}]
        check(nearest_vnum(gv, -29.25, 179.99, 300) == 242030 and nearest_vnum(gv, 0, 0, 30) is None, '座標對火山：跨換日線對得到、太遠不對')
        sig = lambda raw, **k: {'hazard': 'VA', 'firId': 'WAAF', 'firName': 'WAAF UJUNG PANDANG', 'validTimeFrom': 1794180000,
                                'validTimeTo': 1794201600, 'top': 15000, 'dir': 'W', 'spd': '20', 'rawSigmet': raw, **k}
        ok_raw = 'WAAF SIGMET 32 VALID 082320/090520 WAAA- VA ERUPTION MT SEMERU PSN S0806 E11255 VA CLD OBS AT 2300Z'
        page = json.dumps([sig(ok_raw), sig(ok_raw, seriesId='32F'), sig('SIGMET 03 CNL SIGMET 28 082050/090250='),
                           sig('STATUS: EXER VA ERUPTION MT SEMERU PSN S0806 E11255'), sig('VA ERUPTION MT X PSN N0000 E00000'),
                           sig(ok_raw, hazard='TS')]).encode()
        rs = parse_sigmets(page, gv)
        check(len(rs) == 2 and len({r['id'] for r in rs}) == 1 and rs[0]['vnum'] == 263300 and rs[0]['top_ft'] == 15000
              and rs[0]['spd_kt'] == 20, 'SIGMET：同一份的兩筆 id 相同（存檔時合併），取消、演習、對不到火山、非火山灰都不收')
        check(parse_sigmets(b'', gv) == [], 'SIGMET：AWC 沒有結果（HTTP 204 空內容）當作沒有警報')
        old = {**rs[0], 'id': 'old', 'from': '2000-01-01T00:00:00Z', 'to': '2000-01-01T06:00:00Z'}
        save('ash.json', [old])
        meta = {}
        fetch = lambda url, timeout=0: page
        update_ash(meta, gv)
        check([r['id'] for r in load('ash.json', [])] == [rs[0]['id']] and meta['ash']['error'] is None, f'火山灰：超過 {ASH_DAYS} 天的舊紀錄刪掉、新的存進來')
        fetch = boom
        before_ash = load('ash.json', [])
        update_ash(meta, gv)
        check(load('ash.json', []) == before_ash and meta['ash'].get('error') == '模擬網路中斷', '火山灰：全部查詢失敗就保留上一份')

        jl = json.dumps([{'code': str(500 + i), 'latlon': ['0', '0']} for i in range(100)]
                        + [{'code': '506', 'latlon': ['31.585', '130.657']}, {'code': '900', 'name_jp': '全国'}]).encode()
        jwf = lambda name: json.dumps([{'reportDatetime': '2022-07-27T20:00:00+09:00', 'volcanoInfos': [{'type': '噴火警報・予報（対象火山）', 'items': [
            {'name': name, 'code': '13', 'areas': [{'name': '桜島', 'code': '506'}]}]}]}]).encode()
        jw = jwf('レベル３（入山規制）')
        j = parse_jma(jw, jl, gv)
        check(len(j) == 1 and j[0]['vnum'] == 282080 and j[0]['level'] == 3 and j[0]['label'] == '等級 3：禁止登山'
              and j[0]['elevated'] and j[0]['time'] == '2022-07-27T11:00:00Z', 'JMA：全形等級轉數字、翻成中文、時間轉 UTC')
        check(not parse_jma(jwf('レベル１（活火山であることに留意）'), jl, gv)[0]['elevated'], 'JMA：等級 1 不算警戒升高')
        ph = parse_phivolcs('<p>Alert Level Status:</p><p>Mayon - 3</p><p>Taal - 1</p><p>Summary of 24Hr Observation 09 November 2026</p>', gv)
        check(len(ph) == 1 and ph[0]['level'] == 3 and ph[0]['time'] == '2026-11-09T00:00:00Z', 'PHIVOLCS：頁首等級，對不到的火山略過')
        gn = json.dumps({'features': [{'geometry': {'coordinates': [175.64, -39.13]}, 'properties': {'level': 0, 'volcanoTitle': 'Tongariro'}},
                                      {'geometry': {'coordinates': [175.632, -39.156]}, 'properties': {'level': 1, 'volcanoTitle': 'Ngauruhoe'}},
                                      {'geometry': {'coordinates': [173.63, -35.395]}, 'properties': {'level': 0, 'volcanoTitle': 'Northland'}}]}).encode()
        g = parse_geonet(gn, gv)
        check(len(g) == 1 and g[0]['local'] == 'Ngauruhoe' and g[0]['elevated'], 'GeoNet：同一座 GVP 火山留等級高的，對不到的略過')
        resp = {JMA_WARN: jw, JMA_LIST: jl, GEONET_URL: gn}
        fetch = lambda url, timeout=0: resp.get(url) or (_ for _ in ()).throw(OSError('模擬 PHIVOLCS 失敗'))
        save('levels.json', [{**ph[0], 'level': 2}])
        meta = {}
        update_levels(meta, gv)
        lv = load('levels.json', [])
        check(sorted(r['agency'] for r in lv) == ['GeoNet', 'JMA', 'PHIVOLCS'] and [r['level'] for r in lv if r['agency'] == 'PHIVOLCS'] == [2]
              and meta['levels']['PHIVOLCS']['error'], '各國警戒：抓不到的機構沿用上一份並記下錯誤')
        prev = [{'agency': 'JMA', 'vnum': 1, 'level': 2, 'label': '等級 2'}, {'agency': 'JMA', 'vnum': 2, 'level': 3, 'label': '等級 3'}]
        cur = [{'agency': 'JMA', 'vnum': 1, 'level': 3, 'label': '等級 3'}, {'agency': 'JMA', 'vnum': 2, 'level': 3, 'label': '等級 3'},
               {'agency': 'JMA', 'vnum': 3, 'level': 2, 'label': '等級 2'}]
        t1 = track_changes(cur, prev, 'T1')
        check(t1[0]['prev_level'] == 2 and t1[0]['changed_utc'] == 'T1' and 'changed_utc' not in t1[1] and 'changed_utc' not in t1[2],
              '各國警戒：等級改變記下前一級與時間；沒變、第一次抓到不算改變')
        t2 = track_changes([dict(r) for r in cur], t1, 'T2')
        check(t2[0]['changed_utc'] == 'T1' and t2[0]['prev_level'] == 2, '各國警戒：下一次沒變時沿用上次的改變紀錄')
        h = hans_changes([{'vnum': 5, 'color_code': 'YELLOW', 'alert_level': 'ADVISORY', 'observatory': 'AVO'}],
                         [{'vnum': 5, 'color_code': 'ORANGE', 'alert_level': 'WATCH', 'observatory': 'AVO', 'notice_id': 'n', 'sent_utc': '2026-11-09T00:00:00Z', 'url': 'u'}], '2026-11-09')
        check(h[0]['prev'] == 'YELLOW/ADVISORY' and h[0]['level'] == 'ORANGE/WATCH', 'HANS：變動紀錄帶前後等級')
        items = [{'vnum': 263300, 'date': '2026-11-09', 'activity_date': '2026-11-08', 'section': 'global', 'source_url': 'https://x',
                  'summary': '熔岩噴泉', 'event': '噴發', 'activity': ['熔岩', '亂寫'], 'hazards': ['撤離'], 'hazard_note': '撤離 50 人'},
                 {'vnum': 263300, 'date': '2026-11-09', 'section': 'other', 'source_url': 'https://y', 'summary': '持續小噴煙', 'activity': ['小規模噴煙']},
                 {'vnum': 263300, 'date': '2026-09-01', 'section': 'near', 'source_url': 'https://x', 'summary': '太舊'},
                 {'vnum': 999, 'date': '2026-11-09', 'section': 'tw', 'source_url': 'https://x', 'summary': '不在 GVP'}]
        meta = {}
        update_obs(meta, items, {263300}, date(2026, 11, 9))
        ob = load('obs.json', [])
        check(len(ob) == 2 and ob[0]['date'] == '2026-11-09' and ob[1]['date'] == '2026-11-08' and ob[1]['activity'] == ['熔岩']
              and ob[1]['hazards'] == ['撤離'] and ob[1]['pub'] == '2026-11-09' and meta['obs']['since'] == '2026-11-09',
              '每日動態：各區都留、日期用活動日、清單外的類型丟掉、太舊與 GVP 沒有的不收')
        update_obs(meta, items + [{'vnum': 263300, 'date': '2026-11-09', 'section': 'media', 'source_url': 'https://reuters.com/z',
                                   'summary': '媒體報導', 'source_name': 'Reuters'}], {263300}, date(2026, 11, 9))
        check([(r['section'], r['agency']) for r in load('obs.json', []) if r['section'] == 'media'] == [('media', 'Reuters')],
              '每日動態：重要媒體報導區也收，來源名稱照 V1 給的媒體名')
        check(merge([{'id': 'a'}], [{'id': 'b'}, {'id': 'b'}, {'id': 'a'}]) == ([{'id': 'a'}, {'id': 'b'}], 1),
              '合併：新的一批裡同一個 id 只留第一筆')
        update_obs(meta, items[1:2], {263300}, date(2026, 11, 10))
        check(len(load('obs.json', [])) == 3 and meta['obs']['since'] == '2026-11-09', '每日動態：跟上一份合併，開始保存日期不變')  # 上一份有媒體那則，共 3 則
        td_ = date(2026, 11, 9)
        dr = daily_rows([{'vnum': 1, 'from': '2026-11-08T01:00:00Z', 'top_ft': 9000}, {'vnum': 1, 'from': '2026-11-08T07:00:00Z', 'top_ft': 12000},
                         {'vnum': 1, 'from': '2026-10-01T00:00:00Z', 'top_ft': 5000}],
                        [{'vnum': 1, 'date': '2026-11-08', 'activity': ['小規模噴煙'], 'event': '其他', 'hazards': []},
                         {'vnum': 2, 'date': '2026-11-09', 'activity': ['熔岩', '亂寫'], 'event': '噴發', 'hazards': ['撤離'], 'hazard_note': '50 人'},
                         {'vnum': 2, 'date': '2026-11-09', 'activity': ['地震或變形增強'], 'event': '其他', 'hazards': ['撤離'], 'hazard_note': '50 人'},
                         {'vnum': 3, 'date': '2026-11-07', 'activity': ['暫停或平靜'], 'event': '其他', 'hazards': []}],
                        [{'vnum': 4, 'date': '2026-11-06', 'source': 'claude', 'eruption': True}], td_)
        by = {(r['date'], r['vnum']): r for r in dr}
        check(by[('2026-11-08', 1)]['ash_n'] == 2 and by[('2026-11-08', 1)]['ash_top_ft'] == 12000 and by[('2026-11-08', 1)]['kind'] == 'minor'
              and by[('2026-11-08', 1)]['eruption'] and ('2026-10-01', 1) not in by,
              '日統計：灰雲則數與最高、活動列只看報告、30 天以外不列')
        check(by[('2026-11-09', 2)]['kind'] == 'lava' and by[('2026-11-09', 2)]['activity'] == ['熔岩', '地震或變形增強']
              and by[('2026-11-09', 2)]['hazards'] == ['撤離（50 人）'], '日統計：主要活動取最強、全部活動固定順序、同樣災害只記一次')
        check(not by[('2026-11-07', 3)]['eruption'] and by[('2026-11-07', 3)]['kind'] is None and by[('2026-11-06', 4)]['kind'] == 'other'
              and by[('2026-11-06', 4)]['eruption'], '日統計：暫停不算噴發；Claude 補充的噴發算噴發日')
        ar = Path(td) / 'arch'
        n1 = archive_merge(ar, 'x', [{'id': 'b', 'date': '2026-11-02'}, {'id': 'a', 'date': '2026-10-31'}], lambda r: r['date'][:7])
        n2 = archive_merge(ar, 'x', [{'id': 'b', 'date': '2026-11-02', 'v': 2}, {'id': 'c', 'date': '2026-11-01'}], lambda r: r['date'][:7])
        lines = (ar / 'x' / '2026-11.jsonl').read_text('utf-8').splitlines()
        check(n1 == 2 and n2 == 1 and (ar / 'x' / '2026-10.jsonl').exists() and [json.loads(x)['id'] for x in lines] == ['c', 'b']
              and json.loads(lines[1]).get('v') == 2, '資料庫：依月份分檔、同一個 id 用新的取代、依日期排序')
        check(parse_gvp(json.dumps({'features': [{'properties': {'Volcano_Number': 1, 'Volcano_Name': 'a', 'Country': 'b', 'Primary_Volcano_Type': 'c',
              'Last_Eruption_Year': 2026, 'Evidence_Category': 'd', 'Latitude': 0, 'Longitude': 0, 'Elevation': 1330}}] * 1000}))[0]['elev'] == 1330,
              'GVP：帶山頂高度')
        close_logging()  # 暫存目錄刪除前關掉 log 檔

    DATA, fetch, CONF, ASH_PAUSE = real_data, real_fetch, real_conf, real_pause
    print(f"\n{'全部通過' if not fails else f'{len(fails)} 項失敗'}")
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(selftest() if '--selftest' in sys.argv else main(sys.argv[1:]))
