// 教學模式的剖面示意圖（SVG）：teach.json 的 types[].diagram 用這裡的 key。只是示意，比例不準
const SKY = '#EEF4FA', SEA = '#CFE6F5', MANTLE = '#F6DCC4', OP = '#5C6B7E', OP2 = '#7A8AA0', CONT = '#C9B48E';
const VOLC = '#8C6A4F', MAGMA = '#F76707', MAGMA_L = '#FFA94D', WATER = '#1864AB';
const f = (n) => +n.toFixed(1);
// 箭頭：直線加三角形箭頭
const arrow = (x1, y1, x2, y2, c = '#14171C') => {
  const a = Math.atan2(y2 - y1, x2 - x1), bx = x2 - 6 * Math.cos(a), by = y2 - 6 * Math.sin(a), s = 3.5;
  return `<line x1="${x1}" y1="${y1}" x2="${f(bx)}" y2="${f(by)}" stroke="${c}" stroke-width="1.6"/>`
    + `<polygon points="${x2},${y2} ${f(bx + s * Math.sin(a))},${f(by - s * Math.cos(a))} ${f(bx - s * Math.sin(a))},${f(by + s * Math.cos(a))}" fill="${c}"/>`;
};
// 彎箭頭：二次曲線，箭頭方向沿曲線末端
const curve = (x1, y1, cx, cy, x2, y2, c = '#14171C') => {
  const a = Math.atan2(y2 - cy, x2 - cx), bx = x2 - 6 * Math.cos(a), by = y2 - 6 * Math.sin(a), s = 3.5;
  return `<path d="M${x1} ${y1} Q${cx} ${cy} ${f(bx)} ${f(by)}" fill="none" stroke="${c}" stroke-width="1.6"/>`
    + `<polygon points="${x2},${y2} ${f(bx + s * Math.sin(a))},${f(by - s * Math.cos(a))} ${f(bx - s * Math.sin(a))},${f(by + s * Math.cos(a))}" fill="${c}"/>`;
};
const T = (x, y, s, o = '') => `<text x="${x}" y="${y}"${o ? ` ${o}` : ''}>${s}</text>`;
const W = 'fill="#FFFFFF"', B = 'font-weight="700"', BLUE = `fill="${WATER}"`;
const svg = (label, body) => `<svg viewBox="0 0 320 150" role="img" aria-label="${label}" xmlns="http://www.w3.org/2000/svg" font-size="12" text-anchor="middle" fill="#2A2F37">${body}</svg>`;
const conduit = (x, y1, y2) => `<rect x="${x - 1.5}" y="${y1}" width="3" height="${y2 - y1}" fill="${MAGMA}"/>`;
// 隱沒的海洋板塊（左邊往右下插）
const SLAB = `<path d="M0 50 L112 52 L128 64 C165 80 205 108 250 150 L212 150 C175 114 140 90 104 78 L0 76 Z" fill="${OP}"/>`;
const WET = `${arrow(222, 128, 230, 113, WATER)}${T(278, 132, '板塊帶下去的水', BLUE)}${T(278, 145, '讓地函熔融', BLUE)}`;

export const DIAGRAM = {
  ridge: svg('中洋脊剖面示意圖', `<rect width="320" height="150" fill="${MANTLE}"/>
    <path d="M0 0 H320 V64 L215 58 L178 50 L166 44 L154 44 L142 50 L105 58 L0 64 Z" fill="${SEA}"/>
    <path d="M0 64 L105 58 L142 50 L154 44 L158 44 L158 58 L110 78 L0 96 Z" fill="${OP}"/>
    <path d="M320 64 L215 58 L178 50 L166 44 L162 44 L162 58 L210 78 L320 96 Z" fill="${OP}"/>
    <ellipse cx="160" cy="66" rx="16" ry="7" fill="${MAGMA_L}"/>${conduit(160, 44, 62)}
    ${arrow(160, 132, 160, 84)}${curve(150, 120, 120, 104, 72, 112)}${curve(170, 120, 200, 104, 248, 112)}
    ${arrow(122, 32, 62, 32)}${arrow(198, 32, 258, 32)}
    ${T(160, 24, '中洋脊', B)}${T(92, 22, '板塊分開')}${T(228, 22, '板塊分開')}
    ${T(52, 84, '海洋板塊', W)}${T(268, 84, '海洋板塊', W)}${T(160, 146, '地函上湧、壓力變小而熔融')}`),

  rift: svg('大陸裂谷剖面示意圖', `<rect width="320" height="150" fill="${MANTLE}"/><rect width="320" height="60" fill="${SKY}"/>
    <path d="M0 40 L122 40 L140 58 L180 58 L198 40 L320 40 L320 96 L210 94 L160 80 L110 94 L0 96 Z" fill="${CONT}"/>
    <path d="M122 40 L148 94 M198 40 L172 94" stroke="#7A6648" stroke-width="1.2" stroke-dasharray="3 2" fill="none"/>
    <ellipse cx="160" cy="86" rx="18" ry="7" fill="${MAGMA_L}"/>${conduit(160, 46, 82)}
    <path d="M147 58 L156 45 L164 45 L173 58 Z" fill="${VOLC}"/>
    ${arrow(104, 28, 50, 28)}${arrow(216, 28, 270, 28)}${arrow(160, 140, 160, 100)}
    ${T(160, 32, '裂谷', B)}${T(77, 20, '地殼被拉開')}${T(243, 20, '地殼被拉開')}
    ${T(60, 74, '大陸板塊')}${T(260, 74, '大陸板塊')}${T(240, 128, '地函上湧、減壓熔融')}`),

  hotspot: svg('熱點剖面示意圖', `<rect width="320" height="150" fill="${MANTLE}"/><rect width="320" height="30" fill="${SKY}"/>
    <rect y="30" width="320" height="32" fill="${SEA}"/><rect y="62" width="320" height="28" fill="${OP}"/>
    <path d="M222 150 C222 125 224 112 210 104 C218 96 242 96 250 104 C236 112 238 125 238 150 Z" fill="${MAGMA_L}"/>
    ${conduit(230, 24, 100)}
    <path d="M196 62 L224 22 L236 22 L264 62 Z" fill="${VOLC}"/>
    <path d="M134 62 L153 26 L159 26 L178 62 Z" fill="${VOLC}" opacity=".85"/>
    <path d="M80 62 L95 42 L101 42 L116 62 Z" fill="${VOLC}" opacity=".7"/>
    <path d="M30 62 L41 50 L45 50 L56 62 Z" fill="${VOLC}" opacity=".55"/>
    ${arrow(190, 72, 110, 72, '#FFFFFF')}${T(150, 85, '板塊移動', W)}
    ${T(230, 14, '正在噴發', B)}${T(98, 20, '← 越往左越老、越小')}${T(150, 128, '熱點（地函柱）→')}`),

  sub: svg('隱沒帶（海洋板塊插到大陸板塊下）剖面示意圖', `<rect width="320" height="150" fill="${MANTLE}"/><rect width="320" height="30" fill="${SKY}"/>
    <path d="M0 30 H148 L128 64 L112 52 L0 50 Z" fill="${SEA}"/>
    <path d="M128 64 L148 30 L170 24 L320 24 L320 92 L210 82 L150 70 Z" fill="${CONT}"/>${SLAB}
    ${conduit(240, 8, 100)}<ellipse cx="240" cy="104" rx="11" ry="7" fill="${MAGMA_L}"/>
    <path d="M222 24 L236 6 L244 6 L258 24 Z" fill="${VOLC}"/>
    ${arrow(28, 58, 88, 59, '#FFFFFF')}${T(58, 71, '海洋板塊', W)}${T(118, 44, '海溝')}
    ${T(290, 50, '大陸板塊')}${T(286, 16, '火山', B)}${WET}`),

  arc: svg('島弧（海洋板塊插到海洋板塊下）剖面示意圖', `<rect width="320" height="150" fill="${MANTLE}"/><rect width="320" height="30" fill="${SKY}"/>
    <rect y="30" width="320" height="40" fill="${SEA}"/>
    <path d="M128 64 L150 50 L320 48 L320 74 L200 74 L150 70 Z" fill="${OP2}"/>${SLAB}
    ${conduit(237, 20, 100)}<ellipse cx="238" cy="104" rx="11" ry="7" fill="${MAGMA_L}"/>
    <path d="M214 50 L232 18 L242 18 L260 50 Z" fill="${VOLC}"/>
    ${arrow(28, 58, 88, 59, '#FFFFFF')}${T(58, 71, '海洋板塊', W)}${T(118, 44, '海溝')}
    ${T(290, 66, '海洋板塊', W)}${T(237, 12, '火山島（島弧）', B)}${WET}`),

  backarc: svg('弧後張裂剖面示意圖（以琉球隱沒帶與沖繩海槽為例）', `<rect width="320" height="150" fill="${MANTLE}"/><rect width="320" height="28" fill="${SKY}"/>
    <rect y="28" width="320" height="34" fill="${SEA}"/>
    <path d="M0 24 L40 24 L82 50 L100 54 L118 50 L160 34 L198 34 L250 62 L226 72 L180 76 L130 66 L100 62 L70 70 L0 80 Z" fill="${CONT}"/>
    <path d="M320 54 L262 56 L250 62 C215 78 180 106 140 150 L178 150 C210 116 236 92 270 80 L320 78 Z" fill="${OP}"/>
    ${conduit(177, 16, 92)}<ellipse cx="178" cy="96" rx="10" ry="6" fill="${MAGMA_L}"/>
    <path d="M160 34 L172 15 L182 15 L196 34 Z" fill="${VOLC}"/>
    <ellipse cx="100" cy="68" rx="14" ry="5" fill="${MAGMA_L}"/>${conduit(100, 48, 66)}
    <path d="M92 54 L98 46 L102 46 L108 54 Z" fill="${VOLC}"/>
    ${arrow(92, 20, 62, 20)}${arrow(108, 20, 138, 20)}${arrow(312, 66, 272, 69, '#FFFFFF')}
    ${T(100, 11, '沖繩海槽（張裂）', B)}${T(177, 9, '琉球島弧', B)}${T(262, 44, '琉球海溝')}
    ${T(30, 62, '歐亞板塊')}${T(282, 96, '菲律賓海板塊')}${T(100, 90, '地殼變薄')}`),
};
