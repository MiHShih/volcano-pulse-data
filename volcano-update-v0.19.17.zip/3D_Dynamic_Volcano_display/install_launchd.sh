#!/bin/bash
# 安裝每日自動更新與發布（macOS launchd）。用法：./install_launchd.sh [HH:MM]，預設 09:00（本機時間）
# update.py 失敗時照樣跑 publish.py：data/ 保留的是上一份完整資料，publish.py 會再檢查一次
# 最後跑 tools/make_patches.py（B 版近看的預算圖）：只補新火山，每 28 天檢查一次來源；需要專案的 .venv（numpy、Pillow），沒有就略過
set -euo pipefail

TIME="${1:-09:00}"
[[ "$TIME" =~ ^([01]?[0-9]|2[0-3]):([0-5][0-9])$ ]] || { echo "時間格式應為 HH:MM，例如 09:00" >&2; exit 1; }
HOUR=$((10#${BASH_REMATCH[1]})); MIN=$((10#${BASH_REMATCH[2]}))

DIR="$(cd "$(dirname "$0")" && pwd)"
LABEL="local.volcano-globe.update"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
PY="$(command -v python3)" || { echo "找不到 python3" >&2; exit 1; }

# launchd 不會讀 shell 設定檔，要自己給 PATH 才找得到 claude（原生安裝在 ~/.local/bin）
RUN_PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin"
for c in $(which -a claude 2>/dev/null); do
  case "$c" in *cmux-cli-shims*) ;; *) RUN_PATH="$(dirname "$c"):$RUN_PATH" ;; esac  # cmux shim 只在 cmux 內有效
done

mkdir -p "$HOME/Library/LaunchAgents" "$DIR/data"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>$LABEL</string>
  <key>ProgramArguments</key>
  <array><string>/bin/sh</string><string>-c</string><string>"$PY" update.py; "$PY" publish.py; if [ -x .venv/bin/python ]; then .venv/bin/python tools/make_patches.py; else echo "沒有 .venv，略過地形預算圖"; fi</string></array>
  <key>WorkingDirectory</key><string>$DIR</string>
  <key>EnvironmentVariables</key>
  <dict><key>PATH</key><string>$RUN_PATH</string></dict>
  <key>StartCalendarInterval</key>
  <dict><key>Hour</key><integer>$HOUR</integer><key>Minute</key><integer>$MIN</integer></dict>
  <key>StandardOutPath</key><string>$DIR/data/launchd.log</string>
  <key>StandardErrorPath</key><string>$DIR/data/launchd.log</string>
</dict>
</plist>
EOF

launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"
printf '已安裝：每天 %02d:%02d（本機時間）執行 update.py、publish.py（沒有 publish.json 時不發布），再補地形預算圖\n' "$HOUR" "$MIN"
echo "設定檔：$PLIST"
echo "立刻手動跑一次：launchctl kickstart gui/$(id -u)/$LABEL"
