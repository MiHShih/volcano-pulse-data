// 太陽、月亮與五顆肉眼可見行星的地心方向（赤經、赤緯，J2000 赤道座標，單位度），給星空背景用。
// 行星與地球：JPL 行星近似軌道根數 Table 1（Standish & Williams 1992，適用 1800 到 2050 年，
//   日心經度誤差 15″ 到 600″），https://ssd.jpl.nasa.gov/planets/approx_pos.html
// 月亮：天文年曆（Astronomical Almanac）的低精度公式，誤差約 0.3°。
// 地心與地月質心的差別（約 4,700 km）忽略。檢查：node tools/check_ephem.mjs
const RAD = Math.PI / 180;
const EPS = 23.43928 * RAD;  // J2000 黃赤交角

// 每列：[a (au), e, I, L, 近日點經度, 升交點經度]（度）與每世紀變化率
const EL = {
  mercury: [[0.38709927, 0.20563593, 7.00497902, 252.25032350, 77.45779628, 48.33076593],
    [0.00000037, 0.00001906, -0.00594749, 149472.67411175, 0.16047689, -0.12534081]],
  venus: [[0.72333566, 0.00677672, 3.39467605, 181.97909950, 131.60246718, 76.67984255],
    [0.00000390, -0.00004107, -0.00078890, 58517.81538729, 0.00268329, -0.27769418]],
  earth: [[1.00000261, 0.01671123, -0.00001531, 100.46457166, 102.93768193, 0.0],
    [0.00000562, -0.00004392, -0.01294668, 35999.37244981, 0.32327364, 0.0]],
  mars: [[1.52371034, 0.09339410, 1.84969142, -4.55343205, -23.94362959, 49.55953891],
    [0.00001847, 0.00007882, -0.00813131, 19140.30268499, 0.44441088, -0.29257343]],
  jupiter: [[5.20288700, 0.04838624, 1.30439695, 34.39644051, 14.72847983, 100.47390909],
    [-0.00011607, -0.00013253, -0.00183714, 3034.74612775, 0.21252668, 0.20469106]],
  saturn: [[9.53667594, 0.05386179, 2.48599187, 49.95424423, 92.59887831, 113.66242448],
    [-0.00125060, -0.00050991, 0.00193609, 1222.49362201, -0.41897216, -0.28867794]],
};

// 日心黃道座標（J2000，au）
function helio(k, T) {
  const [e0, rate] = EL[k];
  const [a, e, I, L, w, O] = e0.map((x, i) => x + rate[i] * T);
  const M = (((((L - w) % 360) + 540) % 360) - 180) * RAD;
  let E = M + e * Math.sin(M);
  for (let i = 0; i < 6; i++) E -= (E - e * Math.sin(E) - M) / (1 - e * Math.cos(E));  // 克卜勒方程式（牛頓法）
  const xp = a * (Math.cos(E) - e), yp = a * Math.sqrt(1 - e * e) * Math.sin(E);
  const om = (w - O) * RAD, co = Math.cos(om), so = Math.sin(om);
  const cO = Math.cos(O * RAD), sO = Math.sin(O * RAD), cI = Math.cos(I * RAD), sI = Math.sin(I * RAD);
  return [(co * cO - so * sO * cI) * xp + (-so * cO - co * sO * cI) * yp,
    (co * sO + so * cO * cI) * xp + (-so * sO + co * cO * cI) * yp,
    so * sI * xp + co * sI * yp];
}

// 月亮的地心黃道方向（單位向量）
function moon(T) {
  const s = (a, b) => Math.sin((a + b * T) * RAD);
  const lam = 218.32 + 481267.881 * T + 6.29 * s(135.0, 477198.87) - 1.27 * s(259.3, -413335.36) + 0.66 * s(235.7, 890534.22)
    + 0.21 * s(269.9, 954397.74) - 0.19 * s(357.5, 35999.05) - 0.11 * s(186.5, 966404.03)
    - 1.397 * T;  // 公式是當天的分點，減去歲差改回 J2000
  const bet = 5.13 * s(93.3, 483202.02) + 0.28 * s(228.2, 960400.89) - 0.28 * s(318.3, 6003.15) - 0.17 * s(217.6, -407332.21);
  const l = lam * RAD, b = bet * RAD;
  return [Math.cos(b) * Math.cos(l), Math.cos(b) * Math.sin(l), Math.sin(b)];
}

// 黃道座標轉赤經、赤緯（度）
function radec([x, y, z]) {
  const ye = y * Math.cos(EPS) - z * Math.sin(EPS), ze = y * Math.sin(EPS) + z * Math.cos(EPS);
  return { ra: ((Math.atan2(ye, x) / RAD) + 360) % 360, dec: Math.atan2(ze, Math.hypot(x, ye)) / RAD };
}

export const BODIES = [
  ['sun', '太陽'], ['moon', '月亮'], ['mercury', '水星'], ['venus', '金星'], ['mars', '火星'], ['jupiter', '木星'], ['saturn', '土星'],
];

// ms：Unix 時間（毫秒）→ [{ key, zh, ra, dec }]
export function bodies(ms) {
  const T = (ms / 864e5 + 2440587.5 - 2451545.0) / 36525;
  const earth = helio('earth', T);
  const geo = (k) => (k === 'sun' ? earth.map((v) => -v) : k === 'moon' ? moon(T) : helio(k, T).map((v, i) => v - earth[i]));
  return BODIES.map(([key, zh]) => ({ key, zh, ...radec(geo(key)) }));
}
