// A 版地圖：MapLibre GL JS 地球＋3D 地形（AWS Terrain Tiles，Terrarium 格式）。
// vendor/terrain 有全球低層級與火山周邊的精細圖磚（清單在 local.json），本機沒有的才向 AWS 讀取。
import * as maplibregl from './vendor/maplibre/maplibre-gl.mjs';
import { createStars, subsolar, capRing } from './stars.js';
import { PLATE_KINDS, QUAKE_DEPTHS, loadGeo } from './geo.js';

const REMOTE = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png';
// 衛星影像：EOX Sentinel-2 cloudless 2016 年版（CC BY 4.0，任何用途都可以，須註明出處）。2018 年以後的版本是 CC BY-NC-SA，
// EOX 不把政府機關的使用算成非商業用途，要換新版先跟 EOX（cloudless@eox.at）確認，再把 s2cloudless_3857 改成例如 s2cloudless-2025_3857
const SAT = 'https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless_3857/default/g/{z}/{y}/{x}.jpg';
const SAT_CREDIT = '衛星影像：EOxCloudless https://cloudless.eox.at by EOX IT Services GmbH（Contains modified Copernicus Sentinel data 2016）';
const EXAGGERATION = 1.6;
const PAL_KEY = 'volcano-globe.palette';
// 地形配色。z11 以上的圖磚海面一律是 0 m（沒有水深），所以每組都讓 0 m 算水域、1 m 以上才是陸地。
// stops：海拔 (m) 與顏色交錯；shade：hillshade 的陰影、亮面、輪廓色；bg：地球外圍背景
const PALETTES = [
  { key: 'mist', label: '霧白深海（原配色）', swatch: ['#0F2847', '#285886', '#EDECE8'],
    bg: 'radial-gradient(circle at 50% 45%, #F7F8F9 0%, #E6E9EC 70%, #DCE0E4 100%)',
    stops: [-8000, '#0A1C33', -4000, '#0F2847', -1500, '#16375E', -200, '#1E4772', -1, '#285886', 0, '#285886',
      1, '#F3F2EE', 600, '#EDECE8', 2000, '#E4E2DD', 4000, '#ECEBE8', 6000, '#FFFFFF'],
    shade: ['rgba(52,60,72,0.55)', 'rgba(255,255,255,0.45)', 'rgba(52,60,72,0.25)'] },
  { key: 'clay', label: '黏土模型', swatch: ['#AEBDCC', '#D8E0E8', '#F2EFEA'],
    bg: 'radial-gradient(circle at 50% 45%, #FAF9F7 0%, #EEEDEA 70%, #E5E3DF 100%)',
    stops: [-8000, '#9FB0C2', -4000, '#AEBDCC', -1500, '#BFCAD6', -200, '#CFD8E1', -1, '#D8E0E8', 0, '#D8E0E8',
      1, '#F7F5F1', 800, '#F2EFEA', 2500, '#ECE8E2', 6000, '#FFFFFF'],
    shade: ['rgba(96,88,80,0.55)', 'rgba(255,255,255,0.55)', 'rgba(96,88,80,0.25)'] },
  { key: 'hypso', label: '經典分層設色', swatch: ['#36689A', '#A9C79B', '#D9BE91'],
    bg: 'radial-gradient(circle at 50% 45%, #F6F9FC 0%, #E4EBF2 70%, #D9E2EB 100%)',
    stops: [-8000, '#24507A', -4000, '#36689A', -1500, '#5B8DBD', -200, '#93BCDD', -1, '#B9D6EC', 0, '#B9D6EC',
      1, '#A9C79B', 300, '#C8D8A2', 800, '#E4DDA9', 1500, '#D9BE91', 2500, '#BE9A7C', 3500, '#C9B5A8', 5000, '#F2EEEA', 6000, '#FFFFFF'],
    shade: ['rgba(60,55,50,0.45)', 'rgba(255,255,255,0.35)', 'rgba(60,55,50,0.2)'] },
  { key: 'paper', label: '紙本地圖', swatch: ['#5F7F88', '#C2D5D4', '#E5D9C0'],
    bg: 'radial-gradient(circle at 50% 45%, #FAF7F1 0%, #EEE8DC 70%, #E6DFD1 100%)',
    stops: [-8000, '#4D6C75', -4000, '#5F7F88', -1500, '#7E9DA3', -200, '#A8C1C3', -1, '#C2D5D4', 0, '#C2D5D4',
      1, '#EEE7D7', 800, '#E5D9C0', 2000, '#D8C6A6', 3500, '#CFBCA8', 5000, '#F3EFE8', 6000, '#FFFFFF'],
    shade: ['rgba(84,64,46,0.5)', 'rgba(255,250,240,0.4)', 'rgba(84,64,46,0.22)'] },
];
const palOf = (k) => PALETTES.find((p) => p.key === k) || PALETTES[0];
const reliefColor = (p) => ['interpolate', ['linear'], ['elevation'], ...p.stops];

async function online() {
  try {
    const c = new AbortController();
    const t = setTimeout(() => c.abort(), 4000);
    const r = await fetch(REMOTE.replace('{z}/{x}/{y}', '6/56/25'), { signal: c.signal, cache: 'no-store' });
    clearTimeout(t);
    return r.ok;
  } catch {
    return false;
  }
}

// 鏡頭飛行時間（飛向火山、切換區域、進出待機）與待機自轉速度：預設 3 秒、4 分鐘一圈，
// 設定頁（app.js）用 motion() 改；app.js 的待機導覽也照 flyMs 計時
let flyMs = 3000, spinMin = 4;
// 點火山時拉近的程度（設定頁「拉近程度」，縮放級數 6 到 14，預設 12.5 近景）；傾斜角度跟著拉近程度，越近越斜，最多 60°
const NEAR_RANGE = [6, 14];
let nearZoom = 12.5;
const pitchFor = (z) => Math.min(60, Math.max(0, (z - 7) * 10));

export async function createMap(el, o) {
  const [isOnline, local] = await Promise.all([online(), fetch('vendor/terrain/local.json').then((r) => (r.ok ? r.json() : null)).catch(() => null)]);
  const LOCAL_MAX = local?.maxzoom ?? 6;
  const extra = new Set(local?.extra || []);
  let saved = null;
  try { saved = localStorage.getItem(PAL_KEY); } catch { /* 私密視窗等情況讀不到，用預設配色 */ }
  const pal = palOf(saved);
  // 全球視角：地球直徑約為地圖框短邊的 80%
  const worldZoom = Math.log2((0.8 * Math.min(el.clientWidth, el.clientHeight) * Math.PI) / 512);
  // 離線時，本機沒有的精細圖磚會載入失敗，MapLibre 會改用上一層的圖磚顯示
  const dem = { type: 'raster-dem', tiles: [REMOTE], tileSize: 256, encoding: 'terrarium', maxzoom: isOnline ? 12 : (local?.extraMaxzoom ?? LOCAL_MAX) };
  // 高解析地形（設定頁開關，預設關）：改讀到 AWS 最細的 z15。美國等原始資料精細的地方更清楚，
  // 但部分地區（例如埃特納）的圖磚有方塊色差，所以平常只讀到 z12。沒用到的來源不會下載
  const demHi = { ...dem, maxzoom: 15 };
  const map = new maplibregl.Map({
    container: el,
    attributionControl: false,
    center: [150, 15],
    zoom: worldZoom,
    minZoom: 0.8,
    maxZoom: 14,  // 地形到 z12（火山周邊 15 km 內在本機），再拉近是放大顯示；衛星影像到 z14
    maxPitch: 70,
    // 國名與板塊名稱都是中文，由瀏覽器字型直接畫，不用下載字型檔；glyphs 只是 MapLibre 規定要有（tools/make_geo.py 確認名稱沒有英文字）
    localIdeographFontFamily: '"PingFang TC", "Noto Sans TC", "Noto Sans CJK TC", "Microsoft JhengHei", sans-serif',
    style: {
      version: 8,
      glyphs: `${location.href.replace(/[^/]*$/, '')}vendor/glyphs/{fontstack}/{range}.pbf`,
      projection: { type: 'globe' },
      sky: { 'atmosphere-blend': ['interpolate', ['linear'], ['zoom'], 0, 0.55, 4, 0.25, 6, 0] },
      sources: { dem, terrainDem: { ...dem }, demHi, terrainDemHi: { ...demHi }, sat: { type: 'raster', tiles: [SAT], tileSize: 256, maxzoom: 14 } },
      layers: [
        { id: 'relief', type: 'color-relief', source: 'dem', paint: { 'color-relief-color': reliefColor(pal) } },
        // 衛星影像只在拉近時淡入（z7 到 z9），遠看維持地形配色；陰影疊在上面讓起伏更明顯。離線時讀不到，自動看到底下的地形配色
        { id: 'sat', type: 'raster', source: 'sat', paint: { 'raster-opacity': ['interpolate', ['linear'], ['zoom'], 7, 0, 9, 1] } },
        { id: 'shade', type: 'hillshade', source: 'dem', paint: {
          'hillshade-method': 'multidirectional',
          'hillshade-exaggeration': 0.6,
          'hillshade-shadow-color': pal.shade[0],
          'hillshade-highlight-color': pal.shade[1],
          'hillshade-accent-color': pal.shade[2] } },
      ],
      terrain: { source: 'terrainDem', exaggeration: EXAGGERATION },
    },
    // 本機有的圖磚改讀專案內的檔案
    transformRequest: (url) => {
      const m = url.match(/terrarium\/(\d+)\/(\d+)\/(\d+)\.png$/);
      const here = m && (+m[1] <= LOCAL_MAX || extra.has(`${m[1]}/${m[2]}/${m[3]}`));
      return here ? { url: new URL(`vendor/terrain/${m[1]}/${m[2]}/${m[3]}.png`, location.href).href } : { url };
    },
  });
  await new Promise((resolve, reject) => { map.once('load', resolve); map.once('error', (e) => reject(e.error || e)); });

  // 沒有近期活動的火山：灰色小噴煙圖示（app.js 的 ico('none')，32 px 當成 2 倍解析度）
  const img = new Image(32, 32);
  img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(o.dotIcon)}`;
  await img.decode();
  map.addImage('vol-ico', img, { pixelRatio: 2 });
  map.addSource('vol', { type: 'geojson', data: { type: 'FeatureCollection', features: o.dots.map((v) => ({
    type: 'Feature', properties: { v: v.vnum, n: v.zh ? `${v.name} ${v.zh}` : v.name }, geometry: { type: 'Point', coordinates: [v.lon, v.lat] } })) } });
  // 白天與黑夜（待機背景的開關，app.js 決定什麼時候顯示）：黑夜是以太陽正對面為中心的球冠，由大到小疊 24 層半透明
  // （太陽在地平線下 0° 到 18°，每層差約 0.8°），每層只加深約 4%，晨昏線是平順的漸層、看不出一圈一圈；
  // 在火山圖示與板塊等圖層底下，拉近到 z3 以上淡出
  const NIGHT_N = 24, NIGHT_MAX = 0.61;  // 最深處約 61%
  const NIGHT_A = 1 - (1 - NIGHT_MAX) ** (1 / NIGHT_N);
  const NIGHT_R = Array.from({ length: NIGHT_N }, (_, i) => 90 - (18 * i) / (NIGHT_N - 1));
  const nightData = () => {
    const s = subsolar(Date.now());
    return { type: 'FeatureCollection', features: NIGHT_R.map((r) => ({ type: 'Feature', properties: {},
      geometry: { type: 'Polygon', coordinates: [capRing(-s.lat, s.lon + 180, r)] } })) };
  };
  map.addSource('night', { type: 'geojson', data: { type: 'FeatureCollection', features: [] } });
  map.addLayer({ id: 'night', type: 'fill', source: 'night', layout: { visibility: 'none' },
    paint: { 'fill-color': '#030714', 'fill-antialias': false, 'fill-opacity': ['interpolate', ['linear'], ['zoom'], 3, NIGHT_A, 5, 0] } });
  let nightT = 0;
  map.addLayer({ id: 'vol', type: 'symbol', source: 'vol', layout: {
    'icon-image': 'vol-ico',
    'icon-size': ['interpolate', ['linear'], ['zoom'], 1, 0.5, 4, 0.8, 7, 1.2, 10, 1.6],
    'icon-allow-overlap': true, 'icon-ignore-placement': true } });
  const tip = new maplibregl.Popup({ closeButton: false, closeOnClick: false, offset: 10, className: 'tip' });
  map.on('mouseenter', 'vol', () => { map.getCanvas().style.cursor = 'pointer'; });
  map.on('mousemove', 'vol', (e) => tip.setLngLat(e.lngLat).setText(e.features[0].properties.n).addTo(map));
  map.on('mouseleave', 'vol', () => { map.getCanvas().style.cursor = ''; tip.remove(); });
  map.on('click', 'vol', (e) => o.onSelect(e.features[0].properties.v));

  // 有活動的火山與十年火山：圖釘；被地形或地球背面擋住時隱藏
  // subpixelPositioning：不四捨五入到整數像素，慢慢自轉時圖釘才不會一跳一跳
  const add = (v) => new maplibregl.Marker({ element: o.makePin(v), anchor: 'center', opacityWhenCovered: '0', subpixelPositioning: true }).setLngLat([v.lon, v.lat]).addTo(map);
  const pinMarkers = o.pins.map(add);
  let selMarker = null;
  // 拉近時選取的火山（點選或待機導覽）一定要看得到名稱：火山位置被前面的山擋住時 MapLibre 會把整個標記藏起來，
  // 但名稱已用引線提到山頂上方，所以拉近時選取的標記被擋住也照樣顯示；拉遠時照舊隱藏（地球背面的不能透出來）
  const showSel = () => [...pinMarkers, ...(selMarker ? [selMarker] : [])].forEach((m) =>
    m.setOpacity('1', nearNow && m.getElement().classList.contains('sel') ? '1' : '0'));
  // 全球視角的星空背景（stars.js）：地球固定座標 x 指向經度 0°、z 指向北極；相機方向由地圖中心、方位角、傾角算出
  const D = Math.PI / 180;
  const stars = await createStars(el, {
    dir: (lat, lon) => [Math.cos(lat * D) * Math.cos(lon * D), Math.cos(lat * D) * Math.sin(lon * D), Math.sin(lat * D)],
    view: () => {
      const c = map.getCenter(), la = c.lat * D, lo = c.lng * D, b = map.getBearing() * D, p = map.getPitch() * D;
      const mix = (u, ku, w, kw) => u.map((x, i) => x * ku + w[i] * kw);
      const U = [Math.cos(la) * Math.cos(lo), Math.cos(la) * Math.sin(lo), Math.sin(la)];  // 地圖中心的天頂
      const E = [-Math.sin(lo), Math.cos(lo), 0];
      const N = [-Math.sin(la) * Math.cos(lo), -Math.sin(la) * Math.sin(lo), Math.cos(la)];
      const S = mix(N, Math.cos(b), E, Math.sin(b));  // 畫面上方對應的地面方向
      return { right: mix(E, Math.cos(b), N, -Math.sin(b)), up: mix(U, Math.sin(p), S, Math.cos(p)), fwd: mix(U, -Math.cos(p), S, Math.sin(p)),
        fov: map.getVerticalFieldOfView?.() || map.transform?.fov || 36.87 };
    },
  });

  // 拉近到 NAME_Z 以上只顯示火山名稱、不顯示圖示，才看得清楚地形：圖釘由 app.css 的 .near 藏起來只留標籤，
  // 其他火山的小圖示圖層關掉，改成畫面範圍內的名稱標籤（點了一樣打開詳細卡）
  // 名稱標籤（app.js 的 nameEl）以底部對齊火山位置
  const NAME_Z = 9, NAME_MAX = 80;
  let names = [], nearNow = false;
  const refreshNames = () => {
    names.forEach((m) => m.remove());
    names = [];
    if (!nearNow) return;
    const b = map.getBounds();
    for (const v of o.dots) {
      if (names.length >= NAME_MAX) break;
      if (v.vnum !== selMarker?.vnum && b.contains([v.lon, v.lat])) {  // 選取的火山已經有圖釘標籤
        names.push(new maplibregl.Marker({ element: o.makeName(v), anchor: 'bottom', opacityWhenCovered: '0', subpixelPositioning: true })
          .setLngLat([v.lon, v.lat]).addTo(map));
      }
    }
  };
  map.on('moveend', refreshNames);

  // 圖釘跟著縮放變大變小：全球 0.7 倍，到 z7 左右最大約 1.4 倍；再拉近看火山時縮回 0.8 倍，不擋住山頂
  const far = () => {
    const z = map.getZoom();
    o.onFar(z < 3);
    if ((z >= NAME_Z) !== nearNow) {
      nearNow = z >= NAME_Z;
      o.onNear?.(nearNow);
      map.setLayoutProperty('vol', 'visibility', nearNow ? 'none' : 'visible');
      refreshNames();
      showSel();
    }
    const k = z <= 7 ? 0.7 + (z - 1.4) * 0.12 : 1.37 - (z - 7) * 0.143;
    el.style.setProperty('--pz', Math.min(1.5, Math.max(0.7, k)).toFixed(2));
  };
  map.on('zoom', far);
  far();
  map.on('dragstart', () => o.onUserMove?.());
  map.on('wheel', () => o.onUserMove?.());

  // ---- 板塊邊界、地震、國界與國名（geo.js、vendor/geo/）：第一次打開才讀檔、加圖層，都放在火山圖示底下 ----
  const GEO_LAYERS = { plates: ['plate-case', 'plate', 'plate-name'], quakes: ['quake'], borders: ['border-case', 'border', 'border-d', 'country-name'] };
  const geoOn = {};
  let geoP = null;
  const addGeo = async () => {
    const g = await loadGeo();
    if (!g) return false;
    const pts = (rows) => ({ type: 'FeatureCollection', features: rows.map(([n, x, y, z], i) => ({
      type: 'Feature', properties: { n, z: z ?? 0, i }, geometry: { type: 'Point', coordinates: [x, y] } })) });
    map.addSource('borders', { type: 'geojson', data: g.borders });
    map.addSource('plates', { type: 'geojson', data: g.plates });
    map.addSource('quakes', { type: 'geojson', data: { type: 'FeatureCollection', features: g.quakes.q.map(([x, y, d, m]) => ({
      type: 'Feature', properties: { d, m }, geometry: { type: 'Point', coordinates: [x, y] } })) } });
    map.addSource('countries', { type: 'geojson', data: pts(g.labels.countries) });
    map.addSource('plateNames', { type: 'geojson', data: pts(g.labels.plates) });
    const lay = (l) => map.addLayer({ ...l, layout: { visibility: 'none', ...l.layout } }, 'vol');
    const w = (a, b) => ['interpolate', ['linear'], ['zoom'], 1, a, 8, b];
    const halo = { 'text-halo-color': 'rgba(255,255,255,0.88)', 'text-halo-width': 1.5 };
    const ink = 'rgba(45,50,60,0.75)';
    lay({ id: 'border-case', type: 'line', source: 'borders', paint: { 'line-color': 'rgba(255,255,255,0.5)', 'line-width': w(1.8, 3.4) } });
    lay({ id: 'border', type: 'line', source: 'borders', filter: ['!', ['has', 'd']], paint: { 'line-color': ink, 'line-width': w(0.6, 1.4) } });
    // 有爭議、未定或實際控制線：虛線
    lay({ id: 'border-d', type: 'line', source: 'borders', filter: ['has', 'd'], paint: { 'line-color': ink, 'line-width': w(0.6, 1.4), 'line-dasharray': [3, 2] } });
    // 地震：顏色是深度，大小是規模（規模 5.5 半徑約 1.5 像素，每大 1 級約 1.8 倍，拉近再放大）
    const r = (k) => ['*', k * 1.5, ['^', 1.8, ['-', ['get', 'm'], 5.5]]];
    lay({ id: 'quake', type: 'circle', source: 'quakes', paint: {
      'circle-color': ['step', ['get', 'd'], QUAKE_DEPTHS[0].color, QUAKE_DEPTHS[0].max, QUAKE_DEPTHS[1].color, QUAKE_DEPTHS[1].max, QUAKE_DEPTHS[2].color],
      'circle-radius': ['interpolate', ['linear'], ['zoom'], 1, r(0.8), 5, r(1.2), 9, r(2)],
      'circle-opacity': 0.75, 'circle-stroke-width': 0.4, 'circle-stroke-color': 'rgba(255,255,255,0.7)' } });
    lay({ id: 'plate-case', type: 'line', source: 'plates', layout: { 'line-join': 'round', 'line-cap': 'round' }, paint: { 'line-color': 'rgba(255,255,255,0.75)', 'line-width': w(3.4, 6) } });
    lay({ id: 'plate', type: 'line', source: 'plates', layout: { 'line-join': 'round', 'line-cap': 'round' },
      paint: { 'line-color': ['match', ['get', 't'], ...PLATE_KINDS.flatMap((k) => [k.key, k.color]), '#000000'], 'line-width': w(1.8, 3.4) } });
    // 國名照 Natural Earth 建議的縮放級數出現，大國先放；跟別的字重疊時 MapLibre 自動不畫
    lay({ id: 'country-name', type: 'symbol', source: 'countries', filter: ['>=', ['zoom'], ['get', 'z']],
      layout: { 'text-field': ['get', 'n'], 'text-size': 12, 'symbol-sort-key': ['get', 'i'] }, paint: { 'text-color': '#2A2F37', ...halo } });
    lay({ id: 'plate-name', type: 'symbol', source: 'plateNames',
      layout: { 'text-field': ['get', 'n'], 'text-size': 14, 'text-font': ['Noto Sans Bold'], 'text-letter-spacing': 0.2 }, paint: { 'text-color': '#5F3DC4', ...halo } });
    return true;
  };
  // k：plates／quakes／borders；讀不到資料時回傳 false
  const setGeo = async (k, on) => {
    geoOn[k] = on;
    if (on) geoP ||= addGeo();
    if (!geoP || !(await geoP)) return !on;
    for (const id of GEO_LAYERS[k]) map.setLayoutProperty(id, 'visibility', geoOn[k] ? 'visible' : 'none');
    return true;
  };

  // ---- 3D 地形貼不上去時自動退回（v0.19.15）----
  // 有台 Windows 開 3D 地形時地球整片透明：配色與陰影要先畫到暫存畫布再貼到地形網格上，那台的顯示卡這一步失敗
  // （Mac 上模擬暫存畫布建不起來，畫面一模一樣）。開機後讀地球中心附近 5 點：透明就關掉 3D 起伏（配色、陰影照畫），
  // 還是透明就換地形貼圖版。readPixels 在 render 事件裡讀（同一格剛畫完，不需要 preserveDrawingBuffer）
  let flat = false;
  const gl = map.painter.context.gl;  // MapLibre 內部屬性，升級 MapLibre 時要確認還在
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const settled = (ms) => Promise.race([new Promise((r) => map.once('idle', r)), sleep(ms)]);  // 地圖在動時不會 idle，最多等 ms
  const seeThrough = () => new Promise((r) => {
    map.once('render', () => {
      const w = gl.drawingBufferWidth, h = gl.drawingBufferHeight, px = new Uint8Array(4);
      let n = 0;
      for (const [fx, fy] of [[0.5, 0.5], [0.4, 0.45], [0.6, 0.45], [0.45, 0.6], [0.55, 0.6]]) {
        gl.readPixels(Math.round(w * fx), Math.round(h * fy), 1, 1, gl.RGBA, gl.UNSIGNED_BYTE, px);
        if (px[3] < 128) n++;
      }
      r(n >= 4);
    });
    map.triggerRepaint();
  });
  // 隔 2 秒兩次都透明才算，避免圖磚還沒畫上去時誤判
  const gone = async () => {
    await settled(20000);
    if (!(await seeThrough())) return false;
    await sleep(2000);
    return seeThrough();
  };
  gone().then(async (bad) => {
    if (!bad) return;
    flat = true;
    map.setTerrain(null);
    console.warn('3D 地形貼不上去（地球表面透明），已關掉 3D 起伏');
    try { o.onFlat?.(); } catch (e) { console.error(e); }
    if (await gone()) location.replace('relief.html?auto=3d');
  }).catch((e) => console.error(e));

  // 切換高解析地形：地形與陰影、配色兩個圖層改用另一組來源（圖層的來源不能直接改，移除後原樣加回同一個位置）
  let hiNow = false;
  const setHi = (on) => {
    if (on === hiNow || !isOnline) return;
    hiNow = on;
    for (const id of ['relief', 'shade']) {
      const ls = map.getStyle().layers, i = ls.findIndex((l) => l.id === id);
      map.removeLayer(id);
      map.addLayer({ ...ls[i], source: on ? 'demHi' : 'dem' }, ls[i + 1]?.id);
    }
    if (!flat) map.setTerrain({ source: on ? 'terrainDemHi' : 'terrainDem', exaggeration: EXAGGERATION });
  };

  let tilted = false, spinId = 0;
  return {
    // 待機時慢慢轉：地圖中心往西移，看起來是地球由西向東自轉，spinMin 分鐘一圈
    spin(on) {
      cancelAnimationFrame(spinId);
      if (!on) return;
      // 跟 B 版一樣量每格的間隔：超過一成的格比正常慢一半以上（例如 Raspberry Pi），就改成每兩格才轉一次；
      // 穩定的每秒 30 格比忽快忽慢的 60 格順。轉速依時間算，跳過的格不影響速度
      let t0 = performance.now(), prev = 0, half = false, odd = false;
      const gaps = [];
      const step = (t) => {
        spinId = requestAnimationFrame(step);
        if (!half) {
          if (prev) gaps.push(t - prev);
          prev = t;
          if (gaps.length >= 120) {
            const s = gaps.sort((a, b) => a - b), base = s[12];
            half = s.filter((x) => x > base * 1.5).length > 12;
            gaps.length = 0;
          }
        }
        if (half && (odd = !odd)) return;
        const c = map.getCenter();
        map.setCenter([((c.lng - ((t - t0) * 360) / (spinMin * 60000) + 540) % 360) - 180, c.lat]);
        t0 = t;
      };
      spinId = requestAnimationFrame(step);
    },
    stars: stars || undefined,  // 星空開關（app.js 的控制鈕）
    night(on) {  // 白天與黑夜：太陽每分鐘移動約 0.25°，顯示時每分鐘更新一次
      clearInterval(nightT);
      map.setLayoutProperty('night', 'visibility', on ? 'visible' : 'none');
      if (!on) return;
      const upd = () => map.getSource('night').setData(nightData());
      upd();
      nightT = setInterval(upd, 60000);
    },
    get flyMs() { return flyMs; },
    motion(m) {  // m：{ spinMin, flySec, near, sat, hidem }，自轉中改速度會馬上生效（每格依 spinMin 計算）
      if (m.flySec > 0) flyMs = m.flySec * 1000;
      if (m.spinMin > 0) spinMin = m.spinMin;
      if (m.near >= NEAR_RANGE[0] && m.near <= NEAR_RANGE[1]) nearZoom = m.near;
      if (typeof m.sat === 'boolean') map.setLayoutProperty('sat', 'visibility', m.sat ? 'visible' : 'none');
      if (typeof m.hidem === 'boolean') setHi(m.hidem);
    },
    sat: true,  // 有衛星影像可以開關
    geo: setGeo,  // 板塊邊界、地震、國界與國名的開關
    hidem: isOnline,  // 有高解析地形可以開關（離線時沒有作用，不顯示）
    nearRange: NEAR_RANGE,  // 有「拉近程度」可選
    center() { const c = map.getCenter(); return { lat: c.lat, lng: c.lng }; },  // 畫面中心（待機導覽判斷火山有沒有轉到中間）
    hint: '拖曳旋轉・滾輪縮放・右鍵拖曳傾斜',
    get note() { return flat ? '3D 起伏已自動關閉' : `地形垂直誇大 ${EXAGGERATION} 倍`; },
    get flat() { return flat; },  // 3D 起伏被自動關掉了（設定頁最下面顯示）
    credit: `地形：AWS Terrain Tiles（SRTM、GMTED2010、ETOPO1 等）・垂直誇大 ${EXAGGERATION} 倍${isOnline ? '' : '・離線模式'}・${SAT_CREDIT}`,
    terrainNote: `MapLibre GL JS 3D 地形，垂直誇大 ${EXAGGERATION} 倍。專案內有全球 z0–z${LOCAL_MAX}${extra.size ? `，以及火山周邊到 z${local.extraMaxzoom} 的 ${extra.size.toLocaleString('en-US')} 張精細圖磚` : ''}；${isOnline ? '其他地方放大時向 AWS 線上讀取（最高 z12；設定頁打開高解析地形時到 z15）。' : `目前離線，火山周邊以外的地方放大後只有 z${LOCAL_MAX} 的解析度。`}海拔 1 m 以下顯示成水色，所以低於海平面的陸地窪地也會是水色；放大到 z11 以上時海面沒有水深資料，會是一致的淺水色。`,
    flyTo(v, card, menu) {  // card：右邊有詳細卡；menu：左邊有教學火山選單（火山放在兩者之間）
      // 區域尺度（z8 以下）：已經比較近就不拉遠、傾斜維持原狀（原本的做法）；再近：固定的距離與傾斜角度
      const region = nearZoom < 8;
      const zoom = region ? Math.max(map.getZoom(), nearZoom) : nearZoom;
      const pitch = region ? (tilted ? 55 : map.getPitch()) : Math.max(pitchFor(nearZoom), tilted ? 55 : 0);
      map.flyTo({ center: [v.lon, v.lat], zoom, pitch,
        padding: { top: 0, bottom: 0, left: menu ? 280 : 0, right: card ? 380 : 0 }, duration: flyMs, essential: true });
    },
    region(r) {
      map.flyTo({ center: [r.lon, r.lat], zoom: r.key === 'world' ? worldZoom : r.zoom, pitch: 0, bearing: 0, padding: { top: 0, bottom: 0, left: 0, right: 0 }, duration: flyMs, essential: true });
      tilted = false;
    },
    zoomBy(d) { if (d > 0) map.zoomIn(); else map.zoomOut(); },
    tilt() {
      tilted = !tilted;
      map.easeTo({ pitch: tilted ? 55 : 0, duration: 800 });
      return tilted;
    },
    north() { tilted = false; map.easeTo({ bearing: 0, pitch: 0, duration: 800 }); },
    palettes: PALETTES.map(({ key, label, swatch, bg }) => ({ key, label, swatch, bg })),
    palette: pal.key,
    setPalette(k) {
      const p = palOf(k);
      map.setPaintProperty('relief', 'color-relief-color', reliefColor(p));
      map.setPaintProperty('shade', 'hillshade-shadow-color', p.shade[0]);
      map.setPaintProperty('shade', 'hillshade-highlight-color', p.shade[1]);
      map.setPaintProperty('shade', 'hillshade-accent-color', p.shade[2]);
      this.palette = p.key;
      try { localStorage.setItem(PAL_KEY, p.key); } catch { /* 存不了就只在這次有效 */ }
    },
    select(v) {
      selMarker?.remove();
      selMarker = null;
      if (v) {
        selMarker = Object.assign(add(v), { vnum: v.vnum });
        selMarker.getElement().classList.add('sel');
      }
      refreshNames();
      showSel();  // app.js 先標好 .sel 才呼叫這裡
    },
  };
}
