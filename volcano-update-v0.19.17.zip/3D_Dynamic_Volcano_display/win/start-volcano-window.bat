@echo off
rem Volcano Pulse display (Windows), window version (v0.19.16): a normal Edge window you can close, minimize to the taskbar,
rem resize, or drag to another monitor. The page has Full screen and Leave buttons at the top right.
rem Copy this file next to the 3D_Dynamic_Volcano_display folder (same place as start-volcano.bat), then double-click it.
rem Auto update only puts it inside 3D_Dynamic_Volcano_display\win\, so copy it out once.
cd /d "%~dp0\3D_Dynamic_Volcano_display" || (echo Cannot find the 3D_Dynamic_Volcano_display folder. Copy this file next to it. & pause & exit /b 1)
where py >nul 2>nul || (echo Python is not installed. See the manual, step 1. & pause & exit /b 1)
py updater.py
start "Volcano server" /min py http_server.py
timeout /t 3 /nobreak >nul
rem --app opens a window without tabs or address bar; Edge remembers its last size and position
start "" msedge --app=http://localhost:8000/?win=1 --no-first-run
