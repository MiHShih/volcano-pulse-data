@echo off
rem Volcano Pulse display (Windows): start a local web server, then open Edge full screen (version A, 3D terrain).
rem Keep this file next to the 3D_Dynamic_Volcano_display folder, e.g. C:\volcano\start-volcano.bat
rem Exit full screen: Alt+F4. Then close the minimized "Volcano server" window on the taskbar.
cd /d "%~dp0\3D_Dynamic_Volcano_display" || (echo Cannot find the 3D_Dynamic_Volcano_display folder & pause & exit /b 1)
where py >nul 2>nul || (echo Python is not installed. See the manual, step 1. & pause & exit /b 1)
rem Check for a new version first (v0.19.12+): download and apply it; if offline or anything fails, start the current version
py updater.py
start "Volcano server" /min py http_server.py
timeout /t 3 /nobreak >nul
start "" msedge --kiosk http://localhost:8000 --edge-kiosk-type=fullscreen --no-first-run
