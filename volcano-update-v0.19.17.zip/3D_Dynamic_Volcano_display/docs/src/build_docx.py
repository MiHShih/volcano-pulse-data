"""產生說明單張的 Word 版（.docx），內容跟 PDF 版相同，版面比較簡單、方便自己改字。只用 Python 標準函式庫，macOS 執行。

執行：python3 docs/src/build_docx.py
- 圖示與「加了編號的主畫面截圖」先用 Chrome 轉成 PNG，放在 docs/img/word/
- 圖示來源是 icons.json（app.js 的 ico() 匯出：node --input-type=module -e "import {ico} from './app.js'; ..."）
- 改了 PDF 版（*.tpl.html）的文字時，這裡要一起改
"""
import json
import os
import re
import subprocess
import tempfile
import zipfile
from xml.sax.saxutils import escape

from build_pdf import REFRESH

SRC = os.path.dirname(os.path.abspath(__file__))
DOCS = os.path.dirname(SRC)
IMG = os.path.join(DOCS, 'img')
WIMG = os.path.join(IMG, 'word')
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
EMU_CM = 360000
TW_CM = 567  # twips per cm
PAGE_W_CM, MARGIN_CM = 21.0, 1.5
TEXT_W = round((PAGE_W_CM - 2 * MARGIN_CM) * TW_CM)
ORANGE, INK, MUTED, SOFT = 'E8590C', '14171C', '5A6170', 'F5F6F8'


# ---------- 先把圖示與標號截圖轉成 PNG ----------
def chrome_shot(html, out, w, h, scale=3):
    with tempfile.TemporaryDirectory() as tmp:
        page = os.path.join(tmp, 'p.html')
        open(page, 'w', encoding='utf-8').write(html)
        subprocess.run([CHROME, '--headless=new', '--disable-gpu', f'--user-data-dir={tmp}/prof', '--hide-scrollbars',
                        f'--window-size={w},{h}', f'--force-device-scale-factor={scale}', '--default-background-color=ffffffff',
                        f'--screenshot={out}', 'file://' + page], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)


def make_images():
    os.makedirs(WIMG, exist_ok=True)
    icons = json.load(open(os.path.join(SRC, 'icons.json'), encoding='utf-8'))
    icons['refresh'] = REFRESH.replace('class="ri"', 'width="28" height="28"')
    for k, svg in icons.items():
        svg = re.sub(r'width="\d+" height="\d+"', 'width="64" height="64"', svg)
        chrome_shot(f'<body style="margin:0">{svg}</body>', os.path.join(WIMG, f'ico-{k}.png'), 64, 64)
    pins = [(33.9, 11.0), (17.6, 32.3), (5.8, 16.5), (57.6, 95.0), (76.7, 25.8), (76.5, 11.5), (71.6, 6.1)]
    dots = ''.join(f'<span style="position:absolute;left:{x}%;top:{y}%;width:34px;height:34px;margin:-17px 0 0 -17px;border-radius:50%;'
                   f'background:#E8590C;color:#fff;font:700 21px/34px Arial;text-align:center;box-shadow:0 0 0 4px #fff">{i + 1}</span>'
                   for i, (x, y) in enumerate(pins))
    chrome_shot(f'<body style="margin:0"><div style="position:relative;width:1423px;height:775px">'
                f'<img src="file://{IMG}/screen-main.jpg" style="display:block;width:1423px">{dots}</div></body>',
                os.path.join(WIMG, 'screen-main-pins.png'), 1423, 775, scale=1)


def px_size(path):
    out = subprocess.run(['sips', '-g', 'pixelWidth', '-g', 'pixelHeight', path], capture_output=True, text=True, check=True).stdout
    return tuple(int(v) for v in re.findall(r'pixel\w+: (\d+)', out))


# ---------- 極簡 OOXML 產生器 ----------
class Doc:
    def __init__(self, landscape=False):
        self.body, self.media, self.lists, self.pics = [], [], 0, 0
        self.landscape = landscape  # 標題海報是 A4 橫式，其他說明單張是直式

    def image(self, path, width_cm, alt=''):
        """回傳行內圖片的 run；寬度固定，高度依比例。"""
        if path not in [m[0] for m in self.media]:
            self.media.append((path, f'rIdImg{len(self.media) + 1}'))
        rid = dict(self.media)[path]
        w, h = px_size(path)
        cx, cy = round(width_cm * EMU_CM), round(width_cm * EMU_CM * h / w)
        self.pics += 1
        n = self.pics
        return (f'<w:r><w:drawing><wp:inline distT="0" distB="0" distL="0" distR="0"><wp:extent cx="{cx}" cy="{cy}"/>'
                f'<wp:docPr id="{n}" name="圖 {n}" descr="{escape(alt)}"/><wp:cNvGraphicFramePr><a:graphicFrameLocks noChangeAspect="1"/></wp:cNvGraphicFramePr>'
                f'<a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/picture"><pic:pic><pic:nvPicPr>'
                f'<pic:cNvPr id="{n}" name="{escape(os.path.basename(path))}"/><pic:cNvPicPr/></pic:nvPicPr><pic:blipFill><a:blip r:embed="{rid}"/>'
                f'<a:stretch><a:fillRect/></a:stretch></pic:blipFill><pic:spPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
                f'<a:prstGeom prst="rect"><a:avLst/></a:prstGeom></pic:spPr></pic:pic></a:graphicData></a:graphic></wp:inline></w:drawing></w:r>')

    def runs(self, text, size=None, color=None, bold=False):
        """簡單標記：**粗體**、`程式碼`、{ico:名稱} 行內圖示。"""
        out = []
        for part in re.split(r'(\*\*.+?\*\*|`.+?`|\{ico:\w+\})', text):
            if not part:
                continue
            if part.startswith('{ico:'):
                out.append(self.image(os.path.join(WIMG, f'ico-{part[5:-1]}.png'), 0.42))
                continue
            b, code = bold, False
            if part.startswith('**'):
                part, b = part[2:-2], True
            elif part.startswith('`'):
                part, code = part[1:-1], True
            rpr = '<w:rFonts w:ascii="Menlo" w:hAnsi="Menlo" w:cs="Consolas"/>' if code else ''  # 子元素順序依 OOXML 規範
            if b:
                rpr += '<w:b/>'
            if color:
                rpr += f'<w:color w:val="{color}"/>'
            if size or code:
                rpr += f'<w:sz w:val="{round((size or 9.5) * 2 * (0.9 if code else 1))}"/>'
            if code:
                rpr += '<w:shd w:val="clear" w:color="auto" w:fill="F1F3F5"/>'
            out.append(f'<w:r><w:rPr>{rpr}</w:rPr><w:t xml:space="preserve">{escape(part)}</w:t></w:r>')
        return ''.join(out)

    def p(self, text='', style=None, size=None, color=None, bold=False, before=None, after=None, align=None, num=None, shade=None, raw=''):
        ppr = ''
        if style:
            ppr += f'<w:pStyle w:val="{style}"/>'
        if num:
            ppr += f'<w:numPr><w:ilvl w:val="0"/><w:numId w:val="{num}"/></w:numPr>'
        if shade:
            ppr += f'<w:shd w:val="clear" w:color="auto" w:fill="{shade}"/>'
        if before is not None or after is not None:
            ppr += f'<w:spacing w:before="{before or 0}" w:after="{after or 0}"/>'
        if align:
            ppr += f'<w:jc w:val="{align}"/>'
        return f'<w:p><w:pPr>{ppr}</w:pPr>{raw}{self.runs(text, size, color, bold)}</w:p>'

    def add(self, *xml):
        self.body.extend(xml)

    def h(self, text):
        self.add(self.p(text, style='H2'))

    def bullets(self, items, size=None):
        self.add(*[self.p(t, num=1, size=size, after=40) for t in items])

    def numbered(self, items, size=None):
        self.lists += 1
        self.add(*[self.p(t, num=1 + self.lists, size=size, after=40) for t in items])

    def table(self, rows, widths_cm, fills=None, borders=False, pad=90):
        """rows：每格是段落 XML 字串（可多段）；fills：同形狀的底色或 None。"""
        ws = [round(w * TW_CM) for w in widths_cm]
        b = ('<w:tblBorders>' + ''.join(f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="E3E6EB"/>' for s in ('top', 'bottom', 'insideH'))
             + '</w:tblBorders>') if borders else ('<w:tblBorders>' + ''.join(f'<w:{s} w:val="nil"/>' for s in ('top', 'left', 'bottom', 'right', 'insideH', 'insideV')) + '</w:tblBorders>')
        xml = (f'<w:tbl><w:tblPr><w:tblW w:w="{sum(ws)}" w:type="dxa"/>{b}<w:tblLayout w:type="fixed"/>'
               f'<w:tblCellMar><w:top w:w="{pad}" w:type="dxa"/><w:left w:w="110" w:type="dxa"/><w:bottom w:w="{pad}" w:type="dxa"/><w:right w:w="110" w:type="dxa"/></w:tblCellMar>'
               f'<w:tblLook w:val="0000"/></w:tblPr><w:tblGrid>' + ''.join(f'<w:gridCol w:w="{w}"/>' for w in ws) + '</w:tblGrid>')
        for i, row in enumerate(rows):
            xml += '<w:tr><w:trPr><w:cantSplit/></w:trPr>'
            for j, cell in enumerate(row):
                fill = fills[i][j] if fills else None
                shd = f'<w:shd w:val="clear" w:color="auto" w:fill="{fill}"/>' if fill else ''
                xml += f'<w:tc><w:tcPr><w:tcW w:w="{ws[j]}" w:type="dxa"/>{shd}<w:vAlign w:val="top"/></w:tcPr>{cell or self.p()}</w:tc>'
            xml += '</w:tr>'
        self.add(xml + '</w:tbl>', self.p(after=0, size=4))

    def page_break(self):
        self.add('<w:p><w:r><w:br w:type="page"/></w:r></w:p>')

    def save(self, path, title):
        ns = ('xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" '
              'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
              'xmlns:wp="http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing" '
              'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
              'xmlns:pic="http://schemas.openxmlformats.org/drawingml/2006/picture"')
        m = round(MARGIN_CM * TW_CM)
        pg = '<w:pgSz w:w="16838" w:h="11906" w:orient="landscape"/>' if self.landscape else '<w:pgSz w:w="11906" w:h="16838"/>'
        doc = (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {ns}><w:body>{"".join(self.body)}'
               f'<w:sectPr>{pg}<w:pgMar w:top="{m}" w:right="{m}" w:bottom="{m}" w:left="{m}" w:header="0" w:footer="0" w:gutter="0"/></w:sectPr>'
               '</w:body></w:document>')
        rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                '<Relationship Id="rIdNum" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/>'
                + ''.join(f'<Relationship Id="{rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="media/{rid}{os.path.splitext(p)[1].lower()}"/>'
                          for p, rid in self.media) + '</Relationships>')
        types = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                 '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
                 '<Default Extension="png" ContentType="image/png"/><Default Extension="jpg" ContentType="image/jpeg"/>'
                 '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>'
                 '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>'
                 '<Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/>'
                 '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>')
        root = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>'
                '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>')
        core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
                'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
                f'<dc:title>{escape(title)}</dc:title><dc:language>zh-TW</dc:language></cp:coreProperties>')
        with zipfile.ZipFile(path, 'w', zipfile.ZIP_DEFLATED) as z:
            z.writestr('[Content_Types].xml', types)
            z.writestr('_rels/.rels', root)
            z.writestr('docProps/core.xml', core)
            z.writestr('word/document.xml', doc)
            z.writestr('word/_rels/document.xml.rels', rels)
            z.writestr('word/styles.xml', STYLES)
            z.writestr('word/numbering.xml', numbering(self.lists))
            for p, rid in self.media:
                z.write(p, f'word/media/{rid}{os.path.splitext(p)[1].lower()}')


STYLES = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:eastAsia="Microsoft JhengHei" w:cs="Arial"/><w:color w:val="{INK}"/><w:sz w:val="19"/><w:lang w:val="en-US" w:eastAsia="zh-TW"/></w:rPr></w:rPrDefault>
<w:pPrDefault><w:pPr><w:spacing w:after="60" w:line="276" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>
<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="0" w:after="40"/></w:pPr><w:rPr><w:b/><w:sz w:val="40"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Subtitle"><w:name w:val="Subtitle"/><w:basedOn w:val="Normal"/><w:pPr><w:pBdr><w:bottom w:val="single" w:sz="12" w:space="6" w:color="{INK}"/></w:pBdr><w:spacing w:before="0" w:after="120"/></w:pPr><w:rPr><w:color w:val="{MUTED}"/><w:sz w:val="18"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="H2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:pBdr><w:left w:val="single" w:sz="24" w:space="6" w:color="{ORANGE}"/></w:pBdr><w:spacing w:before="200" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style>
</w:styles>'''


def numbering(lists):
    bullet = (f'<w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/>'
              f'<w:lvlText w:val="●"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="300" w:hanging="220"/></w:pPr><w:rPr><w:color w:val="{ORANGE}"/><w:sz w:val="12"/></w:rPr></w:lvl></w:abstractNum>')
    dec = ('<w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/>'
           f'<w:lvlText w:val="%1"/><w:lvlJc w:val="left"/><w:pPr><w:ind w:left="340" w:hanging="300"/></w:pPr><w:rPr><w:b/><w:color w:val="{ORANGE}"/></w:rPr></w:lvl></w:abstractNum>')
    nums = '<w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num>' + ''.join(
        f'<w:num w:numId="{i + 2}"><w:abstractNumId w:val="1"/><w:lvlOverride w:ilvl="0"><w:startOverride w:val="1"/></w:lvlOverride></w:num>' for i in range(lists))
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            + bullet + dec + nums + '</w:numbering>')


# ---------- 內容 ----------
def header(d, title, sub):
    d.add(d.p(raw=d.image(os.path.join(IMG, 'tvo.png'), 4.2, '大屯火山觀測站 TVO'), align='right', after=0))
    d.add(d.p(title, style='Title'), d.p(sub, style='Subtitle'))


def foot(d, text):
    d.add(d.p(text, size=7.5, color=MUTED, before=120))


def card(d, title, text, fill):
    return d.p(title, bold=True, size=9.8, after=20) + d.p(text, size=8.6, after=0)


def viewer():
    d = Doc()
    header(d, '全球火山活動 3D 地球　觀眾導覽 1／2', '火山脈動 Volcano Pulse・看懂這個螢幕')
    d.add(d.p('這個螢幕顯示全球 **1,214 座**全新世（Holocene，約一萬一千七百年來）曾經活動過的火山，以及它們最近的活動狀態。資料每天自動更新。', size=10, after=120))
    keys = ['區域：一鍵切到全球、東亞、東南亞等', '地圖：拖曳轉動，滾輪或雙指縮放', '放大縮小、傾斜視角、待機與設定', '圖例：每種狀態目前有幾座',
            '概況、活動、火山、來源四個分頁', '搜尋：打中文或英文火山名、國家', '資料更新時間與立即更新按鈕']
    d.lists += 1
    keys_xml = ''.join(d.p(k, num=1 + d.lists, size=8.6, after=50) for k in keys)
    d.table([[d.p(raw=d.image(os.path.join(WIMG, 'screen-main-pins.png'), 12.2, '畫面全貌'), after=0), keys_xml]], [12.6, 5.4], pad=0)
    d.h('地圖上的圖示代表什麼')
    items = [('alert', '警戒升高', '美國地質調查所（USGS）調高警戒等級的火山，只涵蓋美國'), ('erupt_yday', '昨天噴發', '昨天（UTC）有噴發報導的火山'),
             ('erupt_off', '7 天內噴發（官方）', '最近 7 天，官方火山活動週報記錄的噴發'), ('erupt_unv', '7 天內噴發（網路來源）', '最近 7 天，網路報導的噴發，未經官方確認'),
             ('weekly', '官方週報', '最新一期週報提到，但不是最近 7 天的噴發'), ('claude', '網路來源', '最近 30 天有網路報導的活動'),
             ('decade', '十年火山', '國際選出的 16 座重點研究火山，名稱一直顯示（見第 2 頁）'), ('none', '其他火山', '近期沒有活動紀錄')]
    cell = lambda k, n, t: d.p(f'{{ico:{k}}} **{n}**', size=9.6, after=10) + d.p(t, size=8.4, color=MUTED, after=0)
    rows = [[cell(*items[i]), cell(*items[i + 1])] for i in range(0, 8, 2)]
    d.table(rows, [9, 9], fills=[[SOFT, SOFT]] * 4)
    d.add(d.p('噴發中的火山外圍有一圈脈動的光環。同一座火山符合好幾種狀態時，顯示上表排在前面（由左到右、由上到下）的那一種。', size=8.2, color=MUTED))
    d.h('點一座火山，看詳細資料')
    pts = ['點地圖上的圖示，或在右側列表點火山名稱。', '詳細卡最上面是這座火山的中文簡介，接著是目前狀態、最近一次噴發的年份、座標、官方週報與網路報導的內容和原始來源。',
           '有 YouTube 直播的火山會列出直播，點一下就能看。直播多半是民間頻道，畫面僅供參考。', '按右上角的 × 關閉。']
    d.table([[d.p(raw=d.image(os.path.join(IMG, 'screen-card.jpg'), 9.2, '櫻島的詳細卡'), after=20) + d.p('例：點選櫻島後，地圖飛過去並打開右邊的詳細卡。', size=8, color=MUTED, after=0),
              ''.join(d.p(t, num=1, size=9, after=50) for t in pts)]], [9.6, 8.4], pad=0)
    foot(d, '畫面上的日期與時間都是世界協調時間（UTC）；台灣時間＝UTC＋8 小時。　觀眾導覽 1／2')
    d.page_break()

    header(d, '全球火山活動 3D 地球　觀眾導覽 2／2', '火山脈動 Volcano Pulse・資料從哪裡來')
    d.h('資料從哪裡來')
    cards = [('全球火山清單', '美國史密森尼學會「全球火山計畫」（GVP）的《世界火山》資料庫 v5.4.0：1,214 座全新世火山的位置與基本資料。', 'F5F6F8'),
             ('每週火山活動報告（官方）', 'GVP 與美國地質調查所（USGS）每週發布，整理全球新的與持續中的噴發。地圖上的橘色。', 'FFF4EC'),
             ('美國火山警戒（官方）', 'USGS 火山災害通報系統（HANS）公布的警戒等級。地圖上的深紅色，只涵蓋美國。', 'FDF1EF'),
             ('網路來源（未經官方確認）', '每天由 AI（Claude）搜尋各國觀測機構與新聞的最新報導並判讀。地圖上的紫色，可能有誤。', 'F5F2FF')]
    d.table([[card(d, *cards[0]), card(d, *cards[1])], [card(d, *cards[2]), card(d, *cards[3])]], [9, 9], fills=[[c[2] for c in cards[:2]], [c[2] for c in cards[2:]]])
    d.add(d.p('直播影像來自 YouTube，每天更新一次清單；直播隨時可能結束。詳細卡的中文簡介依 GVP 資料庫的地質摘要，由 AI（Claude）整理，十年火山與台灣的火山經過人工校對。', size=8.2, color=MUTED))
    d.h('每天怎麼更新')
    steps = [('07:00', 'AI 搜尋前一天的網路報導與 YouTube 直播'), ('09:00', '資料站整理官方資料與網路報導，檢查格式'),
             ('發布', '把整理好的資料放到網路上的固定位置'), ('每 30 分鐘', '展示螢幕檢查一次，有新資料就自動更新畫面')]
    d.table([[d.p(a, bold=True, color=ORANGE, size=10, after=10) + d.p(b, size=8.5, after=0) for a, b in steps]], [4.5] * 4, fills=[[SOFT] * 4])
    d.add(d.p('時間為台灣時間。官方週報每週發布一次，所以「官方」的資料一週才變一次。', size=8.2, color=MUTED))
    d.h('什麼是「十年火山」')
    d.add(d.p('1990 年代聯合國推動「國際減災十年」，國際火山學與地球內部化學協會（IAVCEI）選出 16 座歷史上曾造成重大災害、又靠近人口密集地區的火山，作為重點研究的對象。地圖上用三角形標示，名稱一直顯示。'))
    dec = ['Sakurajima 櫻島（日本）', 'Unzen 雲仙岳（日本）', 'Taal 塔爾火山（菲律賓）', 'Merapi 默拉皮火山（印尼）', 'Ulawun（巴布亞紐幾內亞）',
           'Avachinsky-Koryaksky（俄羅斯）', 'Mauna Loa 毛納羅亞山（美國）', 'Rainier 雷尼爾山（美國）', 'Colima（墨西哥）', 'Santa María（瓜地馬拉）',
           'Galeras（哥倫比亞）', 'Teide 泰德峰（西班牙）', 'Etna 埃特納火山（義大利）', 'Vesuvius 維蘇威火山（義大利）', 'Santorini 聖托里尼（希臘）',
           'Nyiragongo 尼拉貢戈火山（剛果民主共和國）']
    d.table([[d.p(dec[r * 4 + c], size=8.2, after=0) for c in range(4)] for r in range(4)], [4.5] * 4, fills=[[SOFT] * 4] * 4, pad=50)
    d.h('沒人操作時：地球與真實的星空')
    sky_txt = (d.p('幾分鐘沒人操作，地球會回到全球視角慢慢轉動，背後出現星空。有人碰螢幕或滑鼠時就停下來，把台灣轉回正中間。', size=9, after=60)
               + d.p('星星的位置依照這台電腦現在的時間計算：轉到哪一面，看到的就是那個方向真正的天空，也會隨季節改變。', num=1, size=9, after=50)
               + d.p('可以顯示約 9,100 顆肉眼可見的星、銀河、太陽、月亮、水星到土星五顆行星，以及 88 星座的連線和名稱。', num=1, size=9, after=50)
               + d.p('工作人員可以打開「待機導覽」：轉到十年火山或昨天噴發的火山時，地球會停下來飛過去，打開它的詳細卡。', num=1, size=9, after=0))
    d.table([[d.p(raw=d.image(os.path.join(IMG, 'sky.jpg'), 9.2, '待機背景的星空示意'), after=20)
              + d.p('示意：鏡頭朝向天蠍座方向，開啟銀河與星座（2026 年 11 月 7 日）。這時太陽在天秤座，月亮、金星在室女座。', size=7.8, color=MUTED, after=0), sky_txt]], [9.6, 8.4], pad=0)
    d.add(d.p('**本網頁非官方預警，警戒資訊以各國火山觀測機構公告為準。**網路來源由 AI 自動搜尋與判讀，可能有誤，請以詳細卡裡的原始來源為準。', size=9, color='7A1A12', shade='FDECEA', before=120))
    foot(d, '資料：GVP（Smithsonian Institution）、USGS。星表：Yale Bright Star Catalogue；星座與銀河：d3-celestial。　觀眾導覽 2／2')
    return d


def staff():
    d = Doc()
    header(d, 'Raspberry Pi 展示機操作說明　工作人員用', '全球火山活動 3D 地球（火山脈動 Volcano Pulse）v0.19.14')
    left = []
    d.lists += 1
    n = 1 + d.lists
    left.append(d.p('每天開機', style='H2'))
    left += [d.p(t, num=n, size=9, after=50) for t in ['接上電源，約 1 分鐘後自動登入、檢查新版（有就自動更新），再全螢幕打開火山地圖，不需要其他操作。',
                                                        '螢幕不會自動關閉。沒人操作一段時間（預設 3 分鐘）會進入待機：回到全球、慢慢轉動（約 4 分鐘一圈）、顯示星空。',
                                                        '有人碰螢幕、滑鼠或鍵盤就離開待機，台灣轉回正中間。']]
    left.append(d.p('手動啟動、關閉', style='H2'))
    left += [d.p(t, num=1, size=9, after=50) for t in ['**啟動**：在桌面開「終端機」，輸入 `~/volcano/start-volcano.sh`',
                                                        '**離開全螢幕**：按 `Alt`＋`F4`。接著在終端機輸入 `pkill -f http.server` 關掉本機伺服器。',
                                                        '**重新開機**：`sudo reboot`', '**關機**：`sudo shutdown -h now`，等指示燈不再閃爍後再拔電源。']]
    left.append(d.p('待機導覽', style='H2'))
    left += [d.p(t, num=1, size=9, after=50) for t in ['待機選單的**待機導覽**有「十年火山介紹」「噴發中與昨天噴發火山介紹」兩個開關，預設都關。',
                                                        '打開後，地球轉到這些火山時會停下來飛過去，打開詳細卡，停留後再飛回全球繼續轉。',
                                                        '**每座停留**：5、10、15、20、30 秒，預設 10 秒。停留中有人操作就留在那座火山。']]
    right = [d.p('待機與背景設定', style='H2')]
    right.append(d.p(raw=d.image(os.path.join(IMG, 'menu-idle.png'), 3.4, '待機模式選單'), align='center', after=40))
    right += [d.p(t, num=1, size=8.6, after=40) for t in ['地圖左上控制列的**時鐘按鈕**打開選單。', '**待機時間**：1、3、5、10、30 分鐘或不待機。',
                                                           '**待機背景**：星星、銀河、太陽月亮與行星、星座、白天與黑夜，各自開關。',
                                                           '**齒輪按鈕**（控制列最下面）打開設定頁（待機、鏡頭、圖層與教學、地形配色）：可調自轉速度、飛行時間、拉近程度、銀河樣式、衛星影像，也從這裡開教學模式。',
                                                           '設定存在這台機器的瀏覽器裡，重開機也會記住。Pi 預設開 A 版（3D 地形）；太卡的話在頁首切到「地形貼圖」（B 版）。']]
    d.table([[''.join(left), ''.join(right)]], [10.2, 7.8], pad=0)
    d.h('資料更新')
    d.bullets(['**自動**：資料站每天 09:00（台灣時間）發布新資料。展示機每 30 分鐘檢查一次，有新資料會趁沒人操作時自動重新載入。',
               '**手動**：按頁首更新時間右邊的 {ico:refresh} 按鈕（見下圖）。',
               '**頁首圓點**：綠色是正常；橘色表示資料超過 2 天沒更新，或官方週報超過 10 天沒有新一期（滑鼠移上去看原因）。GVP 週報的 RSS 從 10 月中沒更新，目前是橘色。'], size=9)
    d.add(d.p(raw=d.image(os.path.join(IMG, 'header-refresh.png'), 9, '頁首的更新時間與立即更新按鈕'), after=80))
    d.h('常見問題')
    qa = [('開機後沒有出現地圖', '確認已經自動登入桌面；在終端機執行 `~/volcano/start-volcano.sh`，看有沒有錯誤訊息。'),
          ('出現「地圖無法啟動」或看不到地球', '瀏覽器網址列輸入 `chrome://gpu`，WebGL 要是「Hardware accelerated」；不是的話先重新開機。'),
          ('日期、「昨天噴發」或星空位置不對', 'Pi 沒有電池供電的時鐘，要連上網路才會校正時間。確認網路後重新開機。'),
          ('畫面很卡', '在待機背景關掉「銀河」；還是卡就在頁首切到「地形貼圖」（B 版，改法寫在 `start-volcano.sh` 開頭的說明）。'),
          ('資料一直沒更新、圓點是橘色', '先按 {ico:refresh}；確認網路；仍然不行請通知維護人員（資料站在 Mac mini）。'),
          ('畫面空白', '會自己重新載入一次；還是空白就按 `Ctrl`＋`Shift`＋`R`。程式更新與退回見第 2 頁。')]
    rows = [[d.p('狀況', bold=True, size=8.6, after=0), d.p('處理方式', bold=True, size=8.6, after=0)]] + [[d.p(a, bold=True, size=8.6, after=0), d.p(b, size=8.6, after=0)] for a, b in qa]
    d.table(rows, [5.6, 12.4], fills=[[SOFT, SOFT]] + [[None, None]] * len(qa), borders=True, pad=60)
    d.h('維護聯絡人')
    line = lambda t: d.p(t, size=8.4, color=MUTED, before=320, after=0)
    d.table([[line('姓名'), line('電話'), line('Email')]], [6, 6, 6], borders=True)
    foot(d, '依 Raspberry Pi OS（Debian 13 Trixie）撰寫，尚未在實機完整測試。安裝與更新見第 2 頁。　操作說明 1／2')
    d.page_break()

    header(d, 'Raspberry Pi 展示機操作說明　工作人員用', '安裝與更新・全球火山活動 3D 地球（火山脈動 Volcano Pulse）v0.19.14')
    cmd = lambda *lines: ''.join(d.p(f'`{l}`', shade='F5F6F8', size=9, after=0) for l in lines) + d.p(after=40, size=4)  # noqa: E731

    def steps(items):
        d.lists += 1
        for t, c in items:
            d.add(d.p(t, num=1 + d.lists, size=9, after=50))
            if c:
                d.add(cmd(*c))

    d.h('兩種移植檔')
    rows = [[d.p('檔案', bold=True, size=8.6, after=0), d.p('用途', bold=True, size=8.6, after=0)],
            [d.p('**volcano-globe.zip**', size=8.6, after=0) + d.p('完整檔，約 3.7 GB', size=8, color=MUTED, after=0),
             d.p('第一次安裝。含地形圖磚與 B 版近看的地形圖，沒有網路也能放大看火山細節。', size=8.6, after=0)],
            [d.p('**volcano-update-v版本.zip**', size=8.6, after=0) + d.p('更新包，約 16 MB（v0.17.0 約 0.4 GB）', size=8, color=MUTED, after=0),
             d.p('已經裝過的 Pi 手動換新版，解壓縮後直接覆蓋。v0.19.12 起開機會自動更新，只有第一次或沒網路時才要用。比 v0.17.0 舊的機器先裝 v0.17.0。', size=8.6, after=0)]]
    d.table(rows, [6.4, 11.6], fills=[[SOFT, SOFT], [None, None], [None, None]], borders=True, pad=60)
    d.h('完整安裝（第一次，用完整檔）')
    steps([('**燒錄系統**：建議 Pi 5（或 RAM 4 GB 以上的 Pi 4）、官方電源、32 GB 以上的 microSD。在電腦上用 Raspberry Pi Imager 燒錄「Raspberry Pi OS (64-bit)」桌面版（不要選 Lite），先填好使用者名稱、Wi-Fi 與時區。', None),
           ('**更新系統**：第一次開機後打開「終端機」輸入：', ['sudo apt update && sudo apt full-upgrade -y']),
           ('**複製並解壓縮**：插上放有完整檔的隨身碟，在終端機輸入（顯示沒有 `unzip` 時先執行 `sudo apt install unzip`）：',
            ['mkdir -p ~/volcano && cd ~/volcano', 'cp /media/$USER/*/volcano-globe.zip .', 'unzip -q volcano-globe.zip && rm volcano-globe.zip']),
           ('**手動測試**：輸入 `~/volcano/start-volcano.sh`，Chromium 會全螢幕打開 A 版（3D 地形）。按 `Alt`＋`F4` 離開後，在網址列輸入 `chrome://gpu`，WebGL 要是「Hardware accelerated」。', None),
           ('**開機自動啟動**：', ['mkdir -p ~/.config/labwc', 'echo "$HOME/volcano/start-volcano.sh &" >> ~/.config/labwc/autostart']),
           ('**自動登入、螢幕不關**：輸入 `sudo raspi-config`，選 System Options → Boot / Auto Login → Desktop Autologin；Display Options → Screen Blanking → 關閉。完成後 `sudo reboot`，應該會自動進入全螢幕展示，頁尾顯示目前版本（例如「測試開發版 v0.19.14」），「來源」分頁的資料包寫「線上資料包」。', None),
           ('**連上網路**：Pi 沒有電池供電的時鐘，要連網才會校正時間；時間錯了，日期、「昨天噴發」和星空都會跟著錯。', None)])
    d.h('換新版')
    d.bullets(['**自動更新**（v0.19.12 起）：每次執行 `start-volcano.sh`（包括開機）先檢查新版，有就下載（約 16 MB）、核對、備份後套用；沒網路或失敗就照目前的版本開。紀錄在程式資料夾的 `.update/update.log`。',
               '**退回上一版**：`cd ~/volcano/3D_Dynamic_Volcano_display && python3 updater.py --rollback`',
               '**這台不要自動更新**：在程式資料夾的 `config.json` 大括號裡加 `, "auto_update": false`。'], size=9)
    d.h('手動換新版（第一次、沒網路或維護人員指示時）')
    steps([('按 `Alt`＋`F4` 離開全螢幕，插上更新包的隨身碟，在終端機輸入（版本號換成實際檔名）：', ['cd ~/volcano', 'pkill -f http.server', 'unzip -o -q /media/$USER/*/volcano-update-v0.19.14.zip', '~/volcano/start-volcano.sh']),
           ('頁尾的版本號要是新版。啟動腳本本身只會隨手動更新包換新。', None)])
    foot(d, '依 Raspberry Pi OS（Debian 13 Trixie）撰寫，尚未在實機完整測試；開機自動啟動那一步最可能要再調整。　操作說明 2／2')
    return d


def poster():
    d = Doc(landscape=True)
    d.table([[d.p(raw=d.image(os.path.join(IMG, 'tvo.png'), 4.6, '大屯火山觀測站 TVO'), after=0),
              d.p('火山脈動 VOLCANO PULSE', size=9, color=MUTED, align='right', before=160, after=0)]], [13.2, 13.2], pad=0)
    feats = [('找到正在噴發的火山', '{ico:erupt_yday} 紅色是昨天噴發，{ico:erupt_off} 橘色、{ico:erupt_unv} 紫色是最近 7 天噴發，外圍有脈動的光環。深紅色圓點是美國警戒升高的火山。'),
             ('點一下，看簡介、紀錄與直播', '每座火山都有中文簡介與詳細資料：最近一次噴發、官方週報與網路報導的原始來源。部分火山還有 YouTube 直播畫面。'),
             ('地球在真實的星空前自轉', '沒人操作時，地球慢慢轉動，背後是依現在時間計算的星空、銀河、太陽、月亮與行星。')]
    left = (d.p('全球火山活動', bold=True, size=32, after=0) + d.p('3D 地球', bold=True, size=32, after=60)
            + d.p('看見地球上正在活動的火山', bold=True, size=13, color=ORANGE, after=100)
            + d.p('在立體的地球上，標出全世界 1,214 座全新世火山的位置與最近的活動。誰昨天噴發、誰的警戒升高，資料每天自動更新。', size=11.5, after=240)
            + ''.join(d.p(t, bold=True, size=11, before=120, after=30) + d.p(x, size=9, after=0) for t, x in feats))
    right = (d.p(raw=d.image(os.path.join(IMG, 'hero.png'), 13.6, '地球在星空前自轉的待機畫面'), align='center', after=60)
             + d.p('{ico:erupt_yday} 昨天噴發　{ico:erupt_off} 7 天內噴發（官方）　{ico:erupt_unv} 7 天內噴發（網路來源）　{ico:alert} 警戒升高　{ico:decade} 十年火山', size=8.6, after=120)
             + d.p('**試試看**　拖曳轉動地球・滾輪或雙指縮放・點一座火山・在右上搜尋中文名，例如「櫻島」', size=10, shade='FFF4EC', after=0))
    d.table([[left, right]], [12.2, 14.2], pad=60)
    foot(d, '本網頁非官方預警，警戒資訊以各國火山觀測機構公告為準。資料：GVP（Smithsonian Institution）、USGS 與網路來源。畫面時間為 UTC。')
    return d


def port():
    d = Doc()
    sub = '全球火山活動 3D 地球（火山脈動 Volcano Pulse）v0.19.14'
    cmd = lambda *lines: ''.join(d.p(f'`{l}`', shade='F5F6F8', size=9, after=0) for l in lines) + d.p(after=40, size=4)  # noqa: E731

    def steps(items):
        d.lists += 1
        for t, c in items:
            d.add(d.p(t, num=1 + d.lists, size=9, after=50))
            if c:
                d.add(cmd(*c))

    header(d, 'Windows 與 Mac 移植操作手冊　維護人員用', sub)
    d.add(d.p('展示端是一組網頁：在這台電腦開本機伺服器，用瀏覽器全螢幕打開；資料每天自動從網路讀取。', size=10, after=120))
    d.h('兩種移植檔')
    rows = [[d.p('檔案', bold=True, size=8.6, after=0), d.p('用途', bold=True, size=8.6, after=0)],
            [d.p('**volcano-globe.zip**', size=8.6, after=0) + d.p('完整檔，約 3.7 GB', size=8, color=MUTED, after=0),
             d.p('第一次安裝。含地形圖磚與 B 版近看的地形圖，沒有網路也能放大看火山細節。', size=8.6, after=0)],
            [d.p('**volcano-update-v版本.zip**', size=8.6, after=0) + d.p('更新包，約 16 MB（v0.17.0 約 0.4 GB）', size=8, color=MUTED, after=0),
             d.p('已經裝過的電腦手動換新版，解壓縮後直接覆蓋。v0.19.12 起開機會自動更新，只有第一次或沒網路時才要用。比 v0.17.0 舊的機器先裝 v0.17.0。', size=8.6, after=0)]]
    d.table(rows, [6.4, 11.6], fills=[[SOFT, SOFT], [None, None], [None, None]], borders=True, pad=60)
    d.add(d.p('最上層有三支啟動腳本（Windows `.bat`、Mac `.command`、Pi `.sh`）與 `3D_Dynamic_Volcano_display` 資料夾。'
              '維護人員在資料站（Mac mini）執行 `sh tools/pack.sh`（完整檔）、`sh tools/pack.sh --update`（更新包）、`python3 tools/release.py`（發佈自動更新，推送前要經負責人同意）。', size=8.2, color=MUTED))
    d.h('需要準備')
    d.bullets(['**Python 3**：用來開本機伺服器，安裝方式見下面各系統的第 1 步。', '**瀏覽器**：Windows 用內建的 Edge，Mac 用 Chrome，兩者都要能用顯示卡硬體加速。',
               '**空間與隨身碟**：解壓縮時需要約 8 GB，解完可以刪掉壓縮檔；隨身碟 exFAT 或 FAT32 都可以（完整檔小於 4 GB）。',
               '**網路**：每天的新資料、YouTube 直播和正確的時間都要靠網路。'], size=9)
    d.h('Mac（macOS）完整安裝（第一次，用完整檔）')
    steps([('**安裝 Python**：打開「終端機」，輸入 `python3 --version`。第一次會跳出安裝「命令列開發者工具」的視窗，按「安裝」；裝好後再輸入一次，出現版本號就完成。', None),
           ('**解壓縮**：以壓縮檔放在「下載項目」為例，在終端機輸入下面兩行。不要在 Finder 雙擊解壓縮：5 萬多個檔案很慢，還會多包一層資料夾。',
            ['mkdir -p ~/volcano', 'unzip -q ~/Downloads/volcano-globe.zip -d ~/volcano']),
           ('**啟動**：在 Finder 打開個人專屬資料夾裡的 `volcano`，雙擊 `start-volcano.command`，Chrome 會全螢幕打開 A 版（3D 地形）。如果跳出「無法打開，因為無法確認開發者」，改成按住 Control 鍵點一下這個檔案、選「打開」，之後就能直接雙擊。', None),
           ('**開機自動啟動**：「系統設定」→「一般」→「登入項目」，按「＋」加入 `start-volcano.command`。', None),
           ('**螢幕不要關**：在「系統設定」的「鎖定畫面」把關閉顯示器的時間設成「永不」，並在「能源」（筆電是「電池」）裡打開防止自動睡眠的選項。', None),
           ('**離開**：按 `Cmd`＋`Q` 關掉全螢幕的 Chrome，再在終端機輸入 `pkill -f http.server` 關掉本機伺服器。', None)])
    d.h('裝好後確認')
    d.bullets(['頁尾最下面一行是目前版本（例如「測試開發版 v0.19.14」）。「來源」分頁的資料包寫「線上資料包」，表示有讀到網路上的資料。',
               '停手 3 分鐘會進入待機：回到全球、慢慢轉動、出現星空；動一下滑鼠就停下來。控制列最下面的齒輪按鈕打開設定頁（待機、鏡頭、圖層與教學、地形配色）。',
               '點一座火山，詳細卡最上面有中文簡介。網址列輸入 `chrome://gpu`（Edge 是 `edge://gpu`），WebGL 要是「Hardware accelerated」。'], size=9)
    foot(d, 'Windows 與 Mac 的步驟、兩支啟動腳本都還沒有實機完整測試；第一次安裝請照做並回報問題。　移植操作手冊 1／2')
    d.page_break()

    header(d, 'Windows 與 Mac 移植操作手冊　維護人員用', sub)
    d.h('Windows 10／11 完整安裝（第一次，用完整檔）')
    steps([('**安裝 Python**：在 Microsoft Store 搜尋並安裝「Python Install Manager」（也可以在 PowerShell 執行 `winget install 9NQ7512CXL7T`）。開一個新的 PowerShell 輸入 `py --version`，出現版本號就完成；沒有的話執行 `py install default`。', None),
           ('**解壓縮**：放在只有英文的路徑，例如 `C:\\volcano`。在 PowerShell 輸入下面兩行（`D:` 換成隨身碟的磁碟代號）。用檔案總管的「解壓縮全部」也可以，但 5 萬多個檔案會很慢。',
            ['mkdir C:\\volcano', 'tar -xf D:\\volcano-globe.zip -C C:\\volcano']),
           ('**啟動**：雙擊 `C:\\volcano\\start-volcano.bat`，Edge 會全螢幕打開 A 版。工作列上縮小的「Volcano server」視窗是本機伺服器，不要關。防火牆詢問按「取消」，安全性警告按「執行」。', None),
           ('**開機自動啟動**：按 `Win`＋`R` 輸入 `shell:startup`，用滑鼠右鍵把 `start-volcano.bat` 拖進打開的「啟動」資料夾，選「在這裡建立捷徑」。', None),
           ('**螢幕不要關**：「設定」→「系統」→「電源」，螢幕與睡眠都設「永不」。「啟動」資料夾要登入後才執行；停電重開要自動進入展示需設定自動登入，請依單位資安規定決定。', None),
           ('**離開**：按 `Alt`＋`F4` 關掉全螢幕的 Edge，再關掉工作列上的「Volcano server」視窗。', None)])
    d.h('換新版')
    d.bullets(['**自動更新**（v0.19.12 起）：每次執行啟動腳本（包括開機）先檢查新版，有就下載（約 16 MB）、核對、備份後套用；沒網路或失敗就照目前的版本開。紀錄在程式資料夾的 `.update/update.log`。',
               '**退回上一版**：在程式資料夾 `3D_Dynamic_Volcano_display` 執行 `python3 updater.py --rollback`（Windows 是 `py`）。不要自動更新：`config.json` 大括號裡加 `, "auto_update": false`。',
               '**手動更新**（第一次、沒網路或維護人員指示時；啟動腳本只會這樣換新）：先離開展示（Windows 另外關掉「Volcano server」），Mac 在終端機輸入第一行、Windows 在 PowerShell 輸入第二行，再雙擊啟動腳本：'], size=9)
    d.add(cmd('pkill -f http.server; unzip -o -q ~/Downloads/volcano-update-v0.19.14.zip -d ~/volcano', 'tar -xf D:\\volcano-update-v0.19.14.zip -C C:\\volcano'))
    d.h('常見問題')
    qa = [('啟動後沒反應或網頁打不開', 'Windows 確認 `py --version` 有版本號；Mac 在終端機執行 `~/volcano/start-volcano.command` 看錯誤。不能直接雙擊 `index.html`。'),
          ('畫面很卡', '在頁首切到「地形貼圖」（B 版）。要每次都開 B 版，把啟動腳本最後一行的網址改成 `http://localhost:8000/relief.html`。'),
          ('日期、「昨天噴發」或星空不對', '檢查電腦的時間與時區（台北），並連上網路。'),
          ('畫面空白或換新版後沒變', '網頁會自己重新載入一次；還是不行就按 `Ctrl`＋`Shift`＋`R`（Mac 是 `Cmd`＋`Shift`＋`R`）。'),
          ('自動更新一直沒成功', '看 `.update/update.log` 的原因。Mac 若是 SSL 憑證錯誤，表示用的是 python.org 版 Python，要執行一次它附的「Install Certificates.command」。')]
    rows = [[d.p('狀況', bold=True, size=8.6, after=0), d.p('處理方式', bold=True, size=8.6, after=0)]] + [[d.p(a, bold=True, size=8.6, after=0), d.p(b, size=8.6, after=0)] for a, b in qa]
    d.table(rows, [5.6, 12.4], fills=[[SOFT, SOFT]] + [[None, None]] * len(qa), borders=True, pad=60)
    foot(d, '依 Windows 11 與 macOS 撰寫；Raspberry Pi 請看「樹莓派操作說明」。2026-11-09　移植操作手冊 2／2')
    return d


OUT = {
    '2026-11-07_guide-火山脈動觀眾說明.docx': (viewer, '全球火山活動 3D 地球：觀眾導覽'),
    '2026-11-09_guide-火山脈動樹莓派操作說明.docx': (staff, 'Raspberry Pi 展示機操作說明'),
    '2026-11-07_guide-火山脈動標題海報.docx': (poster, '全球火山活動 3D 地球：標題海報'),
    '2026-11-09_guide-火山脈動Windows與Mac移植操作手冊.docx': (port, '全球火山活動 3D 地球：Windows 與 Mac 移植操作手冊'),
}

if __name__ == '__main__':
    make_images()
    for name, (fn, title) in OUT.items():
        fn().save(os.path.join(DOCS, name), title)
        print('輸出', name)
