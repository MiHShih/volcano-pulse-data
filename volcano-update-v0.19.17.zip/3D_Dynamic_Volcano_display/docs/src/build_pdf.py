"""產生說明單張的 PDF：把 *.tpl.html 的圖示代號換成畫面上實際的 SVG 圖示，再用 Chrome 列印成 A4 PDF。

執行：python3 docs/src/build_pdf.py（全部），或在後面加名稱只產生其中幾張，例如 python3 docs/src/build_pdf.py tent
圖示來自 app.js 的 ico()，存在 icons.json（重新匯出：見 build_docx.py 開頭的說明）。
"""
import json
import os
import subprocess
import sys
import tempfile

SRC = os.path.dirname(os.path.abspath(__file__))
DOCS = os.path.dirname(SRC)
CHROME = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
OUT = {
    'viewer': '2026-11-07_guide-火山脈動觀眾說明.pdf',
    'staff': '2026-11-09_guide-火山脈動樹莓派操作說明.pdf',
    'poster': '2026-11-07_guide-火山脈動標題海報.pdf',
    'tent': '2026-11-07_guide-火山脈動螢幕立牌.pdf',
    'port': '2026-11-09_guide-火山脈動Windows與Mac移植操作手冊.pdf',
}
LOGO = ('<svg class="mark" viewBox="0 0 34 34" aria-hidden="true"><rect width="34" height="34" rx="9" fill="#14171C"/>'
        '<path d="M7 25 L14 12.5 H20 L27 25 Z" fill="none" stroke="#FFFFFF" stroke-width="1.8" stroke-linejoin="round"/>'
        '<circle cx="17" cy="8" r="2" fill="#E8590C"/></svg>')
# 頁首「立即更新」按鈕的圖示（同 app.js）
REFRESH = ('<svg class="ri" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" '
           'stroke-linejoin="round" aria-label="立即更新"><path d="M23 4 V10 H17"/><path d="M20.5 15 A9 9 0 1 1 18.4 5.6 L23 10"/></svg>')


def main():
    icons = json.load(open(os.path.join(SRC, 'icons.json'), encoding='utf-8'))
    icons['logo'] = LOGO
    icons['refresh'] = REFRESH
    with tempfile.TemporaryDirectory() as prof:
        for name in sys.argv[1:] or OUT:
            pdf = OUT[name]
            html = open(os.path.join(SRC, f'{name}.tpl.html'), encoding='utf-8').read()
            for k, v in icons.items():
                html = html.replace('{{%s}}' % k, v)
            assert '{{' not in html, f'{name}：還有沒換掉的代號'
            page = os.path.join(SRC, f'{name}.html')
            open(page, 'w', encoding='utf-8').write(html)
            subprocess.run([CHROME, '--headless=new', '--disable-gpu', f'--user-data-dir={prof}', '--no-pdf-header-footer',
                            f'--print-to-pdf={os.path.join(DOCS, pdf)}', 'file://' + page],
                           check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=120)
            print('輸出', pdf)


if __name__ == '__main__':
    main()
