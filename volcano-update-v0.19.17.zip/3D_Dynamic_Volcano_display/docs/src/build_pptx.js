// 火山脈動 Volcano Pulse 介紹簡報第二版（4:3，深色「星空夜幕」版面，15 張，每張附講稿）。
// 順序：為什麼要做 → 可以看到什麼 → 怎麼看、怎麼用（含現場示範）→ 架構與方法 → Open House 的迴響與下一步。
// 第一版（15 張，2026-11-09_slides-火山脈動展示頁面介紹.pptx）留在 docs/，不再由這支程式產生。
// 執行：NODE_PATH=<裝了 pptxgenjs 3.12 的 node_modules> node docs/src/build_pptx.js
// 截圖放在 docs/src/deck-img/（v0.19.14 本機畫面，2026-11-09 資料）；輸出到 docs/。
// tools/pack.py 不打包 .pptx 與 deck-img/，簡報不會進更新包。
const path = require('path');
const fs = require('fs');
const PptxGenJS = require('pptxgenjs');
const JSZip = require(require.resolve('jszip', { paths: [require.resolve('pptxgenjs')] }));

const DOCS = path.resolve(__dirname, '..');
const IMG = (f) => path.join(__dirname, 'deck-img', f);
const OUT = path.join(DOCS, '2026-11-09_slides-火山脈動展示頁面介紹第二版.pptx');

const FONT = 'Microsoft JhengHei';
const BG = '050912', SURF = '10172A', LINE = '26304A', INK = 'F1F3F5', SOFT = 'D7DCE5', MUTED = 'A3ADBF';
const ACC = 'FF7A45', ON_ACC = '050912';
const THEME = { dk1: BG, lt1: 'FFFFFF', dk2: SURF, lt2: SOFT, accent1: ACC, accent2: '74C0FC', accent3: '12B886', accent4: '6250D6', accent5: 'C98500', accent6: 'C92A2A', hlink: '74C0FC', folHlink: 'A5D8FF' };

const pres = new PptxGenJS();
pres.layout = 'LAYOUT_4x3';  // 10 × 7.5 吋
pres.title = 'Volcano Pulse 火山脈動：全球火山活動 3D 地球';
pres.author = '大屯火山觀測站';
pres.theme = { headFontFace: FONT, bodyFontFace: FONT };

const T = (o) => ({ fontFace: FONT, margin: 0, isTextBox: true, valign: 'top', ...o });

// 封面：英文名 VOLCANO PULSE 為主標題，分兩行
pres.defineSlideMaster({
  title: 'COVER', background: { color: BG },
  objects: [{ placeholder: { options: { name: 'title', type: 'title', x: 0.6, y: 1.85, w: 3.9, h: 1.7, fontFace: FONT, fontSize: 48, bold: true, color: INK, charSpacing: 1, margin: 0, valign: 'middle', align: 'left' }, text: '' } }],
});
pres.defineSlideMaster({
  title: 'CLOSING', background: { color: BG },
  objects: [{ placeholder: { options: { name: 'title', type: 'title', x: 0.6, y: 2.1, w: 3.6, h: 1.1, fontFace: FONT, fontSize: 58, bold: true, color: INK, margin: 0, valign: 'middle', align: 'left' }, text: '' } }],
});
pres.defineSlideMaster({
  title: 'CONTENT', background: { color: BG },
  objects: [
    { placeholder: { options: { name: 'eyebrow', type: 'body', x: 0.6, y: 0.42, w: 6, h: 0.3, fontFace: FONT, fontSize: 12, bold: true, color: ACC, charSpacing: 2, margin: 0, valign: 'middle' }, text: '' } },
    { placeholder: { options: { name: 'title', type: 'title', x: 0.6, y: 0.72, w: 8.8, h: 0.7, fontFace: FONT, fontSize: 30, bold: true, color: INK, margin: 0, valign: 'middle', align: 'left' }, text: '' } },
  ],
  slideNumber: { x: 8.8, y: 7.02, w: 0.6, h: 0.28, fontFace: FONT, fontSize: 10, color: MUTED, align: 'right' },
});

let sec = '';
const section = (t) => { sec = t; pres.addSection({ title: t }); };
const content = (eyebrow, title) => {
  const s = pres.addSlide({ masterName: 'CONTENT', sectionTitle: sec });
  s.addText(eyebrow, { placeholder: 'eyebrow' });
  s.addText(title, { placeholder: 'title' });
  return s;
};
const card = (s, x, y, w, h, o = {}) => s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y, w, h, rectRadius: 0.08, fill: { color: SURF }, line: { color: LINE, width: 0.75 }, ...o });
const badge = (s, n, x, y, d = 0.4, size = 15) => s.addText(String(n), T({ shape: pres.shapes.OVAL, x, y, w: d, h: d, fill: { color: ACC }, line: { color: BG, width: 2.5 }, color: ON_ACC, bold: true, fontSize: size, align: 'center', valign: 'middle' }));
const hline = (s, x, y, w, color = LINE) => s.addShape(pres.shapes.LINE, { x, y, w, h: 0, line: { color, width: 0.75 } });
const bullets = (items) => items.map((t, i) => ({ text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1 } }));
const chip = (s, text, x, y, w = 1.0) => s.addText(text, T({ shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.15, x, y, w, h: 0.3, fill: { color: ACC }, color: ON_ACC, bold: true, fontSize: 11, align: 'center', valign: 'middle' }));
// 截圖裁成固定框：w、h 給圖片原本的比例，box 是要顯示的範圍
const fill = (s, f, ratio, x, y, w, h, alt) => {
  const iw = Math.max(w, h * ratio);
  s.addImage({ path: IMG(f), x, y, w: iw, h: iw / ratio, sizing: { type: 'cover', w, h }, altText: alt });
};

// 1 封面 ---------------------------------------------------------------
section('開場');
{
  const s = pres.addSlide({ masterName: 'COVER', sectionTitle: sec });
  s.addImage({ path: IMG('cover-globe.jpg'), x: 3.0, y: 0, w: 7.0, h: 7.5, altText: '待機畫面：星空中的火山地球' });
  s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: 0.6, y: 0.55, w: 1.95, h: 0.5, rectRadius: 0.06, fill: { color: 'FFFFFF' }, line: { color: 'FFFFFF', width: 0 } });
  s.addImage({ path: path.join(DOCS, 'img', 'tvo.png'), x: 0.8, y: 0.63, w: 1.55, h: 0.34, altText: '大屯火山觀測站' });
  s.addText('全球火山活動 3D 地球', T({ x: 0.6, y: 1.5, w: 3.8, h: 0.35, fontSize: 14, bold: true, color: ACC, charSpacing: 3 }));
  s.addText('VOLCANO\nPULSE', { placeholder: 'title' });
  s.addText('火山脈動', T({ x: 0.6, y: 3.6, w: 3.9, h: 0.5, fontSize: 26, bold: true, color: INK, charSpacing: 6, valign: 'middle' }));
  s.addText('Global volcanic activity on a 3D Earth', T({ x: 0.6, y: 4.12, w: 3.9, h: 0.28, fontSize: 12, color: MUTED, valign: 'middle' }));
  const rows = [['1,214', '座全新世（Holocene）火山'], ['每天', '自動更新官方警戒與新聞'], ['離線', '沒有網路也能展示']];
  rows.forEach(([n, t], i) => {
    const y = 4.65 + i * 0.55;
    hline(s, 0.6, y, 3.3);
    s.addText(n, T({ x: 0.6, y: y + 0.08, w: 1.05, h: 0.44, fontSize: 22, bold: true, color: ACC, valign: 'middle' }));
    s.addText(t, T({ x: 1.7, y: y + 0.08, w: 2.3, h: 0.44, fontSize: 12, color: SOFT, valign: 'middle' }));
  });
  hline(s, 0.6, 6.3, 3.3);
  s.addText('［講者姓名］　大屯火山觀測站　［日期］', T({ x: 0.6, y: 6.85, w: 4.5, h: 0.3, fontSize: 11, color: MUTED }));
  s.addNotes(`【約 30 秒】
大家好，我是［姓名］。今天介紹觀測站的 Volcano Pulse，中文名「火山脈動」，一個全球火山活動的 3D 地球。「脈動」的意思是它每天更新，反映全球火山此刻的狀態。右邊是它待機時的樣子。
接下來分四段：為什麼要做、可以看到什麼、怎麼看怎麼用（含現場示範），最後是背後的架構與方法。

（全場約 14 分鐘，含 3 分鐘現場示範。時間不夠時，示範縮成 2 分鐘，或第 11 張資料流程只講最下面一句。）`);
}

// 2 問題 ---------------------------------------------------------------
section('一、為什麼要做');
{
  const s = content('一　為什麼要做', '今天，全球有幾座火山在噴發？');
  s.addText('這個問題的答案，散在四種地方', T({ x: 0.6, y: 1.55, w: 8.8, h: 0.35, fontSize: 15, color: SOFT, valign: 'middle' }));
  const src = [
    ['各國火山觀測機構', '美國 USGS、日本氣象廳、\n菲律賓 PHIVOLCS、紐西蘭 GeoNet', '各有網站與語言，警戒分級也不同'],
    ['航空火山灰警報', '給飛航用的 SIGMET 警報', '縮寫電文，一般人不容易讀'],
    ['全球火山週報', 'Smithsonian GVP 與 USGS 合編', '英文，一週才一期'],
    ['新聞與媒體', '最快，常有現場畫面', '語言多，來源品質不一'],
  ];
  src.forEach(([h, a, b], i) => {
    const x = i % 2 ? 5.1 : 0.6, y = 2.1 + Math.floor(i / 2) * 1.75;
    card(s, x, y, 4.3, 1.55);
    s.addText(h, T({ x: x + 0.25, y: y + 0.18, w: 3.8, h: 0.36, fontSize: 17, bold: true, color: INK, valign: 'middle' }));
    s.addText(a, T({ x: x + 0.25, y: y + 0.6, w: 3.85, h: 0.5, fontSize: 12, color: SOFT, lineSpacingMultiple: 1.1 }));
    s.addText(b, T({ x: x + 0.25, y: y + 1.13, w: 3.85, h: 0.28, fontSize: 12.5, bold: true, color: ACC, valign: 'middle' }));
  });
  s.addText([
    { text: '資訊都有，只是散在各處', options: { fontSize: 20, bold: true, color: INK, breakLine: true } },
    { text: '要拼出全貌，得自己看好幾個網站、對照好幾種警戒分級', options: { fontSize: 13, color: SOFT } },
  ], T({ shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.08, x: 0.6, y: 5.75, w: 8.8, h: 0.95, fill: { color: SURF }, line: { color: ACC, width: 1.25 }, align: 'center', valign: 'middle', lineSpacingMultiple: 1.2 }));
  s.addNotes(`【約 45 秒】
先問大家一個問題：今天全球有幾座火山在噴發？
這個問題其實不好回答。資訊都有，但散在四種地方：
各國火山觀測機構，例如美國 USGS、日本氣象廳、菲律賓 PHIVOLCS、紐西蘭 GeoNet，各有自己的網站、語言和警戒分級；
給飛航用的火山灰警報是縮寫電文；
Smithsonian 的全球火山週報是英文，一週才一期；
新聞最快，但語言多、品質不一。
要拼出全貌，得自己看好幾個網站、對照好幾種分級。火山脈動想做的，就是把這些整理到一個畫面上。
（答案留到後面：以 11 月 9 日為例，畫面上噴發中 8 座、警戒升高 20 座。）`);
}

// 3 兩個場合 -----------------------------------------------------------
{
  const s = content('一　為什麼要做', '兩個場合，同一個需求');
  const cols = [
    [0.6, 'tour-wide.jpg', '待機導覽飛到櫻島', 'Open House 展場', ['自動展示：沒人操作時自己轉、自己介紹火山', '民眾自己動手看：點火山就打開詳細介紹', '要看得懂：觀眾多半不是專業背景', '不用人顧：外部連結改成 QR code']],
    [5.1, 'main-watch.jpg', '本日關注火山清單', '平日快速瀏覽', ['每天想知道哪裡在噴、哪裡升警戒', '官方警戒、火山灰警報、新聞在同一頁', '「本日關注」一眼看到今天的重點']],
  ];
  for (const [x, img, alt, head, items] of cols) {
    card(s, x, 1.65, 4.3, 4.45);
    s.addImage({ path: IMG(img), x: x + 0.15, y: 1.8, w: 4.0, h: 2.26, altText: alt });
    s.addText(head, T({ x: x + 0.3, y: 4.25, w: 3.8, h: 0.4, fontSize: 18, bold: true, color: INK, valign: 'middle' }));
    s.addText(bullets(items), T({ x: x + 0.3, y: 4.72, w: 3.85, h: 1.33, fontSize: 12.5, color: SOFT, paraSpaceAfter: 4 }));
  }
  s.addText([{ text: '共同需求　', options: { bold: true, color: ACC } }, { text: '一個畫面，看懂全球火山今天怎麼了', options: { bold: true, color: INK } }],
    T({ x: 0.6, y: 6.3, w: 8.8, h: 0.45, fontSize: 18, align: 'center', valign: 'middle' }));
  s.addNotes(`【約 1 分鐘】
這個想法來自兩個場合。
第一是 Open House：展場要能自動展示，也要讓民眾自己動手看。沒人操作時它會自己轉、自己飛到火山介紹；民眾可以自己點火山，打開詳細介紹；畫面要讓非專業背景的觀眾看得懂，而且不用人顧，觀眾點外部連結也不會跑出去，而是跳出 QR code，用手機看原文。
第二是平日：我們每天想知道全球哪裡在噴、哪裡升警戒。現在官方警戒、航空火山灰警報和新聞整理在同一頁，每天自動更新，打開「本日關注」就看到重點。
兩個場合其實是同一個需求：一個畫面，看懂全球火山今天怎麼了。`);
}

// 4 設計目標 -----------------------------------------------------------
{
  const s = content('一　為什麼要做', '三個設計目標');
  const goals = [
    ['01', '一眼看懂', '顏色代表狀態\n一個畫面看完\n全球 1,214 座火山'],
    ['02', '每天自動更新', '資料站每天整理\n官方警戒、火山灰警報\n與新聞，不用人手更新'],
    ['03', '沒人顧也能跑', '待機時自己介紹火山\n外部連結改 QR code\n沒網路也照常展示'],
  ];
  goals.forEach(([n, h, t], i) => {
    const x = 0.6 + i * 2.98, y = 1.9;
    card(s, x, y, 2.84, 3.9);
    s.addText(n, T({ x: x + 0.3, y: y + 0.35, w: 1.5, h: 0.75, fontSize: 40, bold: true, color: ACC, valign: 'middle' }));
    s.addText(h, T({ x: x + 0.3, y: y + 1.35, w: 2.4, h: 0.45, fontSize: 20, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: x + 0.3, y: y + 2.0, w: 2.4, h: 1.5, fontSize: 14, color: SOFT, lineSpacingMultiple: 1.3 }));
  });
  s.addNotes(`【約 45 秒】
所以設計時定了三個目標。
一眼看懂：用顏色代表狀態，一個畫面看完全球 1,214 座火山。
每天自動更新：資料站每天整理官方警戒、火山灰警報和新聞，不需要人手更新。
沒人顧也能跑：待機時自己介紹火山，外部連結改成 QR code，沒有網路也照常展示。`);
}

// 5 打開就看到 ---------------------------------------------------------
section('二、可以看到什麼');
{
  const s = content('二　可以看到什麼', '打開就看到：今天全球火山的狀態');
  const X = 0.6, Y = 1.6, W = 5.9, H = W / 1.6;
  s.addImage({ path: IMG('main.jpg'), x: X, y: Y, w: W, h: H, altText: '展示頁面主畫面：左邊地球，右邊概況清單' });
  const at = (fx, fy) => [X + W * fx - 0.2, Y + H * fy - 0.2];
  badge(s, 1, ...at(0.375, 0.54), 0.4, 14);
  badge(s, 2, ...at(0.735, 0.236), 0.4, 14);
  badge(s, 3, ...at(0.745, 0.8), 0.4, 14);
  const items = [
    ['地球', '1,214 座全新世火山\n圖示顏色是今天的狀態'],
    ['本日關注', '今天值得注意的火山\n每座附一句理由'],
    ['概況清單', '最新噴發、7 天內噴發、\n警戒升高、官方週報'],
  ];
  items.forEach(([h, t], i) => {
    const y = 1.65 + i * 1.2;
    badge(s, i + 1, 6.8, y, 0.36, 12);
    s.addText(h, T({ x: 7.3, y: y - 0.01, w: 2.1, h: 0.38, fontSize: 16, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: 7.3, y: y + 0.4, w: 2.15, h: 0.65, fontSize: 11.5, color: SOFT, lineSpacingMultiple: 1.15 }));
  });
  s.addText('本日關注依理由分七組，越前面越優先', T({ x: 0.6, y: 5.6, w: 8.8, h: 0.3, fontSize: 12, bold: true, color: ACC, valign: 'middle' }));
  const groups = ['火山災害', '警戒提升', '劇烈噴發', '新噴發', '全球重大報導', '媒體報導', '鄰近台灣'];
  const cw = (8.8 - 0.08 * 6) / 7;
  groups.forEach((g, i) => s.addText(g, T({ shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.06, x: 0.6 + i * (cw + 0.08), y: 6.0, w: cw, h: 0.42, fill: { color: SURF }, line: { color: LINE, width: 0.75 }, fontSize: 11.5, bold: true, color: INK, align: 'center', valign: 'middle' })));
  s.addText('一座火山只放在最優先的一組，其他理由變成小標籤', T({ x: 0.6, y: 6.55, w: 8.8, h: 0.28, fontSize: 11, color: MUTED, valign: 'middle' }));
  s.addNotes(`【約 1 分鐘】
打開就是這個畫面。
1 左邊是地球，上面是 1,214 座全新世火山，圖示的顏色是今天的狀態。
2 右上深色的「本日關注火山」是今天的重點：資料站把昨天和今天有特別狀況的火山挑出來，每座附一句為什麼要關注。理由分成下面這七組，越前面越優先；一座火山只放在最優先的那一組。
3 再往下是最新噴發活動、7 天內噴發、警戒升高中和官方週報，點開就是完整清單。
以 11 月 9 日為例：Puracé 和 Nevados de Chillán 是全球重大報導，Popocatépetl 是媒體報導，而且有直播可以看。
（「劇烈噴發」的門檻是依民航機巡航高度訂的：灰雲 9 公里以上，或高出山頂 3 公里，不是官方分級。）`);
}

// 6 點一座火山 ---------------------------------------------------------
{
  const s = content('二　可以看到什麼', '點一座火山：詳細卡與近 30 天活動');
  const X = 0.6, Y = 1.6, H = 5.1, W = H * 720 / 1592;
  s.addImage({ path: IMG('card-semeru.png'), x: X, y: Y, w: W, h: H, altText: 'Semeru 塞梅魯火山的詳細卡' });
  [0.236, 0.38, 0.7].forEach((fy, i) => badge(s, i + 1, X + W + 0.06, Y + H * fy - 0.18, 0.36, 12));
  s.addText('Semeru 塞梅魯火山', T({ x: 0.6, y: 6.8, w: 2.6, h: 0.25, fontSize: 10, color: MUTED }));
  const AW = 2.75, AH = AW * 802 / 622;
  s.addImage({ path: IMG('act-273030.png'), x: 3.45, y: 1.6, w: AW, h: AH, altText: 'Mayon 馬榮火山的近 30 天活動圖' });
  s.addText('近 30 天活動：Mayon 馬榮火山', T({ x: 3.45, y: 1.6 + AH + 0.08, w: AW, h: 0.25, fontSize: 10, color: MUTED }));
  card(s, 3.45, 5.75, AW, 0.95);
  s.addText('30 天內至少 5 天噴發、\n最近 10 天還在噴，才畫活動圖', T({ x: 3.6, y: 5.85, w: AW - 0.3, h: 0.75, fontSize: 11, color: SOFT, lineSpacingMultiple: 1.15, valign: 'middle' }));
  const rows = [
    ['狀態與警報標籤', '噴發中幾天、火山灰警報、\n灰雲高度'],
    ['中文簡介', '依 GVP 地質摘要，\nClaude 整理成 2 到 3 句'],
    ['近 30 天活動', '灰雲高度、每日活動、\n官方警戒的變化'],
    ['官方警戒', '美、日、菲、紐的等級與\n最近 3 則火山灰警報'],
    ['直播與原文', '直播在畫面裡播放；\n原文連結顯示 QR code'],
  ];
  rows.forEach(([h, t], i) => {
    const y = 1.62 + i * 1.0;
    badge(s, i + 1, 6.5, y, 0.34, 11);
    s.addText(h, T({ x: 6.95, y: y - 0.02, w: 2.5, h: 0.36, fontSize: 14, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: 6.95, y: y + 0.36, w: 2.5, h: 0.55, fontSize: 11, color: SOFT, lineSpacingMultiple: 1.1 }));
  });
  s.addNotes(`【約 1 分鐘】
點一座火山，右側會打開詳細卡，左邊以 Semeru 為例。
1 最上面是狀態色帶與井字標籤，例如噴發中幾天、火山灰警報幾則、灰雲多高。
2 接著是 2 到 3 句中文簡介，依 GVP 的地質摘要由 Claude 整理。
3 最近真的在活動的火山，會多一張近 30 天活動圖，像中間 Mayon 的例子：上面的藍柱是火山灰警報的灰雲高度，中間每天一格是當天的活動，最下面一條是官方警戒等級；點某一天，下方會顯示當天紀錄。
4、5 卡片再往下，有美、日、菲、紐的官方警戒等級、最近 3 則航空火山灰警報，以及直播影像。直播在畫面裡播放，原文連結則跳出 QR code。`);
}

// 7 兩種模式 -----------------------------------------------------------
{
  const s = content('二　可以看到什麼', '兩種模式：展場與教學');
  const cols = [
    [0.6, 'tour-map.jpg', 1445 / 1025, '待機導覽飛到櫻島並打開詳細卡', '展場模式', ['3 分鐘沒人操作，回到全球慢慢轉', '真實星空，地球顯示此刻的日夜', '待機導覽：飛到十年火山或噴發中的火山', '有人一碰就停下來'], '吸引路過的觀眾停下來，自己動手看'],
    [5.1, 'teach.jpg', 1.6, '教學模式：板塊邊界、地震分布與教學火山選單', '教學模式', ['4 種板塊邊界：張裂、隱沒、碰撞、錯動', '約 2.4 萬筆地震（1976 年起，規模 5.5 以上）', '13 座教學火山，照成因分 8 類', '含大屯火山群與龜山島'], '看懂火山為什麼沿著板塊邊界分布'],
  ];
  for (const [x, img, ratio, alt, head, items, goal] of cols) {
    card(s, x, 1.65, 4.3, 4.75);
    fill(s, img, ratio, x + 0.15, 1.8, 4.0, 2.05, alt);
    s.addText(head, T({ x: x + 0.3, y: 3.97, w: 3.8, h: 0.4, fontSize: 18, bold: true, color: INK, valign: 'middle' }));
    s.addText(bullets(items), T({ x: x + 0.3, y: 4.45, w: 3.85, h: 1.25, fontSize: 12, color: SOFT, paraSpaceAfter: 4 }));
    hline(s, x + 0.3, 5.75, 3.7);
    s.addText('希望可以達到', T({ x: x + 0.3, y: 5.83, w: 3.7, h: 0.22, fontSize: 11, bold: true, color: ACC, valign: 'middle' }));
    s.addText(goal, T({ x: x + 0.3, y: 6.06, w: 3.8, h: 0.27, fontSize: 13, bold: true, color: INK, valign: 'middle' }));
  }
  s.addText('教學內容由 Claude 起草，尚未人工校對', T({ x: 0.6, y: 6.55, w: 8.8, h: 0.28, fontSize: 11, color: MUTED, valign: 'middle' }));
  s.addNotes(`【約 45 秒】
另外有兩種模式。
左邊是展場模式：預設 3 分鐘沒人碰，它會關掉卡片、回到全球慢慢轉，背景是真實星空，地球上是此刻真正的白天和黑夜。打開「待機導覽」的話，轉到十年火山或噴發中的火山就飛過去介紹，像圖上飛到櫻島；有人一碰就停在那裡。
右邊是教學模式：顯示四種板塊邊界，加上 1976 年以來規模 5.5 以上、大約 2.4 萬筆地震，顏色是震源深度，可以清楚看到環太平洋火山帶。選單裡有 13 座教學火山，照成因分 8 類，包括台灣北部的大屯火山群和龜山島。
兩種模式各有希望達到的目標：展場模式是吸引路過的觀眾停下來，自己動手看；教學模式是讓學生看懂火山為什麼沿著板塊邊界分布。
教學這部分內容由 Claude 起草，還沒有人工校對。`);
}

// 8 怎麼看 -------------------------------------------------------------
section('三、怎麼看、怎麼用');
{
  const s = content('三　怎麼看、怎麼用', '顏色是狀態，形狀是活動');
  const head = (t, y) => s.addText(t, T({ x: 0.6, y, w: 8.8, h: 0.28, fontSize: 12, bold: true, color: ACC, valign: 'middle' }));
  head('顏色是狀態', 1.6);
  const colors = [
    ['C92A2A', 1, '噴發中', '連續 2 天以上\n有噴發'],
    ['6250D6', 1, '警戒升高', '官方警戒等級\n高於平常'],
    ['C98500', 1, '7 天內噴發', '近 7 天有火山灰\n警報或週報'],
    ['14996A', 1, '官方週報', '出現在最新一期\nGVP 週報'],
    ['64748B', 0, '資料來源', 'Claude 整理的報導\n未經官方確認'],
  ];
  const cw = (8.8 - 0.15 * 4) / 5;
  colors.forEach(([c, solid, h, t], i) => {
    const x = 0.6 + i * (cw + 0.15), y = 1.95;
    card(s, x, y, cw, 1.45);
    s.addShape(pres.shapes.OVAL, { x: x + 0.18, y: y + 0.18, w: 0.34, h: 0.34, fill: { color: solid ? c : SURF }, line: { color: c, width: solid ? 0 : 3 } });
    s.addText(h, T({ x: x + 0.18, y: y + 0.6, w: cw - 0.3, h: 0.3, fontSize: 13, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: x + 0.18, y: y + 0.93, w: cw - 0.28, h: 0.45, fontSize: 10.5, color: SOFT, lineSpacingMultiple: 1.05 }));
  });
  head('形狀是活動', 3.62);
  s.addImage({ path: IMG('legend.png'), x: 0.6, y: 3.95, w: 8.8, h: 8.8 * 96 / 2177, altText: '展示頁面的圖例列' });
  s.addText('噴煙＝噴發　實心圓＝警戒或週報　空心圓＝一般報導　三角形＝十年火山', T({ x: 0.6, y: 4.42, w: 8.8, h: 0.3, fontSize: 12, color: SOFT, valign: 'middle' }));
  head('三個基本操作', 4.95);
  const ops = [
    ['拖曳與縮放', '拖曳旋轉地球，滾輪縮放'],
    ['點火山', '地球飛過去，右側打開詳細卡'],
    ['區域與搜尋', '上方按鈕切換區域；\n搜尋火山中英文名或國家'],
  ];
  ops.forEach(([h, t], i) => {
    const x = 0.6 + i * 2.98;
    card(s, x, 5.28, 2.84, 1.15);
    badge(s, i + 1, x + 0.18, 5.42, 0.36, 12);
    s.addText(h, T({ x: x + 0.65, y: 5.42, w: 2.05, h: 0.36, fontSize: 14, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: x + 0.18, y: 5.9, w: 2.5, h: 0.62, fontSize: 11.5, color: SOFT, lineSpacingMultiple: 1.1 }));
  });
  s.addNotes(`【約 45 秒】
怎麼看，記兩件事就好。
顏色是狀態：紅色是噴發中，紫色是官方警戒升高，琥珀色是 7 天內噴發，青綠是出現在 GVP 週報，石板灰是 Claude 從新聞整理、還沒有官方確認的。
形狀是活動：噴煙圖示是噴發，實心圓是警戒或週報，空心圓是一般報導，三角形是十年火山。中間那一列就是畫面上的圖例。
操作也只有三個：拖曳旋轉、滾輪縮放；點火山打開詳細卡；用上方的區域按鈕或搜尋框找火山，中英文都可以。
接下來直接操作給大家看。`);
}

// 9 現場示範 -----------------------------------------------------------
{
  const s = content('三　怎麼看、怎麼用', '現場示範（約 3 分鐘）');
  const steps = [
    ['待機畫面', '20 秒', '星空、日夜與自轉\n動一下滑鼠，台灣轉回中間'],
    ['本日關注', '30 秒', '今天有哪幾組、為什麼\n點第一座火山飛過去'],
    ['詳細卡', '40 秒', '色帶、標籤、中文簡介\n點活動圖上的某一天'],
    ['直播與 QR code', '30 秒', '播放直播，按 Esc 關掉\n點「原文」，掃 QR code'],
    ['教學模式', '40 秒', '打開教學模式\n按「在地圖上看火環」\n再點大屯火山群'],
    ['回到簡報', '10 秒', '示範完把待機時間\n改回 3 分鐘'],
  ];
  steps.forEach(([h, t, d], i) => {
    const x = 0.6 + (i % 3) * 2.98, y = 1.65 + Math.floor(i / 3) * 2.4;
    card(s, x, y, 2.84, 2.2);
    badge(s, i + 1, x + 0.2, y + 0.2, 0.44, 16);
    s.addText(t, T({ x: x + 1.5, y: y + 0.27, w: 1.14, h: 0.3, fontSize: 11, color: MUTED, align: 'right', valign: 'middle' }));
    s.addText(h, T({ x: x + 0.2, y: y + 0.8, w: 2.5, h: 0.36, fontSize: 16, bold: true, color: INK, valign: 'middle' }));
    s.addText(d, T({ x: x + 0.2, y: y + 1.22, w: 2.48, h: 0.85, fontSize: 12, color: SOFT, lineSpacingMultiple: 1.15 }));
  });
  s.addText('沒有網路時：直播與衛星影像看不到，其他照常；也可以改用前面的截圖講解', T({ x: 0.6, y: 6.6, w: 8.2, h: 0.3, fontSize: 11, color: MUTED }));
  s.addNotes(`【約 3 分鐘】接下來直接操作給大家看。

示範前準備（上台前做好）
・展示機開 A 版（3D 地形），確認有網路，頁首「資料更新」是當天日期。
・設定頁（左上齒輪）把待機時間改成 1 分鐘，簡報時沒人碰，切過去時就已經在待機；「待機導覽」先關。
・準備好手機，等一下掃 QR code。
・先找好一座標「可看直播」的火山（本日關注或最新噴發活動裡有標示）。

1 待機畫面（20 秒）
介紹星空、白天與黑夜、地球自轉。動一下滑鼠，地球停下來，台灣轉回正中間。

2 本日關注（30 秒）
念一下今天有哪幾組、每座為什麼被挑出來。點第一座火山，地球飛過去，右側打開詳細卡。

3 詳細卡（40 秒）
指出色帶、井字標籤、中文簡介。往下捲到「近 30 天活動」，點其中一天，圖下方出現當天紀錄。

4 直播與 QR code（30 秒）
點直播影像，在畫面裡播放（預設靜音），按 Esc 關掉。點「原文」或 GVP 連結，跳出 QR code，用手機掃給大家看：展示機本身不會開出外部網頁。

5 教學模式（40 秒）
左上地球按鈕「圖層與教學」打開教學模式；右側「成因」分頁按「在地圖上看火環」，板塊邊界與地震一起出現。再從左邊教學火山選單點「大屯火山群」，讓大家看自己家的火山。

6 回到簡報（10 秒）
不用等它回到待機，直接切回投影片。示範結束後記得把待機時間改回 3 分鐘。

備案
・沒有網路：直播與衛星影像看不到，地形、資料與其他功能照常（都在本機）。
・展示機出狀況：略過示範，用第 5 到第 8 張的截圖講解。`);
}

// 10 系統架構 ----------------------------------------------------------
section('四、架構與方法');
{
  const s = content('四　架構與方法', '系統架構：三個部分');
  const cols = [
    ['資料站', '觀測站', ['抓官方警戒與火山灰警報', 'Claude 整理新聞與每日報告', '算每日統計與火山周邊地形圖', '每天發布資料包']],
    ['GitHub', '資料與程式', ['資料包：每天一份', '程式新版：展示機自動更新', '私有資料庫：按月存檔']],
    ['展示機', '三種電腦都穩定運作', ['樹莓派、Windows、Mac', '本機伺服器＋瀏覽器全螢幕', '地形與資料都在本機', '沒有網路也照常展示']],
  ];
  cols.forEach(([c, h, items], i) => {
    const x = 0.6 + i * 3.05, y = 1.65;
    card(s, x, y, 2.7, 2.85, i === 2 ? { line: { color: ACC, width: 1.25 } } : {});
    chip(s, c, x + 0.2, y + 0.2, 1.0);
    s.addText(h, T({ x: x + 0.2, y: y + 0.62, w: 2.4, h: 0.38, fontSize: 15, bold: true, color: INK, valign: 'middle' }));
    s.addText(bullets(items), T({ x: x + 0.2, y: y + 1.1, w: 2.38, h: 1.65, fontSize: 11.5, color: SOFT, paraSpaceAfter: 5 }));
    if (i < 2) s.addShape(pres.shapes.LINE, { x: x + 2.74, y: y + 1.42, w: 0.27, h: 0, line: { color: '5C6B88', width: 1.5, endArrowType: 'triangle' } });
  });
  s.addText('展示機上的兩種地圖', T({ x: 0.6, y: 4.7, w: 8.8, h: 0.28, fontSize: 12, bold: true, color: ACC, valign: 'middle' }));
  const maps = [
    [0.6, '3D 地形', 'MapLibre GL JS＋AWS 地形圖磚\n真實起伏，拉近時疊衛星影像'],
    [5.1, '地形貼圖', 'globe.gl＋預先算好的地形貼圖\n完全離線，近看時換成火山周邊地形圖'],
  ];
  for (const [x, h, t] of maps) {
    card(s, x, 5.05, 4.3, 1.05);
    s.addText(h, T({ x: x + 0.25, y: 5.15, w: 3.8, h: 0.32, fontSize: 14, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: x + 0.25, y: 5.5, w: 3.9, h: 0.52, fontSize: 11, color: SOFT, lineSpacingMultiple: 1.1 }));
  }
  s.addText([{ text: '設計原則　', options: { bold: true, color: ACC } }, { text: '計算放在資料站，展示機只讀檔案', options: { bold: true, color: INK } }],
    T({ x: 0.6, y: 6.3, w: 8.8, h: 0.42, fontSize: 16, align: 'center', valign: 'middle' }));
  s.addNotes(`【約 1 分鐘】
接下來是背後的架構，分三個部分。
左邊是資料站，放在觀測站：每天抓官方資料，用 Claude API 整理新聞和每日報告，算好每日統計和火山周邊的地形圖，再發布出去。
中間是 GitHub：放每天的資料包和程式新版；每天的成果另外存進私有資料庫，按月保存，日後查歷史不用重新搜尋。
右邊是展示機：目前樹莓派、Windows、Mac 三種電腦都穩定運作，在本機開一個網頁伺服器，用瀏覽器全螢幕顯示。地形圖磚和資料都在本機，完整安裝檔約 3.7 GB，所以沒網路也能展示。
地圖有兩個版本：3D 地形版用 MapLibre，有真實起伏，拉近時疊衛星影像；地形貼圖版用 globe.gl，完全離線。
設計原則只有一條：計算放在資料站，展示機只讀檔案。`);
}

// 11 資料流程 ----------------------------------------------------------
{
  const s = content('四　架構與方法', '每天的資料流程');
  const nodes = [
    ['07:00', '每日報告', 'Claude 搜尋新聞\n與各國重要媒體\n整理每座火山動態'],
    ['09:00', '資料站', 'GVP 週報、USGS\n航空火山灰警報\n日菲紐警戒等級'],
    ['發布', '資料包', '推上 GitHub Pages\n每天一份快照'],
    ['每 30 分', '展示機', '檢查新資料\n待機時自動重新載入'],
  ];
  nodes.forEach(([t, h, d], i) => {
    const x = 0.6 + i * 2.3, y = 1.8;
    card(s, x, y, 1.9, 2.15, i === 3 ? { line: { color: ACC, width: 1.25 } } : {});
    chip(s, t, x + 0.18, y + 0.2, 1.0);
    s.addText(h, T({ x: x + 0.18, y: y + 0.65, w: 1.6, h: 0.38, fontSize: 17, bold: true, color: INK, valign: 'middle' }));
    s.addText(d, T({ x: x + 0.18, y: y + 1.1, w: 1.62, h: 0.95, fontSize: 11.5, color: SOFT, lineSpacingMultiple: 1.15 }));
    if (i < 3) s.addShape(pres.shapes.LINE, { x: x + 1.95, y: y + 1.22, w: 0.3, h: 0, line: { color: '5C6B88', width: 1.5, endArrowType: 'triangle' } });
  });
  const branch = [[2.9, '私有資料庫', '每天的成果按月存檔\n日後查歷史不用重搜'], [5.2, '程式新版', '展示機開機時\n自動檢查、核對、更新']];
  for (const [x, h, d] of branch) {
    s.addShape(pres.shapes.LINE, { x: x + 0.95, y: 3.95, w: 0, h: 0.5, line: { color: '3A4766', width: 1.5 } });
    s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x, y: 4.45, w: 1.9, h: 1.2, rectRadius: 0.08, fill: { color: BG }, line: { color: '3A4766', width: 1, dashType: 'dash' } });
    s.addText(h, T({ x: x + 0.18, y: 4.57, w: 1.6, h: 0.3, fontSize: 13, bold: true, color: INK, valign: 'middle' }));
    s.addText(d, T({ x: x + 0.18, y: 4.9, w: 1.65, h: 0.65, fontSize: 11, color: MUTED, lineSpacingMultiple: 1.1 }));
  }
  hline(s, 0.6, 6.0, 8.8);
  s.addText([{ text: '有新資料時，', options: { color: SOFT } }, { text: '等到待機才重新載入', options: { color: ACC, bold: true } }, { text: '，不會打斷正在操作的觀眾', options: { color: SOFT } }],
    T({ x: 0.6, y: 6.15, w: 8.8, h: 0.4, fontSize: 15, valign: 'middle' }));
  s.addNotes(`【約 1 分鐘】
每天的流程是這樣。
早上 7 點，用 Claude API 跑「每日報告」：搜尋全球新聞和各國重要媒體，整理每座火山的動態與災情。
9 點，資料站抓官方資料：GVP 週報、USGS 警戒、NOAA 的航空火山灰警報，以及日本、菲律賓、紐西蘭的警戒等級，合併後算出每日統計，打包推上 GitHub Pages。
各台展示機每 30 分鐘檢查一次，有新資料就等到待機時才重新載入，不會打斷正在操作的觀眾。
當天的成果另外存進私有資料庫；程式有新版時，展示機開機會自己檢查、核對、備份後更新，有問題可以退回上一版。`);
}

// 12 資料來源與可信度 --------------------------------------------------
{
  const s = content('四　架構與方法', '資料來源與可信度');
  const cols = [
    // 縮寫的全名用小字寫在下一行（同一段落內換行，跟著項目符號縮排）
    [0.6, '官方資料', '照原文顯示', [['Smithsonian GVP：火山資料庫與週報', 'GVP：Global Volcanism Program'],
      ['USGS HANS：美國火山警戒色碼', 'USGS：U.S. Geological Survey', 'HANS：Hazard Notification System'],
      ['NOAA：航空火山灰警報（SIGMET）', 'NOAA：National Oceanic and Atmospheric Administration', 'SIGMET：Significant Meteorological Information'],
      ['日本氣象廳、菲律賓 PHIVOLCS、紐西蘭 GeoNet 警戒等級', 'PHIVOLCS：Philippine Institute of Volcanology and Seismology']]],
    [5.1, 'Claude 整理', '畫面上標明未經官方確認', ['每日報告：搜尋新聞與各國重要媒體', '中文簡介：依 GVP 地質摘要整理', '教學內容：Claude 起草，尚未人工校對', '每一則都附原文連結（QR code）']],
  ];
  const runs = (items) => items.flatMap((it, i) => {
    const [t, ...full] = Array.isArray(it) ? it : [it];
    const last = i === items.length - 1;
    return [{ text: t, options: { bullet: { indent: 14 }, breakLine: !full.length && !last } },
      ...full.map((f, k) => ({ text: f, options: { softBreakBefore: true, fontSize: 9, color: MUTED, breakLine: k === full.length - 1 && !last } }))];
  });
  for (const [x, h, sub, items] of cols) {
    card(s, x, 1.65, 4.3, 4.25);
    s.addText(h, T({ x: x + 0.3, y: 1.85, w: 3.7, h: 0.4, fontSize: 20, bold: true, color: INK, valign: 'middle' }));
    s.addText(sub, T({ x: x + 0.3, y: 2.3, w: 3.7, h: 0.28, fontSize: 12, color: ACC, bold: true }));
    s.addText(runs(items), T({ x: x + 0.3, y: 2.75, w: 3.85, h: 3.0, fontSize: 13.5, color: SOFT, paraSpaceAfter: 7, lineSpacingMultiple: 1.05 }));
  }
  s.addText('本網頁非官方預警，警戒資訊以各國火山觀測機構公告為準', T({ shape: pres.shapes.ROUNDED_RECTANGLE, rectRadius: 0.08, x: 0.6, y: 6.12, w: 8.8, h: 0.6, fill: { color: SURF }, line: { color: ACC, width: 1.25 }, fontSize: 16, bold: true, color: INK, align: 'center', valign: 'middle' }));
  s.addNotes(`【約 45 秒】
資料分兩類。
官方資料照原文顯示：Smithsonian 的 GVP、美國 USGS、NOAA，以及日本、菲律賓、紐西蘭的火山觀測機構。
Claude 整理的部分，包括每日報告、中文簡介和教學內容，在畫面上都標明未經官方確認或未經人工校對，而且每一則都附原文連結。
所以這個網頁不是官方預警，警戒資訊一律以各國火山觀測機構的公告為準，頁尾也一直寫著這句話。`);
}

// 13 Open House 的迴響 -------------------------------------------------
section('收尾');
{
  const s = content('收尾', 'Open House 的迴響');
  card(s, 0.6, 1.65, 8.8, 0.85);
  chip(s, '目前狀態', 0.85, 1.92, 1.1);
  s.addText('仍是內部開發測試版（v0.19.14），還沒有公開網址', T({ x: 2.2, y: 1.8, w: 7.0, h: 0.55, fontSize: 16, bold: true, color: INK, valign: 'middle' }));
  s.addText('但在 Open House 大受好評', T({ x: 0.6, y: 2.85, w: 8.8, h: 0.6, fontSize: 28, bold: true, color: ACC, valign: 'middle' }));
  s.addText('大多數觀眾提出兩個要求', T({ x: 0.6, y: 3.5, w: 8.8, h: 0.35, fontSize: 15, color: SOFT, valign: 'middle' }));
  const asks = [
    [0.6, '公開網址', '不用到現場\n用瀏覽器就能打開'],
    [5.1, '行動裝置安裝', '裝在自己的\n行動裝置上使用'],
  ];
  asks.forEach(([x, h, t], i) => {
    const y = 4.1;
    card(s, x, y, 4.3, 2.4);
    const ix = x + 0.4, iy = y + 0.55;
    if (i === 0) {  // 瀏覽器視窗
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: ix, y: iy, w: 1.15, h: 0.85, rectRadius: 0.06, fill: { color: SURF }, line: { color: ACC, width: 2 } });
      s.addShape(pres.shapes.LINE, { x: ix, y: iy + 0.22, w: 1.15, h: 0, line: { color: ACC, width: 2 } });
      [0, 1, 2].forEach((k) => s.addShape(pres.shapes.OVAL, { x: ix + 0.1 + k * 0.1, y: iy + 0.08, w: 0.06, h: 0.06, fill: { color: ACC }, line: { color: ACC, width: 0 } }));
    } else {  // 平板與手機
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: ix, y: iy - 0.1, w: 0.85, h: 1.1, rectRadius: 0.08, fill: { color: SURF }, line: { color: ACC, width: 2 } });
      s.addShape(pres.shapes.ROUNDED_RECTANGLE, { x: ix + 0.65, y: iy + 0.3, w: 0.42, h: 0.75, rectRadius: 0.06, fill: { color: SURF }, line: { color: ACC, width: 2 } });
    }
    s.addText(h, T({ x: x + 1.9, y: y + 0.55, w: 2.25, h: 0.45, fontSize: 20, bold: true, color: INK, valign: 'middle' }));
    s.addText(t, T({ x: x + 1.9, y: y + 1.1, w: 2.25, h: 0.8, fontSize: 13, color: SOFT, lineSpacingMultiple: 1.25 }));
  });
  s.addNotes(`【約 45 秒】
最後分享 Open House 的反應。
火山脈動目前仍是內部開發測試版，只在展示機上運作，還沒有公開網址。
但在 Open House 上大受好評，大多數觀眾提出兩個要求：一是公開網址，不用到現場也能打開；二是能在自己的行動裝置上安裝使用。
這也是接下來要評估的方向，下一張一起說。`);
}

// 14 限制與下一步 ------------------------------------------------------
{
  const s = content('收尾', '限制與下一步');
  const cols = [
    [0.6, '目前的限制', ['官方警戒只有美、日、菲、紐四國', '航空火山灰警報不等於噴發', '沒有火山灰的噴發，警報看不到', 'GVP 週報 RSS 停在 10 月中', 'Claude 整理的內容以原文為準']],
    [5.1, '下一步', ['各台展示機實機測試與相容性排查', '教學內容與中文簡介人工校對', '評估公開網址與行動裝置版本']],
  ];
  for (const [x, h, items] of cols) {
    card(s, x, 1.65, 4.3, 3.75);
    s.addText(h, T({ x: x + 0.3, y: 1.85, w: 3.7, h: 0.42, fontSize: 20, bold: true, color: x > 1 ? ACC : INK, valign: 'middle' }));
    s.addText(bullets(items), T({ x: x + 0.3, y: 2.5, w: 3.8, h: 2.75, fontSize: 15, color: SOFT, paraSpaceAfter: 14, lineSpacingMultiple: 1.1 }));
  }
  s.addNotes(`【約 45 秒】
也說一下限制。
官方警戒等級目前只有美國、日本、菲律賓、紐西蘭，其他國家的網站不開放程式讀取，只能從週報文字看到。
航空火山灰警報不等於噴發，例如只有熔岩、沒有火山灰的噴發，警報就不會出現。
GVP 週報的 RSS 停在 10 月中，官網已經有新一期，原因還在確認。
Claude 整理的內容可能誤判，請以原文為準。
下一步是各台展示機的實機測試與相容性排查（可視情況提：目前有一台 Windows 電腦的 3D 地形版顯示不出地形，正在排查），人工校對教學內容與中文簡介，也會依 Open House 觀眾的要求，評估公開網址與行動裝置版本。`);
}

// 15 結尾 --------------------------------------------------------------
{
  const s = pres.addSlide({ masterName: 'CLOSING', sectionTitle: sec });
  s.addImage({ path: IMG('cover-globe.jpg'), x: 3.0, y: 0, w: 7.0, h: 7.5, altText: '待機畫面：星空中的火山地球' });
  s.addText('謝謝聆聽', T({ x: 0.6, y: 1.72, w: 3.8, h: 0.35, fontSize: 14, bold: true, color: ACC, charSpacing: 3 }));
  s.addText('歡迎試玩', { placeholder: 'title' });
  s.addText('火山脈動　VOLCANO PULSE', T({ x: 0.6, y: 3.3, w: 3.9, h: 0.35, fontSize: 14, bold: true, color: INK, charSpacing: 2, valign: 'middle' }));
  s.addText('展示機就在會場，歡迎動手操作\n問題與討論', T({ x: 0.6, y: 3.85, w: 3.9, h: 0.75, fontSize: 15, color: SOFT, lineSpacingMultiple: 1.3 }));
  s.addText('［講者姓名］　大屯火山觀測站', T({ x: 0.6, y: 6.85, w: 4.5, h: 0.3, fontSize: 11, color: MUTED }));
  s.addNotes(`【約 15 秒】
以上是火山脈動 Volcano Pulse 的介紹。展示機就在會場，歡迎大家動手操作。有問題現在可以提出來。`);
}

(async () => {
  await pres.writeFile({ fileName: OUT });
  // pptxgenjs 寫的是 Office 預設配色；換成這份簡報的顏色，日後在 PowerPoint 新增的圖形才會同色系
  const zip = await JSZip.loadAsync(fs.readFileSync(OUT));
  const part = 'ppt/theme/theme1.xml';
  const xml = await zip.file(part).async('string');
  const slots = Object.entries(THEME).map(([k, v]) => `<a:${k}><a:srgbClr val="${v}"/></a:${k}>`).join('');
  const out = xml.replace(/<a:clrScheme\b[\s\S]*?<\/a:clrScheme>/, `<a:clrScheme name="火山脈動">${slots}</a:clrScheme>`);
  if (out === xml) throw new Error('theme1.xml 沒有 clrScheme，配色沒有換');
  zip.file(part, out);
  fs.writeFileSync(OUT, await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' }));
  console.log(OUT);
})();
