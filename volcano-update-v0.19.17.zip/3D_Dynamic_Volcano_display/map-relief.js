// B 版地圖：globe.gl 內建圖層＋預先算好的地形陰影貼圖（vendor/relief.jpg），完全離線。
// 近看火山時，疊上資料站預先算好的火山周邊地形圖（vendor/patches，tools/make_patches.py），展示機只讀圖不計算；
// 連網時再疊衛星影像
import { createStars, subsolar } from './stars.js';
import { PLATE_COLOR, QUAKE_DEPTHS, loadGeo } from './geo.js';

// 鏡頭飛行時間（飛向火山、切換區域、進出待機）與待機自轉速度：預設 3 秒、4 分鐘一圈，
// 設定頁（app.js）用 motion() 改；app.js 的待機導覽也照 flyMs 計時
let flyMs = 3000, spinMin = 4;
// 拉近程度：跟 A 版一樣用縮放級數（6 到 14，預設 12.5），換算成鏡頭高度後看到的範圍跟 A 版差不多
const NEAR_RANGE = [6, 14];
let nearZoom = 12.5, satOn = true;
// 衛星影像：同 map-terrain.js（EOX Sentinel-2 cloudless 2016 年版，CC BY 4.0），每座火山讀 z10、z12、z14 三層
const SAT = 'https://tiles.maps.eox.at/wmts/1.0.0/s2cloudless_3857/default/g/{z}/{y}/{x}.jpg';
const SAT_CREDIT = '衛星影像：EOxCloudless https://cloudless.eox.at by EOX IT Services GmbH（Contains modified Copernicus Sentinel data 2016）';
const SAT_LEVELS = [10, 12, 14];
const N = 1024;  // 每層的邊長（像素），同 tools/make_patches.py
const NAME_Z = 9, NAME_MAX = 80;  // 同 A 版：拉近到 z9 以上只顯示名稱
const D = Math.PI / 180;
// 板塊邊界與國界的線：離地約 600 m（近看的地形圖與衛星影像在 60 到 400 m）；線與線之間從地底下 DOWN 繞過去，被地球擋住看不到，
// 這樣上萬段線只要畫一次（globe.gl 每條線是一個物件，分開畫 Pi 會卡）
const LINE_ALT = 1e-4, DOWN = -0.02;
const joinLines = (fc, color) => {
  const pts = [], cols = [];
  for (const f of fc.features) {
    const c = color(f.properties), line = f.geometry.coordinates;
    if (pts.length) {
      const [la, lo] = pts[pts.length - 1];
      pts.push([la, lo, DOWN], [line[0][1], line[0][0], DOWN]);
      cols.push(c, c);
    }
    for (const [x, y] of line) { pts.push([y, x, LINE_ALT]); cols.push(c); }
  }
  return { pts, cols };
};
// 地震分 3 種深度 × 3 種規模（5.5 到 6、6 到 7、7 以上），每組一種顏色與大小；globe.gl 的 particles 一組只能一種
const QUAKE_MAGS = [[6, 2.4], [7, 4], [Infinity, 7]];
const mercY = (lat, size) => (1 - Math.log(Math.tan(Math.PI / 4 + Math.max(-85.0511, Math.min(85.0511, lat)) * D / 2)) / Math.PI) / 2 * size;
const latOf = (y, size) => Math.atan(Math.sinh(Math.PI * (1 - 2 * y / size))) / D;
const arc = (a, b) => 2 * Math.asin(Math.sqrt(Math.sin((b.lat - a.lat) * D / 2) ** 2
  + Math.cos(a.lat * D) * Math.cos(b.lat * D) * Math.sin(((b.lon ?? b.lng) - (a.lon ?? a.lng)) * D / 2) ** 2));  // 弧度
const loadImg = (src, cors) => new Promise((ok) => {
  const i = new Image();
  if (cors) i.crossOrigin = 'anonymous';
  i.onload = () => ok(i);
  i.onerror = () => ok(null);
  i.src = src;
});

export async function createMap(el, o) {
  if (!window.Globe) throw new Error('找不到 globe.gl（vendor/globe.gl.min.js）');
  // 全球視角：地球直徑約為地圖框短邊的 80%（globe.gl 相機垂直視角 50°，地球半徑 100）
  const worldAlt = () => {
    const t = (0.8 * Math.min(el.clientWidth, el.clientHeight) / el.clientHeight) * Math.tan(Math.PI * 25 / 180);
    return 1 / Math.sin(Math.atan(t)) - 1;
  };
  // A 版縮放級數 z 換算成鏡頭高度（地球半徑的倍數），讓畫面每像素代表的地面距離相同：
  // A 是 40075016·cos(緯度)／(512·2^z) 公尺，B 從高度 h 往下看，畫面高度對應 2·h·R·tan(25°)
  const altFor = (z, lat = 0) => (40075016 * Math.cos(lat * D) * el.clientHeight) / (512 * 2 ** z * 2 * 6371000 * Math.tan(25 * D));
  const els = new Map(), nameEls = new Map();
  const pinOf = (v) => els.get(v.vnum) || els.set(v.vnum, o.makePin(v)).get(v.vnum);
  // 名稱標籤以底部對齊火山位置；globe.gl 把元素中心放在火山位置，所以外面包一層大小為 0 的框
  const nameOf = (v) => nameEls.get(v.vnum) || nameEls.set(v.vnum, Object.assign(document.createElement('div'), { className: 'vname-at' })).get(v.vnum);
  const g = new window.Globe(el)
    .width(el.clientWidth).height(el.clientHeight)
    .globeImageUrl('vendor/relief.jpg')
    .backgroundColor('rgba(0,0,0,0)')
    .atmosphereColor('#DCE6F2').atmosphereAltitude(0.12)
    .htmlElementsData(o.pins).htmlLat('lat').htmlLng('lon').htmlAltitude(0.003)
    .htmlElement((d) => d.el || pinOf(d))
    .htmlTransitionDuration(0)
    .htmlElementVisibilityModifier((pin, visible) => {
      pin.style.opacity = visible ? '1' : '0';
      pin.style.pointerEvents = visible ? 'auto' : 'none';
    })
    // 近看的地形圖與衛星影像：經緯度方框貼在地球表面上方一點點，越精細的層越高；曲面每 0.1° 一格才貼合球面
    .tilesData([]).tileLat('lat').tileLng('lng').tileWidth('w').tileHeight('h').tileAltitude('alt').tileMaterial('mat')
    .tileCurvatureResolution(0.1).tilesTransitionDuration(0)
    // 板塊邊界（有寬度，顏色逐點給）與國界（1 像素的細線）：pathResolution 很大表示不另外內插點，顏色才對得上每一點
    .pathsData([]).pathPoints('pts').pathPointLat((p) => p[0]).pathPointLng((p) => p[1]).pathPointAlt((p) => p[2])
    .pathColor((d) => d.color).pathStroke((d) => d.w).pathResolution(360).pathTransitionDuration(0);
  g.globeMaterial().shininess = 0;  // 霧面，像白色模型
  // globe.gl 的經緯度轉 3D 方向（世界座標）：星空與白天黑夜共用
  const dirOf = (lat, lon) => [Math.sin((90 - lat) * D) * Math.cos((90 - lon) * D), Math.cos((90 - lat) * D), Math.sin((90 - lat) * D) * Math.sin((90 - lon) * D)];
  // 白天與黑夜（待機背景的開關）：在地球材質的著色程式裡依太陽方向調暗，太陽在地平線下 18° 以後最暗；
  // 近看的地形圖與衛星影像是另外的材質，不受影響（反正拉近時黑夜已經淡出）
  const sunU = { value: { x: 0, y: 1, z: 0 } }, nightU = { value: 0 };
  let nightOn = false, nightT = 0;
  const gm = g.globeMaterial();
  gm.onBeforeCompile = (sh) => {
    sh.uniforms.sunDir = sunU;
    sh.uniforms.nightK = nightU;
    sh.vertexShader = sh.vertexShader.replace('#include <common>', '#include <common>\nvarying vec3 vWorldDir;')
      .replace('#include <begin_vertex>', '#include <begin_vertex>\nvWorldDir = (modelMatrix * vec4(position, 0.0)).xyz;');
    sh.fragmentShader = sh.fragmentShader.replace('#include <common>', '#include <common>\nuniform vec3 sunDir;\nuniform float nightK;\nvarying vec3 vWorldDir;')
      .replace('#include <map_fragment>', '#include <map_fragment>\ndiffuseColor.rgb *= 1.0 - nightK * (1.0 - smoothstep(-0.31, 0.02, dot(normalize(vWorldDir), sunDir)));');
  };
  gm.needsUpdate = true;
  let ps = 0, dotsReady = false, dotTex = null;  // 其他火山圖示目前的大小；要在 onGlobeReady 之前宣告，圖示可能在等星空資料時就載入完成
  let nearNow = false;
  let quakeSets = [];  // 打開地震圖層後才有
  // 其他火山的圖示（拉近時改顯示名稱）與地震都畫在 particles 圖層；大小跟著縮放（ps 是火山圖示的像素大小，地震照比例）
  const sizeParticles = () => g.particlesSize((set) => ((set.r || 12) * (ps || 12)) / 12);
  const refreshParticles = () => {
    if (!dotsReady) return;
    g.particlesData([...(nearNow ? [] : [o.dots]), ...quakeSets]);
    sizeParticles();
  };
  // 沒有近期活動的火山：灰色小噴煙圖示（app.js 的 ico('none')），用 particles 圖層畫在 WebGL 裡；上千個 HTML 元素拖曳時會卡
  g.onGlobeReady(() => {
    // shortcut: globe.gl 沒有開放 three.js，借地球貼圖的建構函式做 Texture；升級 globe.gl 時要重測
    const Tex = g.globeMaterial().map?.constructor;
    if (!Tex) return console.warn('找不到 three.js Texture，其他火山不顯示');
    const img = new Image();
    img.onload = () => {
      const cv = document.createElement('canvas');
      cv.width = cv.height = 64;
      cv.getContext('2d').drawImage(img, 0, 0, 64, 64);
      const tex = new Tex(cv);
      tex.colorSpace = 'srgb';
      tex.needsUpdate = true;
      dotTex = tex;
      dotsReady = true;
      g.particlesList((d) => d).particleLat('lat').particleLng('lon').particleAltitude(0.003)
        .particlesTexture((set) => set.tex || dotTex).particlesColor((set) => set.color || 'white').particlesSizeAttenuation(false)
        .particleLabel((v) => (v.vnum ? `${v.name}${v.zh ? ` ${v.zh}` : ''}`.replace(/[&<>]/g, '') : `規模 ${v.m}・深度 ${v.d} km`))
        .onParticleClick((v) => v.vnum && o.onSelect(v.vnum));
      refreshParticles();
    };
    img.src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(o.dotIcon)}`;
  });
  const c = g.controls();
  c.minDistance = 100 * (1 + altFor(14));  // 地球半徑 100：最近約等於 A 版 z14
  c.maxDistance = 700;
  c.addEventListener('start', () => o.onUserMove?.());
  g.pointOfView({ lat: 15, lng: 150, altitude: worldAlt() });
  new ResizeObserver(() => g.width(el.clientWidth).height(el.clientHeight)).observe(el);
  // 全球視角的星空背景（stars.js）：用 globe.gl 的經緯度轉 3D 座標方式，相機方向直接讀 three.js 相機
  const stars = await createStars(el, {
    dir: dirOf,
    view: () => {
      const cam = g.camera(), e = cam.matrixWorld.elements;
      return { right: [e[0], e[1], e[2]], up: [e[4], e[5], e[6]], fwd: [-e[8], -e[9], -e[10]], fov: cam.fov };
    },
  });

  // ---- 近看：一次只貼一座火山（選取的，或畫面中心最近的）的三層地形圖，連網時再疊三層衛星影像 ----
  let idxP = null, cur = null, curV = null, layers = [];
  const layer = (src, [s, w, n, e], alt, kind) => {
    const tex = new (g.globeMaterial().map.constructor)(src);
    tex.colorSpace = 'srgb';
    tex.needsUpdate = true;
    // 跟地球用同一種材質，受光一樣，顏色才接得起來；外圈是透明漸層
    const mat = new (g.globeMaterial().constructor)({ map: tex, transparent: true, shininess: 0 });
    return { lat: (s + n) / 2, lng: (w + e) / 2, w: e - w, h: n - s, alt, mat, kind };
  };
  // 拉遠就淡出：地形圖在 A 版 z3 到 z5 的距離淡入；衛星影像同 A 版，z7 到 z9 淡入
  const fade = () => {
    const a = g.pointOfView().altitude;
    for (const l of layers) {
      const [lo, hi] = l.kind === 'sat' ? [altFor(9), altFor(7)] : [altFor(5), altFor(3)];
      l.mat.opacity = Math.min(1, Math.max(0, (hi - a) / (hi - lo)));
      l.mat.visible = l.mat.opacity > 0;
    }
  };
  const setLayers = (next) => {
    for (const l of layers) if (!next.includes(l)) { l.mat.map.dispose(); l.mat.dispose(); }
    layers = next;
    g.tilesData(layers);
    fade();
  };
  // 衛星影像在瀏覽器裡接起來：Mercator 圖磚畫進畫布，逐列換成等距圓柱，外圈漸淡（同 tools/make_patches.py 的做法）
  const satLayers = async (v) => {
    const out = [];
    for (const [i, z] of SAT_LEVELS.entries()) {
      const size = 256 * 2 ** z, nT = 2 ** z;
      const x0 = Math.round((v.lon + 180) / 360 * size - N / 2);
      const y0 = Math.min(Math.max(Math.round(mercY(v.lat, size) - N / 2), 0), size - N);
      const merc = Object.assign(document.createElement('canvas'), { width: N, height: N }), mx = merc.getContext('2d');
      const jobs = [];
      for (let ty = Math.floor(y0 / 256); ty <= Math.floor((y0 + N - 1) / 256); ty++) {
        for (let tx = Math.floor(x0 / 256); tx <= Math.floor((x0 + N - 1) / 256); tx++) {
          const url = SAT.replace('{z}', z).replace('{y}', ty).replace('{x}', ((tx % nT) + nT) % nT);
          jobs.push(loadImg(url, true).then((im) => { if (im) mx.drawImage(im, tx * 256 - x0, ty * 256 - y0); return !!im; }));
        }
      }
      if (!(await Promise.all(jobs)).every(Boolean) || cur !== v.vnum) break;  // 離線或讀不到就不疊這層與更細的層
      const n = latOf(y0, size), s = latOf(y0 + N, size);
      const cv = Object.assign(document.createElement('canvas'), { width: N, height: N }), cx = cv.getContext('2d');
      for (let r = 0; r < N; r++) {
        const y = Math.min(N - 1, Math.max(0, Math.floor(mercY(n - (r + 0.5) * (n - s) / N, size) - y0)));
        cx.drawImage(merc, 0, y, N, 1, 0, r, N, 1);
      }
      const gr = cx.createRadialGradient(N / 2, N / 2, N / 2 - 64, N / 2, N / 2, N / 2);
      gr.addColorStop(0, '#000');
      gr.addColorStop(1, 'rgba(0,0,0,0)');
      cx.globalCompositeOperation = 'destination-in';
      cx.fillStyle = gr;
      cx.fillRect(0, 0, N, N);
      out.push(layer(cv, [s, x0 / size * 360 - 180, n, (x0 + N) / size * 360 - 180], (4 + i) * 1e-5, 'sat'));
    }
    return out;
  };
  const addSat = async (v) => {
    const sat = await satLayers(v);
    if (cur === v.vnum && satOn && sat.length) setLayers([...layers.filter((l) => l.kind !== 'sat'), ...sat]);
    else sat.forEach((l) => { l.mat.map.dispose(); l.mat.dispose(); });
  };
  const show = async (v) => {
    if (!v || cur === v.vnum) return;
    cur = v.vnum;
    curV = v;
    // 換新版後不要用到瀏覽器快取裡的舊清單與舊圖：清單每次開網頁都確認一次，圖片網址帶來源指紋與畫法版本（重算過就換網址）
    idxP ||= fetch('vendor/patches/index.json', { cache: 'no-cache' }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    const idx = await idxP, p = idx?.volcanoes?.[v.vnum];
    // 沒有預算圖的火山（例如資料站剛新增、還沒更新到這台）：留著上一座的圖（有經緯度定位，留著不會錯），沒有就是原本的底圖
    const imgs = p ? await Promise.all(idx.levels.map((z) => loadImg(`vendor/patches/${v.vnum}-${z}.webp?s=${p.src.slice(0, 8)}-${p.rev}`))) : [];
    if (cur !== v.vnum || !imgs.some(Boolean)) return;  // 等圖的時候已經換到別座火山，或讀不到
    setLayers(imgs.flatMap((im, i) => (im ? [layer(im, p.b[i], (i + 1) * 1e-5, 'relief')] : [])));
    if (satOn) addSat(v);
  };

  // ---- 板塊邊界、地震、國界與國名（geo.js、vendor/geo/）：第一次打開才讀檔 ----
  const geoOn = {}, lines = {}, lblEls = new Map();
  let geoP = null, geo = null, quakeAll = [], geoLbls = [], lblZ = null, lblT = 0;
  const zoomOf = (alt) => Math.log2((40075016 * el.clientHeight) / (512 * alt * 2 * 6371000 * Math.tan(25 * D)));  // altFor 反過來（赤道）
  const buildGeo = async () => {
    const d = await loadGeo();
    if (!d) return false;
    geo = d;
    // 國界：THREE.Line 可以用函式給每一點的顏色（0 到 1 是線上的位置）；有爭議的線淡一點
    const b = joinLines(d.borders, (q) => (q.d ? 'rgba(45,50,60,0.35)' : 'rgba(45,50,60,0.75)'));
    lines.borders = { pts: b.pts, color: (t) => b.cols[Math.round(t * (b.cols.length - 1))] };
    // 板塊邊界：有寬度的線（Line2）只接受顏色陣列，一點一個
    const pl = joinLines(d.plates, (q) => PLATE_COLOR[q.t]);
    lines.plates = { pts: pl.pts, color: pl.cols, w: 2.5 };
    // 地震：每種深度一張實心圓點貼圖（點只有幾個像素，加白框會把顏色沖淡）
    const Tex = g.globeMaterial().map.constructor;
    const texs = QUAKE_DEPTHS.map((q) => {
      const cv = Object.assign(document.createElement('canvas'), { width: 32, height: 32 }), cx = cv.getContext('2d');
      cx.beginPath();
      cx.arc(16, 16, 15, 0, 2 * Math.PI);
      cx.fillStyle = q.color;
      cx.globalAlpha = 0.85;
      cx.fill();
      const t = new Tex(cv);
      t.colorSpace = 'srgb';
      t.needsUpdate = true;
      return t;
    });
    // 大規模的放後面，畫在上面
    quakeAll = QUAKE_MAGS.flatMap(([mMax, r], j) => QUAKE_DEPTHS.map((q, i) => {
      const dMin = i ? QUAKE_DEPTHS[i - 1].max : -Infinity, mMin = j ? QUAKE_MAGS[j - 1][0] : -Infinity;
      const set = d.quakes.q.filter(([, , dd, m]) => dd >= dMin && dd < q.max && m >= mMin && m < mMax).map(([lon, lat, dd, m]) => ({ lat, lon, d: dd, m }));
      return Object.assign(set, { tex: texs[i], r });
    }));
    return true;
  };
  const setPaths = () => g.pathsData([...(geoOn.borders ? [lines.borders] : []), ...(geoOn.plates ? [lines.plates] : [])]);
  const lblEl = (n, k) => lblEls.get(k + n) || lblEls.set(k + n, Object.assign(document.createElement('div'), { className: `geo-lbl ${k}`, textContent: n })).get(k + n);
  // 國名與板塊名稱：國名照 Natural Earth 建議的縮放級數出現；板塊名稱優先，再放大國，跟已經放的字重疊就不放
  //（用經緯度差換算成畫面像素比較，跟地球轉到哪裡無關，待機自轉時不用重算）
  const pickLabels = () => {
    geoLbls = [];
    if (!geo || !(geoOn.plates || geoOn.borders)) return;
    const p = g.pointOfView(), z = zoomOf(p.altitude), px = (2 * p.altitude * Math.tan(25 * D)) / el.clientHeight;  // 畫面中心每像素幾弧度
    const wide = p.altitude > altFor(6);  // 遠看時整個半球都可能轉進畫面，不用畫面範圍篩
    const r = p.altitude * Math.tan(25 * D) * Math.hypot(1, el.clientWidth / el.clientHeight);
    const cand = [...(geoOn.plates ? geo.labels.plates.map(([n, lon, lat]) => ({ n, lon, lat, k: 'p', w: n.length * 17 + 8 })) : []),
      ...(geoOn.borders ? geo.labels.countries.filter((c) => c[3] <= z).map(([n, lon, lat]) => ({ n, lon, lat, k: 'c', w: n.length * 12 + 8 })) : [])];
    const placed = [];
    for (const c of cand) {
      if (!wide && arc(p, c) > r) continue;
      const hit = placed.some((q) => Math.abs((c.lat - q.lat) * D / px) < 20
        && Math.abs(((((c.lon - q.lon) % 360) + 540) % 360 - 180) * Math.cos(c.lat * D) * D / px) < (c.w + q.w) / 2 + 4);
      if (!hit) placed.push(c);
    }
    geoLbls = placed.map((c) => ({ lat: c.lat, lon: c.lon, el: lblEl(c.n, c.k) }));
  };

  // 拉近時其他火山只顯示名稱（app.js 的 nameEl）：畫面範圍內離中心最近的 NAME_MAX 座
  let selV = null, names = [], settleT = 0;
  const refreshHtml = () => g.htmlElementsData([...o.pins, ...(selV ? [selV] : []), ...names, ...geoLbls]);
  const refreshNames = () => {
    names = [];
    if (nearNow) {
      const p = g.pointOfView();
      const r = p.altitude * Math.tan(25 * D) * Math.hypot(1, el.clientWidth / el.clientHeight);  // 畫面對角線的一半（弧度）
      // 選取的火山已經有圖釘標籤
      names = o.dots.map((v) => [arc(p, v), v]).filter(([d, v]) => d < r && v.vnum !== selV?.vnum).sort((a, b) => a[0] - b[0]).slice(0, NAME_MAX)
        .map(([, v]) => {
          const w = nameOf(v);
          if (!w.firstChild) w.append(o.makeName(v));
          return { lat: v.lat, lon: v.lon, el: w };
        });
    }
    refreshHtml();
  };
  // 鏡頭停下來後：更新名稱；夠近時改貼畫面中心最近那座火山的地形圖（手動拉近也看得清楚）
  const settle = () => {
    const p = g.pointOfView();
    pickLabels();
    if (nearNow) refreshNames();
    else refreshHtml();
    if (p.altitude > altFor(7)) return;
    let best = null, bd = 0.6 * D;
    for (const v of [...o.pins, ...o.dots]) {
      const d = arc(p, v);
      if (d < bd) { best = v; bd = d; }
    }
    if (best) show(best);
  };

  // 圖釘與其他火山圖示跟著縮放：全球約 0.75 倍、區域約 1 倍，最近 1.5 倍
  // 黑夜的深淺：同 A 版，拉近到 z3 以上淡出、z5 消失
  const nightFade = (alt) => { nightU.value = nightOn ? 0.6 * Math.min(1, Math.max(0, (alt - altFor(5)) / (altFor(3) - altFor(5)))) : 0; };
  const far = () => {
    const alt = g.pointOfView().altitude;
    o.onFar(alt > 1.2);
    nightFade(alt);
    const k = Math.min(1.5, Math.max(0.7, 1 - 0.125 * Math.log2(alt / 0.6)));
    el.style.setProperty('--pz', k.toFixed(2));
    const size = Math.round(12 * k);
    if (size !== ps) { ps = size; if (dotsReady) sizeParticles(); }
    if ((alt < altFor(NAME_Z)) !== nearNow) {
      nearNow = !nearNow;
      o.onNear?.(nearNow);
      refreshParticles();
      g.htmlAltitude(nearNow ? 2e-4 : 0.003);  // 近看時鏡頭只離地面十幾公里，圖釘不能浮在 19 公里高
      refreshNames();
    }
    if (layers.length) fade();
    // 縮放改變時重選國名與板塊名稱（每 0.25 級一次，停下來 0.15 秒後）
    const zb = Math.round(zoomOf(alt) * 4) / 4;
    if (geo && zb !== lblZ) { lblZ = zb; clearTimeout(lblT); lblT = setTimeout(() => { pickLabels(); refreshHtml(); }, 150); }
    if (alt < altFor(6)) { clearTimeout(settleT); settleT = setTimeout(settle, 300); }
  };
  g.onZoom(far);
  far();

  let spinId = 0;
  return {
    // 待機時慢慢轉：OrbitControls 的自動旋轉讓相機往西繞，看起來是地球由西向東自轉，spinMin 分鐘一圈（速度依時間算，少畫幾格也不會變慢）
    // 轉的同時量每格的間隔：超過一成的格比正常慢一半以上（Pi 跟不上每秒 60 格），就暫停 globe.gl 自己的迴圈，改成每兩格畫一格，
    // 穩定的每秒 30 格比忽快忽慢的 60 格順。離開待機就恢復
    spin(on) {
      cancelAnimationFrame(spinId);
      c.autoRotate = on;
      c.autoRotateSpeed = 1 / spinMin;  // OrbitControls：1 等於 60 秒一圈
      g.resumeAnimation();
      if (!on) return;
      const gaps = [];
      let prev = 0, half = false, odd = false;
      const step = (t) => {
        spinId = requestAnimationFrame(step);
        if (half) {
          // resumeAnimation 會立刻畫一格並排下一格，緊接著 pause 取消排程，等於只畫這一格
          if ((odd = !odd)) { g.resumeAnimation(); g.pauseAnimation(); }
          return;
        }
        if (prev) gaps.push(t - prev);
        prev = t;
        if (gaps.length < 120) return;
        const s = gaps.sort((a, b) => a - b), base = s[12];
        half = s.filter((x) => x > base * 1.5).length > 12;
        gaps.length = 0;
        if (half) g.pauseAnimation();
      };
      spinId = requestAnimationFrame(step);
    },
    stars: stars || undefined,  // 星空開關（app.js 的控制鈕）
    night(on) {  // 白天與黑夜：太陽每分鐘移動約 0.25°，顯示時每分鐘更新一次
      nightOn = on;
      clearInterval(nightT);
      nightFade(g.pointOfView().altitude);
      if (!on) return;
      const upd = () => { const s = subsolar(Date.now()), [x, y, z] = dirOf(s.lat, s.lon); sunU.value = { x, y, z }; };
      upd();
      nightT = setInterval(upd, 60000);
    },
    get flyMs() { return flyMs; },
    motion(m) {  // m：{ spinMin, flySec, near, sat }，自轉中改速度會馬上生效
      if (m.flySec > 0) flyMs = m.flySec * 1000;
      if (m.spinMin > 0) { spinMin = m.spinMin; c.autoRotateSpeed = 1 / spinMin; }
      if (m.near >= NEAR_RANGE[0] && m.near <= NEAR_RANGE[1]) nearZoom = m.near;
      if (typeof m.sat === 'boolean' && m.sat !== satOn) {
        satOn = m.sat;
        if (!satOn) setLayers(layers.filter((l) => l.kind !== 'sat'));
        else if (curV) addSat(curV);
      }
    },
    sat: true,  // 有衛星影像可以開關
    // 板塊邊界、地震、國界與國名的開關（k：plates／quakes／borders）；讀不到資料時回傳 false
    async geo(k, on) {
      geoOn[k] = on;
      if (on) geoP ||= buildGeo();
      if (!geoP || !(await geoP)) return !on;
      if (k === 'quakes') { quakeSets = geoOn.quakes ? quakeAll : []; refreshParticles(); }
      else { setPaths(); pickLabels(); refreshHtml(); }
      return true;
    },
    nearRange: NEAR_RANGE,  // 有「拉近程度」可選
    center() { const p = g.pointOfView(); return { lat: p.lat, lng: p.lng }; },  // 畫面中心（待機導覽判斷火山有沒有轉到中間）
    hint: '拖曳旋轉・滾輪縮放',
    note: '地形為陰影貼圖',
    credit: `地形：由 AWS Terrain Tiles 預先計算的陰影貼圖（SRTM、GMTED2010、ETOPO1 等）・${SAT_CREDIT}`,
    terrainNote: 'globe.gl 地球加上一張預先計算的地形陰影貼圖（8192×4096，赤道約 5 km/像素），起伏是畫上去的陰影，不是真實立體，完全離線可用。近看火山時改貼資料站預先算好的火山周邊地形圖（z8、z10、z12 三層，最細約 38 m/像素），連網時再疊衛星影像。陸地與海洋以海拔 0 m 區分，低於海平面的陸地窪地也會顯示成水色。',
    flyTo(v) {
      show(v);
      // 區域尺度（z8 以下）：已經比較近就不拉遠；再近：照拉近程度的固定距離
      const a = altFor(nearZoom, v.lat);
      g.pointOfView({ lat: v.lat, lng: v.lon, altitude: nearZoom < 8 ? Math.min(g.pointOfView().altitude, a) : a }, flyMs);
    },
    region(r) {
      g.pointOfView({ lat: r.lat, lng: r.lon, altitude: r.key === 'world' ? worldAlt() : r.alt }, flyMs);
    },
    zoomBy(d) {
      const p = g.pointOfView();
      g.pointOfView({ ...p, altitude: Math.min(6, Math.max(altFor(14), p.altitude * (d > 0 ? 0.6 : 1 / 0.6))) }, 500);
    },
    select(v) {
      selV = v;
      refreshNames();
      if (v) pinOf(v).classList.add('sel');
    },
  };
}
