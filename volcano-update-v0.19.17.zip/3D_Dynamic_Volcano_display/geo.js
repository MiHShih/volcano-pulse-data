// 板塊邊界、地震、國界與國名：兩個地圖版本與 app.js 共用的顏色與讀檔（資料由 tools/make_geo.py 整理在 vendor/geo/）

// 板塊邊界的 4 類：key 同 vendor/geo/plates.json 的 properties.t
export const PLATE_KINDS = [
  { key: 'div', label: '張裂', note: '中洋脊、裂谷', color: '#0CA678' },
  { key: 'sub', label: '隱沒帶', color: '#D6336C' },
  { key: 'col', label: '碰撞', color: '#7048E8' },
  { key: 'tra', label: '錯動', note: '轉形斷層', color: '#343A40' },
];
export const PLATE_COLOR = Object.fromEntries(PLATE_KINDS.map((k) => [k.key, k.color]));
// 地震依震源深度分 3 類（地震學慣用的淺源、中源、深源），顏色照常見的地震分布圖：淺紅、中黃、深藍
export const QUAKE_DEPTHS = [
  { max: 70, label: '淺源', note: '70 km 內', color: '#F03E3E' },
  { max: 300, label: '中源', note: '70 到 300 km', color: '#FAB005' },
  { max: Infinity, label: '深源', note: '300 km 以上', color: '#1C7ED6' },
];
export const quakeColor = (depth) => QUAKE_DEPTHS.find((d) => depth < d.max).color;
// 地震圓點的大小（像素半徑）：規模 5.5 約 1.5，每大 1 級約 1.8 倍
export const quakeRadius = (mag) => 1.5 * 1.8 ** (mag - 5.5);
export const GEO_CREDIT = '板塊邊界：Bird (2003) PB2002（ODC-By，Hugo Ahlenius / Nordpil 整理）・地震：USGS ComCat・國界：Natural Earth';

// 第一次打開圖層時才讀，讀過就留著；讀不到回傳 null（例如更新包沒帶到 vendor/geo/）
let geoP = null;
export function loadGeo() {
  const get = (f) => fetch(`vendor/geo/${f}`).then((r) => (r.ok ? r.json() : null)).catch(() => null);
  geoP ||= Promise.all(['plates.json', 'borders.json', 'labels.json', 'quakes.json'].map(get))
    .then(([plates, borders, labels, quakes]) => (plates && borders && labels && quakes ? { plates, borders, labels, quakes } : null));
  return geoP;
}
