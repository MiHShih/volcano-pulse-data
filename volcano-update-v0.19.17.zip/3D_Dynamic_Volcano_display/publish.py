#!/usr/bin/env python3
"""火山脈動：把 data/ 打包成 bundle.json，commit 並推送到資料 repo（GitHub Pages）。只用 Python 標準函式庫。

用法：
  python3 publish.py             打包、commit、push
  python3 publish.py --no-push   打包、commit，不 push
  python3 publish.py --selftest  自我檢查（用暫存的假 repo，不連網、不動 data/）

publish.json 的 repo 是資料 repo clone 的路徑，station 是資料站的電腦名稱（scutil --get LocalHostName）。
沒有 publish.json，或這台不是 station 時不做任何事：專案資料夾由 Syncthing 同步到其他電腦，只能有一台發布。
檢查不通過或 git 失敗時只寫 log（data/update.log），不改 data/，也不動 repo 裡的資料包。
對照檔 names.json（名稱對照）、decade.json（十年火山）放在資料 repo（可以直接在 GitHub 網頁編輯，展示端直接讀線上那份），
發布時順便複製到 data/，當作展示端離線時的備援；格式不對就保留舊的，只寫 log。
中文簡介 intro.json 也放在資料 repo：Claude API 自動報告的 i1 任務每月把 GVP 地質摘要整理成中文，寫到 publish.json 的 intro 匯出檔，
發布時合併進 repo 的 intro.json。只加入新的火山、GVP 原文改過的、以及提示詞改版（rev）後重新整理的；其餘不動（GitHub 上人工改過的文字會保留），
checked 為 true（人工校對過）的永遠不覆蓋，原文改了只在 log 提醒重新校對。
"""
import json
import logging
import os
import socket
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
CONF = ROOT / 'publish.json'
SCHEMA = 1
MIN_VOLCANOES = 1000  # GVP Holocene 約 1,200 座，少很多代表資料壞了

log = logging.getLogger('publish')


def setup_logging(data):
    for h in list(log.handlers):
        log.removeHandler(h)
        h.close()
    fmt = logging.Formatter('%(asctime)s UTC %(levelname)s %(message)s', '%Y-%m-%d %H:%M:%S')
    fmt.converter = time.gmtime
    data.mkdir(exist_ok=True)
    for h in (logging.FileHandler(data / 'update.log', encoding='utf-8'), logging.StreamHandler()):
        h.setFormatter(fmt)
        log.addHandler(h)
    log.setLevel(logging.INFO)


def build(data):
    """讀 data/ 的 4 個 JSON，檢查後合併成資料包；不合格就丟 ValueError。"""
    rd = lambda n: json.loads((data / n).read_text('utf-8'))
    vols, alerts, act, meta = rd('volcanoes.json'), rd('alerts.json'), rd('activity.json'), rd('meta.json')
    if not isinstance(vols, list) or len(vols) < MIN_VOLCANOES:
        raise ValueError(f'火山數 {len(vols) if isinstance(vols, list) else "?"} 少於 {MIN_VOLCANOES}')
    num = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool)
    if not all(isinstance(v, dict) and isinstance(v.get('vnum'), int) and num(v.get('lat')) and num(v.get('lon'))
               and v.get('name') for v in vols):
        raise ValueError('有火山缺編號、座標或名稱')
    if not isinstance(alerts, list) or not all(isinstance(a, dict) and isinstance(a.get('vnum'), int) for a in alerts):
        raise ValueError('alerts.json 格式不對')
    if not isinstance(act, list) or not all(isinstance(r, dict) and isinstance(r.get('vnum'), int) and r.get('date')
                                            and r.get('source') for r in act):
        raise ValueError('activity.json 格式不對')
    if not isinstance(meta, dict) or not meta.get('updated_utc'):
        raise ValueError('meta.json 沒有 updated_utc')
    media = rd('media.json') if (data / 'media.json').exists() else {}  # 直播清單，沒有就是空的
    if not isinstance(media, dict):
        raise ValueError('media.json 格式不對')
    # 火山灰警報與各國警戒等級（v0.19 起）、V1 的每日動態（v0.19.6 起），沒有就是空的；舊版展示端不認得這些欄位，會直接忽略
    ash, levels, obs = (rd(n) if (data / n).exists() else [] for n in ('ash.json', 'levels.json', 'obs.json'))
    if not all(isinstance(x, list) and all(isinstance(r, dict) and isinstance(r.get('vnum'), int) for r in x) for x in (ash, levels, obs)):
        raise ValueError('ash.json、levels.json 或 obs.json 格式不對')
    # ash.json 從 v0.19.6 起保留 30 天：ash 欄位照舊只放最近 7 天（v0.19.5 以前的展示端把整份當成 7 天），30 天放在 ash30 給新版用
    cut = (datetime.now(timezone.utc) - timedelta(days=7)).strftime('%Y-%m-%dT%H:%M:%SZ')
    # 日統計（v0.19.12 起）：每座火山每天一列，詳細卡的 30 天活動圖直接讀
    daily = rd('daily.json') if (data / 'daily.json').exists() else []
    if not (isinstance(daily, list) and all(isinstance(r, dict) and isinstance(r.get('vnum'), int) and r.get('date') for r in daily)):
        raise ValueError('daily.json 格式不對')
    return {'schema': SCHEMA, 'generated_utc': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'meta': meta, 'volcanoes': vols, 'alerts': alerts, 'activity': act, 'media': media,
            'ash': [r for r in ash if str(r.get('to', '')) >= cut], 'ash30': ash, 'levels': levels, 'obs': obs, 'daily': daily}


SIDE_FILES = (('names.json', '名稱對照', ('name', 'zh')), ('decade.json', '十年火山', ()),
              ('intro.json', '中文簡介', ('zh',)))  # 檔名、名稱、每筆至少要有其一的欄位
INTRO_NOTE = ('火山脈動的火山中文簡介：依 Smithsonian GVP Volcanoes of the World 的地質摘要（Geological Summary），由 Claude 整理成 2 到 3 句中文。'
              'key 是 GVP 火山編號；gvp 是 GVP 原名，只用來核對編號；zh 是簡介，可以直接在 GitHub 網頁修改；'
              'src 是 GVP 原文的指紋、rev 是整理時的提示詞版本，資料站用來判斷要不要更新，請勿修改；checked 改成 true 表示人工校對過，'
              '之後資料站不會再覆蓋這一筆，詳細卡也不再標「未經人工校對」。修改文字後請一併把 checked 改成 true，'
              '否則提示詞改版重新整理時會被新版取代。存檔後各台展示端重新整理網頁就會套用。')


def merge_intro(repo, src, vols):
    """把 i1 匯出檔合併進資料 repo 的 intro.json，有改動就 git add。回傳有沒有改。"""
    if not src or not src.exists():
        return False
    try:
        exp = json.loads(src.read_text('utf-8'))['volcanoes']
        if not isinstance(exp, dict):
            raise ValueError('volcanoes 不是對照表')
    except (OSError, ValueError, KeyError, TypeError) as e:
        log.error('中文簡介：匯出檔讀不到或格式不對，不合併：%s', e)
        return False
    dst = repo / 'intro.json'
    try:
        doc = json.loads(dst.read_text('utf-8')) if dst.exists() else {'說明': INTRO_NOTE, 'volcanoes': {}}
        cur = doc['volcanoes']
        if not isinstance(cur, dict):
            raise ValueError('volcanoes 不是對照表')
    except (OSError, ValueError, KeyError, TypeError) as e:  # 多半是 GitHub 網頁上改壞了：不覆蓋，等人修好
        log.error('中文簡介：repo 的 intro.json 格式不對，這次不合併：%s', e)
        return False
    gvp = {str(v['vnum']) for v in vols}
    added, stale = [], []
    for k, x in exp.items():
        if k not in gvp or not isinstance(x, dict) or not x.get('zh'):
            continue
        old = cur.get(k) if isinstance(cur.get(k), dict) else {}
        if old.get('src') == x.get('src') and old.get('rev', 1) >= x.get('rev', 1):
            continue  # 已經合併過：原文沒變、也不是新版提示詞，就不動（保留人工修改）
        if old.get('checked'):
            if old.get('src') != x.get('src'):
                stale.append(k)
            continue
        cur[k] = {'gvp': x.get('gvp'), 'zh': x['zh'], 'src': x.get('src'), 'rev': x.get('rev', 1), 'checked': False}
        added.append(k)
    if stale:
        log.warning('中文簡介：%d 筆人工校對過，但 GVP 原文已更新，請重新校對：%s', len(stale), '、'.join(stale[:10]))
    if not added:
        return False
    doc['volcanoes'] = dict(sorted(cur.items(), key=lambda kv: int(kv[0]) if kv[0].isdigit() else 0))
    tmp = dst.with_name(dst.name + '.tmp')
    tmp.write_text(json.dumps(doc, ensure_ascii=False, indent=1), 'utf-8')
    os.replace(tmp, dst)
    git(repo, 'add', 'intro.json')
    log.info('中文簡介：新增或更新 %d 筆', len(added))
    return True


def sync_side(repo, data, vols, fname, label, need):
    """把資料 repo 的對照檔複製到 data/，並把需要確認的筆數寫進 log。"""
    src = repo / fname
    if not src.exists():
        return
    try:
        doc = json.loads(src.read_text('utf-8'))
        if not isinstance(doc, dict) or not isinstance(doc.get('volcanoes'), dict):
            raise ValueError('沒有 volcanoes 對照表')
    except (OSError, ValueError) as e:
        log.error('%s：%s 格式不對，data/%s 保留上一份：%s', label, fname, fname, e)
        return
    gvp = {str(v['vnum']): v['name'] for v in vols}
    warn = [k for k, x in doc['volcanoes'].items() if k not in gvp or not isinstance(x, dict)
            or (need and not any(x.get(f) for f in need)) or (x.get('gvp') and x['gvp'] != gvp[k])]
    dst = data / fname
    txt = src.read_text('utf-8')
    if not dst.exists() or dst.read_text('utf-8') != txt:
        tmp = dst.with_name(dst.name + '.tmp')
        tmp.write_text(txt, 'utf-8')
        os.replace(tmp, dst)
        log.info('%s：已更新 data/%s（%d 筆）', label, fname, len(doc['volcanoes']))
    if warn:
        log.warning('%s：%d 筆需要確認（編號不在 GVP、缺必要欄位、或 GVP 原名對不上）：%s', label, len(warn), '、'.join(warn[:10]))


def git(repo, *args):
    return subprocess.run(['git', '-C', str(repo), *args], capture_output=True, text=True, timeout=180,
                          check=True).stdout


def publish(data, repo, push=True, intro=None):
    try:
        bundle = build(data)
    except (OSError, ValueError) as e:  # JSONDecodeError 是 ValueError 的子類別
        log.error('發布：資料檢查不通過，不發布：%s', e)
        return 1
    try:
        git(repo, 'rev-parse', '--is-inside-work-tree')
        if push:
            git(repo, 'pull', '--ff-only', '-q')  # 先同步 GitHub 網頁上的修改（README、對照檔）
        intro_new = merge_intro(repo, intro, bundle['volcanoes'])
        for fname, label, need in SIDE_FILES:
            sync_side(repo, data, bundle['volcanoes'], fname, label, need)
        p = repo / 'bundle.json'
        try:
            old = json.loads(p.read_text('utf-8'))
        except (OSError, ValueError):
            old = None
        strip = lambda b: {k: v for k, v in b.items() if k != 'generated_utc'}
        same = isinstance(old, dict) and strip(old) == strip(bundle)
        if same and not intro_new:
            log.info('發布：資料包沒有變動，不 commit')
        else:
            if not same:
                tmp = p.with_name(p.name + '.tmp')
                tmp.write_text(json.dumps(bundle, ensure_ascii=False, indent=1), 'utf-8')
                os.replace(tmp, p)
                git(repo, 'add', 'bundle.json')
            git(repo, 'commit', '-q', '-m', ('中文簡介' if same else f"資料包 {bundle['meta']['updated_utc']}"
                                              + ('與中文簡介' if intro_new else '')))
            log.info('發布：已 commit（火山 %d 座、活動 %d 筆、%.0f KB%s）',
                     len(bundle['volcanoes']), len(bundle['activity']), p.stat().st_size / 1024, '，含中文簡介' if intro_new else '')
        if push:
            git(repo, 'push', '-q')  # 上次推送失敗留下的 commit 也會在這次一起推上去
            log.info('發布：已推送')
        return 0
    except (OSError, subprocess.SubprocessError) as e:
        log.error('發布：git 失敗：%s', (getattr(e, 'stderr', '') or str(e)).strip())
        return 1


def publish_archive(path, push=True):
    """私有資料庫 repo：update.py 已經把當天的資料寫進工作目錄，這裡 commit 再推送。失敗只記錄，不影響資料包。"""
    try:
        if git(path, 'status', '--porcelain').strip():
            git(path, 'add', '-A')
            git(path, 'commit', '-q', '-m', f"資料庫 {datetime.now(timezone.utc):%Y-%m-%d}")
            log.info('資料庫：已 commit')
        else:
            log.info('資料庫：沒有變動')
        if push:
            git(path, 'push', '-q')  # 上次推送失敗留下的 commit 也會一起推上去
            log.info('資料庫：已推送')
        return 0
    except (OSError, subprocess.SubprocessError) as e:
        log.error('資料庫：git 失敗：%s', (getattr(e, 'stderr', '') or str(e)).strip())
        return 1


def machine_name():
    """跟 claude-api-routines 的判斷方式相同。"""
    try:
        name = subprocess.run(['scutil', '--get', 'LocalHostName'], capture_output=True, text=True,
                              check=True).stdout.strip()
        if name:
            return name
    except (OSError, subprocess.CalledProcessError):
        pass
    return socket.gethostname().split('.')[0]


def main(argv, data=DATA, conf=CONF, here=None):
    setup_logging(data)
    if not conf.exists():
        log.info('發布：沒有 publish.json，略過')
        return 0
    try:
        c = json.loads(conf.read_text('utf-8'))
        repo, station = Path(c['repo']).expanduser(), c['station']
        intro = Path(c['intro']).expanduser() if c.get('intro') else None  # i1 任務的中文簡介匯出檔
        archive = Path(c['archive']).expanduser() if c.get('archive') else None  # 私有資料庫 repo 的 clone
    except (OSError, ValueError, KeyError, TypeError) as e:
        log.error('發布：publish.json 讀不到 repo 或 station：%s', e)
        return 1
    here = here or machine_name()
    if here != station:
        log.info('發布：這台（%s）不是資料站（%s），略過', here, station)
        return 0
    rc = publish(data, repo, push='--no-push' not in argv, intro=intro)
    if archive:
        publish_archive(archive, push='--no-push' not in argv)
    return rc


# ---------- 自我檢查 ----------

def selftest():
    fails = []

    def check(cond, msg):
        print(('  OK   ' if cond else '  FAIL ') + msg)
        cond or fails.append(msg)

    with tempfile.TemporaryDirectory() as td:
        td = Path(td)
        sh = lambda *a: subprocess.run(a, cwd=td, capture_output=True, text=True, check=True).stdout
        sh('git', 'init', '-q', '--bare', 'origin.git')
        sh('git', 'clone', '-q', 'origin.git', 'work')
        work = td / 'work'
        for k, v in (('user.name', 'selftest'), ('user.email', 'selftest@example.invalid'), ('commit.gpgsign', 'false')):
            git(work, 'config', k, v)
        (work / 'README.md').write_text('# test\n')
        git(work, 'add', 'README.md')
        git(work, 'commit', '-q', '-m', 'init')
        git(work, 'push', '-q', '-u', 'origin', 'HEAD')
        commits = lambda: int(git(td / 'origin.git', 'rev-list', '--count', '--all').strip())

        data = td / 'data'
        data.mkdir()
        save = lambda n, o: (data / n).write_text(json.dumps(o, ensure_ascii=False), 'utf-8')
        save('volcanoes.json', [{'vnum': 100000 + i, 'name': f'V{i}', 'lat': 1.5, 'lon': -2} for i in range(MIN_VOLCANOES)])
        save('alerts.json', [{'vnum': 100001, 'color_code': 'ORANGE'}])
        save('activity.json', [{'vnum': 100002, 'date': '2026-11-01', 'source': 'rss'}])
        save('meta.json', {'updated_utc': '2026-11-01T01:00:00Z'})
        stamp = lambda days: (datetime.now(timezone.utc) - timedelta(days=days)).strftime('%Y-%m-%dT%H:%M:%SZ')
        save('ash.json', [{'vnum': 100001, 'to': stamp(1)}, {'vnum': 100002, 'to': stamp(20)}])
        conf = td / 'publish.json'
        conf.write_text(json.dumps({'repo': str(work), 'station': machine_name()}))
        snap = lambda: {p.name: p.read_bytes() for p in data.glob('*.json')}
        before = snap()

        print('1. 正常發布')
        check(main([], data, conf) == 0, '結束碼為 0')
        b = json.loads(git(td / 'origin.git', 'show', 'HEAD:bundle.json'))
        check(b['schema'] == 1 and len(b['volcanoes']) == MIN_VOLCANOES and b['meta']['updated_utc'] == '2026-11-01T01:00:00Z',
              '遠端收到資料包，schema 1，內容與 data/ 一致')
        check([r['vnum'] for r in b['ash']] == [100001] and len(b['ash30']) == 2, '火山灰警報：ash 只放最近 7 天（舊版展示端用），ash30 放全部')
        check(commits() == 2, '遠端多 1 個 commit')
        check(snap() == before, 'data/ 完全沒被改動')
        check(b.get('daily') == [], '沒有 daily.json 時日統計是空的')
        sh('git', 'init', '-q', '--bare', 'arch.git')
        sh('git', 'clone', '-q', 'arch.git', 'arch')
        for k, v in (('user.name', 'selftest'), ('user.email', 'selftest@example.invalid'), ('commit.gpgsign', 'false')):
            git(td / 'arch', 'config', k, v)
        (td / 'arch' / 'daily').mkdir()
        (td / 'arch' / 'daily' / '2026-11.jsonl').write_text('{"id": "x"}\n')
        check(publish_archive(td / 'arch') == 0 and 'daily/2026-11.jsonl' in git(td / 'arch.git', 'ls-tree', '-r', '--name-only', 'HEAD'),
              '資料庫：有變動就 commit 並推送')
        check(publish_archive(td / 'arch') == 0 and int(git(td / 'arch.git', 'rev-list', '--count', '--all').strip()) == 1,
              '資料庫：沒有變動不 commit')

        print('2. 資料沒變不 commit；有變才 commit')
        main([], data, conf)
        check(commits() == 2, '資料沒變：沒有新 commit')
        save('meta.json', {'updated_utc': '2026-11-02T01:00:00Z'})
        main([], data, conf)
        check(commits() == 3, '資料有變：新增 1 個 commit')
        save('media.json', {'live': {'100001': [{'id': 'abcdefghijk'}]}})
        main([], data, conf)
        b = json.loads(git(td / 'origin.git', 'show', 'HEAD:bundle.json'))
        check(commits() == 4 and b['media']['live']['100001'][0]['id'] == 'abcdefghijk', '直播清單一起放進資料包')
        (data / 'media.json').unlink()

        print('3. 資料不合格時不發布')
        good = (work / 'bundle.json').read_bytes()
        save('volcanoes.json', [{'vnum': 1, 'name': 'V', 'lat': 0, 'lon': 0}])
        check(main([], data, conf) == 1 and commits() == 4, '火山數太少：結束碼 1、沒有新 commit')
        (data / 'volcanoes.json').write_text('[{"vnum": 1', 'utf-8')
        check(main([], data, conf) == 1 and commits() == 4, 'JSON 壞掉：結束碼 1、沒有新 commit')
        check((work / 'bundle.json').read_bytes() == good, 'repo 裡的資料包維持上一份')
        check('資料檢查不通過' in (data / 'update.log').read_text('utf-8'), '原因寫進 update.log')

        print('4. 資料站檢查、--no-push 與設定檔')
        save('volcanoes.json', [{'vnum': 100000 + i, 'name': f'V{i}', 'lat': 1.5, 'lon': -2} for i in range(MIN_VOLCANOES)])
        save('meta.json', {'updated_utc': '2026-11-03T01:00:00Z'})
        head = git(work, 'rev-parse', 'HEAD')
        check(main([], data, conf, 'other-mac') == 0 and git(work, 'rev-parse', 'HEAD') == head and commits() == 4,
              '不是資料站的電腦：略過，本機與遠端都沒有新 commit')
        check(main(['--no-push'], data, conf) == 0 and commits() == 4, '--no-push：本機 commit，遠端不變')
        check(main([], data, td / 'none.json') == 0, '沒有 publish.json：略過，結束碼 0')
        conf.write_text(json.dumps({'repo': str(work)}))
        check(main([], data, conf) == 1, 'publish.json 缺 station：結束碼 1')
        conf.write_text(json.dumps({'repo': str(td / 'missing'), 'station': machine_name()}))
        check(main([], data, conf) == 1, 'repo 路徑不存在：結束碼 1')
        print('5. 名稱對照（names.json）')
        conf.write_text(json.dumps({'repo': str(work), 'station': machine_name()}))
        good_names = {'volcanoes': {'100001': {'gvp': 'V1', 'zh': '一號'}}}
        (work / 'names.json').write_text(json.dumps(good_names, ensure_ascii=False), 'utf-8')
        main([], data, conf)
        check(json.loads((data / 'names.json').read_text('utf-8')) == good_names, 'repo 的 names.json 複製到 data/')
        (work / 'names.json').write_text('{"volcanoes": {', 'utf-8')
        main([], data, conf)
        check(json.loads((data / 'names.json').read_text('utf-8')) == good_names and '格式不對' in (data / 'update.log').read_text('utf-8'),
              'names.json 壞掉：data/ 保留上一份，原因寫進 log')
        (work / 'names.json').write_text(json.dumps({'volcanoes': {'999999': {'zh': '不存在'}, '100002': {'gvp': '錯名', 'zh': '二號'}}}), 'utf-8')
        main([], data, conf)
        check('2 筆需要確認' in (data / 'update.log').read_text('utf-8'), '編號不存在、GVP 原名對不上：寫進 log')
        dec = {'volcanoes': {'100003': {'gvp': 'V3', 'label': 'V3 (Three)'}}}
        (work / 'decade.json').write_text(json.dumps(dec), 'utf-8')
        main([], data, conf)
        check(json.loads((data / 'decade.json').read_text('utf-8')) == dec, '十年火山 decade.json 也複製到 data/')

        print('6. 中文簡介（intro.json）')
        exp = td / 'volcano_intro.json'
        ent = lambda zh, src: {'gvp': 'V1', 'zh': zh, 'src': src}
        exp.write_text(json.dumps({'volcanoes': {'100001': ent('一號簡介', 'a'), '999999': ent('不存在', 'z')}}, ensure_ascii=False), 'utf-8')
        conf.write_text(json.dumps({'repo': str(work), 'station': machine_name(), 'intro': str(exp)}))
        n0 = commits()
        main([], data, conf)
        remote = lambda: json.loads(git(td / 'origin.git', 'show', 'HEAD:intro.json'))['volcanoes']
        check(commits() == n0 + 1 and remote() == {'100001': {**ent('一號簡介', 'a'), 'rev': 1, 'checked': False}},
              '資料包沒變也會 commit 中文簡介；不在 GVP 的編號不收')
        check(json.loads((data / 'intro.json').read_text('utf-8'))['volcanoes']['100001']['zh'] == '一號簡介', 'intro.json 也複製到 data/')
        doc = json.loads((work / 'intro.json').read_text('utf-8'))
        doc['volcanoes']['100001']['zh'] = '人工改過'
        (work / 'intro.json').write_text(json.dumps(doc, ensure_ascii=False), 'utf-8')
        git(work, 'commit', '-qam', '網頁上修改')
        git(work, 'push', '-q')
        main([], data, conf)
        check(remote()['100001']['zh'] == '人工改過' and commits() == n0 + 2, '原文沒變：人工修改保留，不再 commit')
        exp.write_text(json.dumps({'volcanoes': {'100001': ent('原文改了的新版', 'b')}}, ensure_ascii=False), 'utf-8')
        main([], data, conf)
        check(remote()['100001']['zh'] == '原文改了的新版', '原文改了、還沒校對：換成新版')
        exp.write_text(json.dumps({'volcanoes': {'100001': {**ent('新版提示詞', 'b'), 'rev': 2}}}, ensure_ascii=False), 'utf-8')
        main([], data, conf)
        check(remote()['100001']['zh'] == '新版提示詞' and remote()['100001']['rev'] == 2, '提示詞改版、還沒校對：換成新版')
        doc = json.loads((work / 'intro.json').read_text('utf-8'))
        doc['volcanoes']['100001'].update(zh='校對過', checked=True)
        (work / 'intro.json').write_text(json.dumps(doc, ensure_ascii=False), 'utf-8')
        git(work, 'commit', '-qam', '校對')
        git(work, 'push', '-q')
        exp.write_text(json.dumps({'volcanoes': {'100001': {**ent('又一版', 'b'), 'rev': 3}}}, ensure_ascii=False), 'utf-8')
        main([], data, conf)
        check(remote()['100001']['zh'] == '校對過' and '請重新校對' not in (data / 'update.log').read_text('utf-8'),
              '校對過的不因提示詞改版覆蓋，也不提醒')
        exp.write_text(json.dumps({'volcanoes': {'100001': ent('又一版', 'c')}}, ensure_ascii=False), 'utf-8')
        main([], data, conf)
        check(remote()['100001']['zh'] == '校對過' and '請重新校對' in (data / 'update.log').read_text('utf-8'),
              '校對過的不覆蓋，原文改了寫進 log 提醒')
        (work / 'intro.json').write_text('{"volcanoes": {', 'utf-8')
        git(work, 'commit', '-qam', '改壞')
        exp.write_text(json.dumps({'volcanoes': {'100002': ent('二號', 'd')}}, ensure_ascii=False), 'utf-8')
        check(main(['--no-push'], data, conf) == 0 and (work / 'intro.json').read_text('utf-8') == '{"volcanoes": {',
              'repo 的 intro.json 壞掉：不覆蓋，等人修好')
        for h in list(log.handlers):  # 暫存目錄刪除前關掉 log 檔
            log.removeHandler(h)
            h.close()

    print(f"\n{'全部通過' if not fails else f'{len(fails)} 項失敗'}")
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(selftest() if '--selftest' in sys.argv else main(sys.argv[1:]))
