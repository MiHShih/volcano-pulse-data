#!/usr/bin/env python3
"""火山脈動展示端的自動更新：啟動腳本開伺服器之前先跑一次（v0.19.12 起）。

  python3 updater.py              有新版就下載、核對、備份、套用；沒網路或任何一步失敗就照舊版，不影響啟動
  python3 updater.py --check      只看有沒有新版，不下載
  python3 updater.py --rollback   退回上一次自動更新之前的版本

新版資訊放在資料 repo 的 release 分支（tools/release.py 發佈）：latest.json 寫版本、更新包檔名、SHA-256、大小、
最低可直接升級的版本。更新包只套用 3D_Dynamic_Volcano_display/ 底下的檔案，不覆蓋 config.json（每台自己的設定）
與 data/ 裡的紀錄檔；三支啟動腳本也不自動換（Windows 執行中的 .bat 被改會出錯），要換時用手動更新包。
config.json 加上 "auto_update": false 就不自動更新；"update_url" 可以改新版資訊的網址。
紀錄寫在 .update/update.log，上一版的備份在 .update/backup/。只用 Python 內建模組。
"""
import hashlib
import json
import re
import shutil
import sys
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urljoin

HERE = Path(__file__).resolve().parent
PREFIX = '3D_Dynamic_Volcano_display/'  # 更新包裡程式資料夾的名稱（tools/pack.py 的 NAME）
DEFAULT_URL = 'https://raw.githubusercontent.com/MiHShih/volcano-pulse-data/release/latest.json'
KEEP = {'config.json', 'data/update.log', 'data/launchd.log'}  # 每台自己的檔案，不覆蓋
WORK = HERE / '.update'
UA = {'User-Agent': 'volcano-pulse-updater/1.0'}


def vtuple(v):
    return tuple(int(x) for x in re.findall(r'\d+', str(v))[:3])


def local_version(root=HERE):
    m = re.search(r"^const VERSION = '(.+)';", (root / 'app.js').read_text('utf-8'), re.M)
    return m.group(1) if m else '0'


def log(msg):
    line = f"{datetime.now(timezone.utc):%Y-%m-%d %H:%M:%S} UTC {msg}"
    print('自動更新：' + msg)
    try:
        WORK.mkdir(exist_ok=True)
        with open(WORK / 'update.log', 'a', encoding='utf-8') as f:
            f.write(line + '\n')
    except OSError:
        pass


def settings(root=HERE):
    try:
        c = json.loads((root / 'config.json').read_text('utf-8'))
        return c if isinstance(c, dict) else {}
    except (OSError, ValueError):
        return {}


def get(url, limit, timeout=20):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f'檔案比預期大（超過 {limit:,} bytes）')
    return data


def check_latest(info):
    """latest.json 的格式檢查，不合格丟 ValueError。"""
    ok = (isinstance(info, dict) and isinstance(info.get('version'), str) and vtuple(info['version'])
          and isinstance(info.get('file'), str) and re.fullmatch(r'[A-Za-z0-9._-]+\.zip', info['file'])
          and isinstance(info.get('sha256'), str) and re.fullmatch(r'[0-9a-f]{64}', info['sha256'])
          and isinstance(info.get('size'), int) and 0 < info['size'] < 2_000_000_000)
    if not ok:
        raise ValueError('latest.json 格式不對')
    return info


def entries(z):
    """更新包裡要套用的檔案：(壓縮檔內名稱, 相對路徑)。路徑不安全就整包拒絕。"""
    out = []
    for i in z.infolist():
        n = i.filename
        if not n.startswith(PREFIX) or n.endswith('/'):
            continue  # 啟動腳本在最上層，不自動換
        rel = n[len(PREFIX):]
        parts = rel.split('/')
        if not rel or '\\' in rel or rel.startswith('/') or ':' in parts[0] or any(p in ('', '.', '..') for p in parts):
            raise ValueError(f'更新包裡有不安全的路徑：{n}')
        if rel in KEEP or parts[0] == '.update':
            continue
        out.append((n, rel))
    return out


def apply(zpath, new_version, root=HERE):
    """先解到暫存資料夾，備份會被覆蓋的檔案，再一個一個換上去；中途失敗就把已換的還原。"""
    work = root / '.update'
    stage, backup = work / 'stage', work / 'backup'
    for d in (stage, backup):
        shutil.rmtree(d, ignore_errors=True)
    old_version = local_version(root)
    with zipfile.ZipFile(zpath) as z:
        files = entries(z)
        if not any(rel == 'app.js' for _, rel in files):
            raise ValueError('更新包裡沒有 app.js')
        for n, rel in files:
            dst = stage / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            with z.open(n) as src, open(dst, 'wb') as f:
                shutil.copyfileobj(src, f)
    got = local_version(stage)
    if got != new_version:
        raise ValueError(f'更新包的版本是 {got}，不是 latest.json 寫的 {new_version}')
    added, done = [], []
    try:
        for _, rel in files:
            dst = root / rel
            if dst.exists():
                b = backup / rel
                b.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dst, b)
            else:
                added.append(rel)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(stage / rel), str(dst))
            done.append(rel)
    except Exception:
        restore(root, [r for r in done if r not in added], [r for r in done if r in added])
        raise
    (work / 'last.json').write_text(json.dumps({'from': old_version, 'to': new_version, 'added': added,
                                                'time': datetime.now(timezone.utc).isoformat()}, ensure_ascii=False), 'utf-8')
    shutil.rmtree(stage, ignore_errors=True)
    return old_version, len(files)


def restore(root, changed, added):
    backup = root / '.update' / 'backup'
    for rel in changed:
        if (backup / rel).exists():
            shutil.copy2(backup / rel, root / rel)
    for rel in added:
        (root / rel).unlink(missing_ok=True)


def rollback(root=HERE):
    p = root / '.update' / 'last.json'
    if not p.exists():
        log('沒有上一次自動更新的紀錄，不能退回')
        return 1
    last = json.loads(p.read_text('utf-8'))
    backup = root / '.update' / 'backup'
    changed = [str(b.relative_to(backup)).replace('\\', '/') for b in backup.rglob('*') if b.is_file()]
    restore(root, changed, last.get('added', []))
    p.unlink()
    log(f"已退回 v{last.get('from')}（原本自動更新到 v{last.get('to')}）")
    return 0


def run(argv, root=HERE):
    if '--rollback' in argv:
        return rollback(root)
    conf = settings(root)
    if conf.get('auto_update') is False and '--check' not in argv:
        print('自動更新：config.json 設定為不自動更新，略過')
        return 0
    url = conf.get('update_url') or DEFAULT_URL
    have = local_version(root)
    try:
        info = check_latest(json.loads(get(url, 100_000)))
    except Exception as e:  # 沒網路、網址錯、格式不對：照舊版啟動
        log(f'查不到新版資訊，照目前的 v{have} 啟動（{type(e).__name__}：{str(e)[:120]}）')
        return 0
    new = info['version']
    if vtuple(new) <= vtuple(have):
        print(f'自動更新：已是最新版 v{have}')
        return 0
    if vtuple(have) < vtuple(info.get('min_version') or '0'):
        log(f"目前 v{have} 太舊，不能直接升級到 v{new}；請先手動安裝 v{info['min_version']} 的更新包")
        return 0
    if '--check' in argv:
        print(f'自動更新：有新版 v{new}（目前 v{have}）')
        return 0
    try:
        data = get(urljoin(url, info['file']), info['size'], timeout=60)
        if len(data) != info['size'] or hashlib.sha256(data).hexdigest() != info['sha256']:
            raise ValueError('下載的檔案跟 latest.json 寫的大小或 SHA-256 不符')
        (root / '.update').mkdir(exist_ok=True)
        zpath = root / '.update' / info['file']
        zpath.write_bytes(data)
        old, n = apply(zpath, new, root)
        zpath.unlink(missing_ok=True)
        log(f'已從 v{old} 更新到 v{new}（{n} 個檔案）；要退回請執行 python3 updater.py --rollback')
    except Exception as e:
        log(f'更新失敗，照目前的 v{have} 啟動（{type(e).__name__}：{str(e)[:160]}）')
    return 0


if __name__ == '__main__':
    sys.exit(run(sys.argv[1:]))
