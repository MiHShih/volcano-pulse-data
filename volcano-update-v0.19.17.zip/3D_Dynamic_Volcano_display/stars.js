// 星空背景：畫在地圖底下的 canvas，只在待機模式顯示。四層可以各自開關：
//   星星：耶魯亮星星表（BSC5）約 9,100 顆肉眼可見的星
//   銀河：三種樣式（設定頁切換），都是 tools/make_milkyway.py 做的全天發光圖，黑色＝沒有光
//     nasa 真實銀河：NASA SVS Deep Star Maps 2020（vendor/milkyway-nasa.jpg）
//     glow 星塵光帶：d3-celestial 的銀河輪廓加暖色核心、淡暗帶（vendor/milkyway-glow.jpg），再沿銀河撒上微弱星點
//     both 真實銀河加星塵：NASA 的圖再撒上少一點的星點
//   太陽、月亮與行星：依現在時間計算位置（ephem.js）
//   星座：d3-celestial 的星座連線與中文名（vendor/sky.json）
// 天球座標（赤經、赤緯）用這台電腦現在時間的格林威治平恆星時轉成地球固定的經緯度，
// 所以轉動地球時看到的是那一面背後真正的天空，也會隨時刻與季節改變。地軸傾角已經包含在赤道座標裡。
// 地圖引擎傳入 dir(lat, lon) → 該方向的單位向量，以及 view() → 相機的 right、up、fwd 單位向量與垂直視角 fov（度），
// 兩者用同一個座標系。
import { bodies } from './ephem.js';

const DEG = Math.PI / 180;
const KEY = 'volcano-pulse.stars';     // 星星開關，使用者手動關閉時存 off
const SKY_KEY = 'volcano-pulse.sky';   // 銀河、太陽月亮與行星、星座的開關
const MW_SCALE = 4;                    // 銀河用 1/4 解析度計算再放大，本來就是模糊的光帶
// 銀河樣式：發光圖與星塵星點數（星點依銀河亮度在網頁打開時撒上，固定亂數種子，每次都一樣）
const MW_LOOK = { nasa: { tex: 'vendor/milkyway-nasa.jpg', dust: 0 }, glow: { tex: 'vendor/milkyway-glow.jpg', dust: 20000 },
  both: { tex: 'vendor/milkyway-nasa.jpg', dust: 12000 } };
// 星塵顏色：冷色、暖色（銀河中心附近）各三種亮度
const DUST_COL = ['rgba(225,232,255,.22)', 'rgba(225,232,255,.42)', 'rgba(235,240,255,.7)',
  'rgba(255,236,212,.22)', 'rgba(255,236,212,.42)', 'rgba(255,242,224,.7)'];

// 格林威治平恆星時（度）：IAU 1982 的簡式，幾十年內誤差遠小於一個像素
export const gmst = (ms) => (((280.46061837 + 360.98564736629 * (ms / 864e5 - 10957.5)) % 360) + 360) % 360;
// 太陽直射點（地心緯度＝太陽赤緯，經度＝太陽赤經減恆星時），給地球的白天與黑夜用
export const subsolar = (ms) => {
  const s = bodies(ms)[0];  // BODIES 第一個是太陽
  return { lat: s.dec, lon: ((((s.ra - gmst(ms)) % 360) + 540) % 360) - 180 };
};
// 以 (lat0, lon0) 為中心、角半徑 r 度（不超過 90°）的球冠，轉成 GeoJSON 多邊形的外圈（經度連續，可能超過 ±180°）；
// 包住極點時經度繞一整圈，從極點那一側收回來
export const capRing = (lat0, lon0, r) => {
  const p = lat0 * DEG, d = r * DEG, out = [];
  for (let i = 0; i <= 360; i += 2) {
    const t = i * DEG, la = Math.asin(Math.sin(p) * Math.cos(d) + Math.cos(p) * Math.sin(d) * Math.cos(t));
    let lo = lon0 + Math.atan2(Math.sin(t) * Math.sin(d) * Math.cos(p), Math.cos(d) - Math.sin(p) * Math.sin(la)) / DEG;
    if (out.length) lo += Math.round((out[out.length - 1][0] - lo) / 360) * 360;
    out.push([lo, la / DEG]);
  }
  const pole = 90 - lat0 < r ? 90 : 90 + lat0 < r ? -90 : 0;
  if (pole) out.push([out[out.length - 1][0], pole], [out[0][0], pole], out[0]);
  return out;
};

const COLORS = [[0, '#BCD0FF'], [0.5, '#F5F7FF'], [1, '#FFF0D2'], [Infinity, '#FFD3A8']];  // 依 B-V 色指數
const colorOf = (bv) => COLORS.find(([lim]) => bv < lim)[1];
// 太陽、月亮與行星：最小半徑（像素）與顏色；日月的圓盤會依實際視角放大
const LOOK = { sun: [7, '#FFF1CC'], moon: [6, '#ECEAE4'], mercury: [2.2, '#D8D0C4'], venus: [3.4, '#FFF8E6'],
  mars: [2.8, '#FF9F70'], jupiter: [3.2, '#F3E2C2'], saturn: [2.8, '#EAD9A2'] };
const dot = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
const getJSON = (u) => fetch(u).then((r) => (r.ok ? r.json() : null)).catch(() => null);
// 銀河發光圖轉成「顏色＋不透明度」：不透明度＝三色最大值，顏色除回去，疊在深色背景上就跟原圖一樣亮。
// 每個像素存成一個 32 位元整數，畫的時候整個複製（JPG 本身不透明，讀出來的就是原始數值）
const texCache = new Map();
const loadTex = (src) => texCache.get(src) || texCache.set(src, new Promise((done) => {
  const img = new Image();
  img.onload = () => {
    const c = document.createElement('canvas');
    c.width = img.width;
    c.height = img.height;
    const x = c.getContext('2d');
    x.drawImage(img, 0, 0);
    const d = x.getImageData(0, 0, c.width, c.height).data;
    for (let i = 0; i < d.length; i += 4) {
      const a = Math.max(d[i], d[i + 1], d[i + 2]), k = a ? 255 / a : 0;
      d[i] *= k; d[i + 1] *= k; d[i + 2] *= k;
      d[i + 3] = a < 3 ? 0 : a;  // 很暗的是 JPG 雜訊
    }
    done({ w: c.width, h: c.height, px: d, t: new Uint32Array(d.buffer) });
  };
  img.onerror = () => done(null);
  img.src = src;
})).get(src);

// 固定種子的亂數（mulberry32），星塵每次開網頁都撒在同樣的位置
const rand = (seed) => () => {
  seed = (seed + 0x6D2B79F5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
// 星塵：依銀河亮度（1.6 次方，集中在亮處）抽樣位置，回傳 [赤經, 赤緯, 顏色組]
const makeDust = (tex, n) => {
  if (!tex || !n) return [];
  const { w, px } = tex, W2 = w >> 1, H2 = tex.h >> 1, cdf = new Float64Array(W2 * H2);
  let sum = 0;
  for (let y = 0, k = 0; y < H2; y++) for (let x = 0; x < W2; x++, k++) cdf[k] = sum += (px[(2 * y * w + 2 * x) * 4 + 3] / 255) ** 1.6;
  const r = rand(1), out = [];
  for (let i = 0; i < n; i++) {
    const u = r() * sum;
    let lo = 0, hi = cdf.length - 1;
    while (lo < hi) { const m = (lo + hi) >> 1; if (cdf[m] < u) lo = m + 1; else hi = m; }
    const y = Math.floor(lo / W2), x = lo % W2, q = (2 * y * w + 2 * x) * 4;
    out.push([((x + r()) / W2) * 360, 90 - ((y + r()) / H2) * 180, (px[q] > px[q + 2] + 8 ? 3 : 0) + Math.min(2, Math.floor(r() * 3))]);
  }
  return out;
};

export async function createStars(el, { dir, view }) {
  const opt = { stars: true, mw: true, planets: true, lines: false, night: true, style: 'nasa' };  // night：地球的白天與黑夜，由地圖畫
  try {
    opt.stars = localStorage.getItem(KEY) !== 'off';
    const s = JSON.parse(localStorage.getItem(SKY_KEY) || '{}');
    for (const k of ['mw', 'planets', 'lines', 'night']) if (typeof s[k] === 'boolean') opt[k] = s[k];
    if (MW_LOOK[s.style]) opt.style = s.style;
  } catch { /* 讀不到就用預設 */ }
  const [data, sky, tex0] = await Promise.all([getJSON('vendor/stars.json'), getJSON('vendor/sky.json'), loadTex(MW_LOOK[opt.style].tex)]);
  if (!Array.isArray(data?.stars)) return null;
  let mw = tex0, dust = makeDust(tex0, MW_LOOK[opt.style].dust);
  const cv = document.createElement('canvas');
  cv.className = 'stars';
  el.prepend(cv);
  const ctx = cv.getContext('2d');
  let g = 0, vecs = [], lines = [], names = [], planets = [], dustG = [], on = false, last = '', want = false, font = '';
  // 地球固定座標的基底，給銀河反查天球座標用；兩個地圖引擎的座標系不同，所以都由 dir 推出來
  const B = { x: dir(0, 0), y: dir(0, 90), n: dir(90, 0) };

  // 天體方向（地球固定座標）；恆星時每分鐘前進約 0.25°，所以每分鐘重算一次
  const place = () => {
    const now = Date.now();
    g = gmst(now);
    const d = (dec, ra) => dir(dec, ra - g);
    vecs = data.stars.map(([ra, dec, mag, bv]) => ({
      d: d(dec, ra), c: colorOf(bv),
      r: Math.max(0.55, 1.9 - 0.22 * mag), a: Math.min(1, Math.max(0.28, 1.15 - 0.13 * mag)),
    }));
    lines = (sky?.lines || []).map((s) => s.filter((_, i) => i % 2 === 0).map((ra, i) => d(s[2 * i + 1], ra)));
    names = (sky?.names || []).map((n) => ({ d: d(n.dec, n.ra), zh: n.zh }));
    planets = bodies(now).map((b) => ({ ...b, d: d(b.dec, b.ra) }));
    dustG = DUST_COL.map(() => []);
    for (const [ra, dec, k] of dust) dustG[k].push(d(dec, ra));
    last = '';
  };

  // 銀河：每個低解析度像素反查它對著的天球座標，到亮度圖取值。
  // 待機自轉只是鏡頭繞地軸轉：每個像素的赤緯不變、赤經整體平移，所以查表位置只在縮放、飛行、改變大小時重算，
  // 自轉時每一格只加上平移量（Pi 上逐像素算三角函數會卡）
  let mwCv = null, mwCtx = null, mwImg = null, mwOut = null, mwKey = '', rowOff = null, col0 = null;
  const drawMW = (v, w, h, f) => {
    const sw = Math.ceil(w / MW_SCALE), sh = Math.ceil(h / MW_SCALE);
    if (!sw || !sh) return;  // 地圖區塊還沒排版好
    if (!mwCv) { mwCv = document.createElement('canvas'); mwCtx = mwCv.getContext('2d'); }
    const c = (a) => [dot(a, B.x), dot(a, B.y), dot(a, B.n)];
    const R = c(v.right), U = c(v.up), F = c(v.fwd), { w: TW, h: TH, t } = mw;
    const az = Math.atan2(F[1], F[0]) / DEG;  // 鏡頭方向的經度（地球固定座標）
    // 鏡頭各軸在地軸方向的分量：繞地軸轉不會變，變了才要重算
    const key = [R[2], U[2], F[2]].map((n) => n.toFixed(4)).join() + f.toFixed(1) + sw + 'x' + sh + 't' + TW;
    if (key !== mwKey) {
      mwKey = key;
      mwCv.width = sw;
      mwCv.height = sh;
      mwImg = mwCtx.createImageData(sw, sh);
      mwOut = new Uint32Array(mwImg.data.buffer);
      rowOff = new Int32Array(sw * sh);
      col0 = new Int32Array(sw * sh);
      const kx = TW / 360, ky = TH / 180;
      for (let j = 0, k = 0; j < sh; j++) {
        const y = h / 2 - (j + 0.5) * MW_SCALE;
        const ax = U[0] * y + F[0] * f, ay = U[1] * y + F[1] * f, an = U[2] * y + F[2] * f;
        for (let i = 0; i < sw; i++, k++) {
          const x = (i + 0.5) * MW_SCALE - w / 2;
          const vx = ax + R[0] * x, vy = ay + R[1] * x, vn = an + R[2] * x;
          let lon = Math.atan2(vy, vx) / DEG - az;  // 相對鏡頭方向的經度
          lon -= Math.floor(lon / 360) * 360;
          const dec = Math.atan2(vn, Math.sqrt(vx * vx + vy * vy)) / DEG;  // Math.hypot 慢很多
          rowOff[k] = Math.min(TH - 1, ((90 - dec) * ky) | 0) * TW;
          col0[k] = Math.min(TW - 1, (lon * kx) | 0);
        }
      }
    }
    let s = az + g;  // 赤經＝經度＋恆星時
    s -= Math.floor(s / 360) * 360;
    const shift = Math.round((s * TW) / 360) % TW, n = rowOff.length;
    for (let k = 0; k < n; k++) {
      let col = col0[k] + shift;
      if (col >= TW) col -= TW;
      mwOut[k] = t[rowOff[k] + col];
    }
    mwCtx.putImageData(mwImg, 0, 0);
    ctx.drawImage(mwCv, 0, 0, w, h);
  };

  const draw = (v) => {
    const dpr = window.devicePixelRatio || 1, w = el.clientWidth, h = el.clientHeight;
    if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
      cv.width = Math.round(w * dpr);
      cv.height = Math.round(h * dpr);
    }
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, w, h);  // 深藍底色是 .mapbox 的背景，這裡只畫天體
    const f = h / 2 / Math.tan((v.fov * DEG) / 2);
    // 投影到畫面；在相機後面或太偏的回傳 null
    const P = (d) => {
      const z = dot(d, v.fwd);
      return z <= 0.05 ? null : [w / 2 + (f * dot(d, v.right)) / z, h / 2 - (f * dot(d, v.up)) / z];
    };
    // 字型只讀一次：每格都讀的話，地圖圖釘在動時會逼瀏覽器重算樣式
    font ||= getComputedStyle(document.body).fontFamily;
    if (opt.mw && mw) drawMW(v, w, h, f);
    if (opt.mw && dust.length) {
      // 星塵：數量多，不另外產生陣列，直接算投影；每種顏色一起畫
      const [fx, fy, fz] = v.fwd, [rx, ry, rz] = v.right, [ux, uy, uz] = v.up;
      dustG.forEach((grp, i) => {
        ctx.fillStyle = DUST_COL[i];
        for (const [x, y, z] of grp) {
          const d = x * fx + y * fy + z * fz;
          if (d <= 0.05) continue;
          const px = w / 2 + (f * (x * rx + y * ry + z * rz)) / d, py = h / 2 - (f * (x * ux + y * uy + z * uz)) / d;
          if (px >= 0 && py >= 0 && px < w && py < h) ctx.fillRect(px, py, 1.2, 1.2);
        }
      });
    }
    if (opt.lines) {
      ctx.strokeStyle = 'rgba(130,165,255,.4)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      for (const s of lines) {
        for (let i = 1; i < s.length; i++) {
          const a = P(s[i - 1]), b = P(s[i]);  // 連線都很短，有一端看不到就整段不畫
          if (a && b) { ctx.moveTo(a[0], a[1]); ctx.lineTo(b[0], b[1]); }
        }
      }
      ctx.stroke();
    }
    if (opt.stars) {
      for (const s of vecs) {
        const p = P(s.d);
        if (!p || p[0] < -2 || p[1] < -2 || p[0] > w + 2 || p[1] > h + 2) continue;
        ctx.globalAlpha = s.a;
        ctx.fillStyle = s.c;
        if (s.r < 1) ctx.fillRect(p[0] - s.r, p[1] - s.r, 2 * s.r, 2 * s.r);
        else { ctx.beginPath(); ctx.arc(p[0], p[1], s.r, 0, 2 * Math.PI); ctx.fill(); }
      }
      ctx.globalAlpha = 1;
    }
    if (opt.lines) {
      ctx.font = `11px ${font}`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = 'rgba(160,185,255,.75)';
      for (const n of names) { const p = P(n.d); if (p) ctx.fillText(n.zh, p[0], p[1]); }
      ctx.textAlign = 'start';
    }
    if (opt.planets) {
      ctx.font = `12px ${font}`;
      ctx.textBaseline = 'middle';
      for (const b of planets) {
        const p = P(b.d);
        if (!p) continue;
        const [r0, col] = LOOK[b.key];
        const r = b.key === 'sun' || b.key === 'moon' ? Math.max(r0, f * Math.tan(0.26 * DEG)) : r0;
        if (b.key === 'sun') {
          const gr = ctx.createRadialGradient(p[0], p[1], r, p[0], p[1], r * 6);
          gr.addColorStop(0, 'rgba(255,236,190,.55)');
          gr.addColorStop(1, 'rgba(255,220,160,0)');
          ctx.fillStyle = gr;
          ctx.beginPath(); ctx.arc(p[0], p[1], r * 6, 0, 2 * Math.PI); ctx.fill();
        }
        ctx.fillStyle = col;
        ctx.beginPath(); ctx.arc(p[0], p[1], r, 0, 2 * Math.PI); ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,.8)';
        ctx.fillText(b.zh, p[0] + r + 5, p[1]);
      }
    }
  };

  // 顯示時每一幀檢查相機有沒有動，有動才重畫（飛行動畫、待機自轉都會跟上）
  const loop = () => {
    if (!on) return;
    const v = view();
    const key = [v.fwd, v.up, v.right].flat().map((n) => n.toFixed(4)).join() + v.fov + el.clientWidth + 'x' + el.clientHeight;
    if (key !== last) { last = key; draw(v); }
    requestAnimationFrame(loop);
  };

  const save = (k) => {
    try {
      if (k === 'stars') localStorage.setItem(KEY, opt.stars ? 'on' : 'off');
      else localStorage.setItem(SKY_KEY, JSON.stringify({ mw: opt.mw, planets: opt.planets, lines: opt.lines, night: opt.night, style: opt.style }));
    } catch { /* 存不了就只在這次有效 */ }
  };
  place();
  setInterval(place, 60000);
  // 實際顯示＝app 要求顯示（待機模式），而且至少開了一層
  const apply = () => {
    const v = want && (opt.stars || opt.mw || opt.planets || opt.lines);
    if (on === v) return;
    on = v;
    cv.classList.toggle('on', v);
    if (v) { last = ''; requestAnimationFrame(loop); }
  };
  return {
    show(v) { want = v; apply(); },
    get: (k) => opt[k],
    toggle(k) {
      opt[k] = !opt[k];
      save(k);
      last = '';
      apply();
      return opt[k];
    },
    // 銀河樣式：先記下選擇，發光圖讀好後換上並重撒星塵
    async style(k) {
      if (!MW_LOOK[k] || k === opt.style) return;
      opt.style = k;
      save('style');
      const t = await loadTex(MW_LOOK[k].tex);
      if (opt.style !== k) return;  // 讀圖時又換了別的樣式
      mw = t;
      dust = makeDust(t, MW_LOOK[k].dust);
      place();
    },
  };
}
