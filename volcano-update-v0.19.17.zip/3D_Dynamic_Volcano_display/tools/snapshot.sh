#!/bin/sh
# 把目前版本存成快照：versions/日期_snapshot-火山脈動v版本.zip（版本號讀 app.js 的 VERSION）
# 不含 vendor/terrain（3.2 GB 地形圖磚，從不修改）、vendor/patches（B 版近看的預算圖，可用 tools/make_patches.py 重算）、
# .venv 與 versions/ 本身；還原時沿用現有的。
# 同名檔已存在就停下，不覆蓋舊快照。執行：sh tools/snapshot.sh
set -e
PROJ=$(cd "$(dirname "$0")/.." && pwd)
NAME=$(basename "$PROJ")
VER=$(sed -n "s/^const VERSION = '\(.*\)';/\1/p" "$PROJ/app.js")
[ -n "$VER" ] || { echo "讀不到 app.js 的 VERSION"; exit 1; }
OUT="$PROJ/versions/$(date +%F)_snapshot-火山脈動v$VER.zip"
[ ! -e "$OUT" ] || { echo "已經有這個版本的快照：$OUT"; exit 1; }
mkdir -p "$PROJ/versions"
cd "$(dirname "$PROJ")"
zip -r -q "$OUT" "$NAME" -x "$NAME/vendor/terrain/*" "$NAME/vendor/patches/*" "$NAME/.venv/*" "$NAME/versions/*" '*/__pycache__/*' '*/.DS_Store'
unzip -tq "$OUT"
ls -l "$OUT"
