#!/usr/bin/env python3
"""用 vendor/terrain 的地形圖磚，產生 B 版（globe.gl）的地形陰影貼圖 vendor/relief.jpg。

等距圓柱投影（globe.gl 需要），白色陸地＋深藍海洋，光源來自西北方。
需要 numpy 與 Pillow；只有重建貼圖時才需要，網頁執行時不需要。
用法：python3 tools/make_relief_texture.py [--zoom 5] [--width 8192]
"""
import argparse
import math
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
LAND = ([0, 600, 2000, 4000, 6000], [(243, 242, 238), (237, 236, 232), (228, 226, 221), (236, 235, 232), (255, 255, 255)])
SEA = ([-8000, -4000, -1500, -200, -1], [(10, 28, 51), (15, 40, 71), (22, 55, 94), (30, 71, 114), (40, 88, 134)])


def ramp(e, stops):
    xs, cs = stops
    return np.stack([np.interp(e, xs, [c[i] for c in cs]) for i in range(3)], axis=-1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--zoom', type=int, default=5)
    ap.add_argument('--width', type=int, default=8192)
    a = ap.parse_args()
    n, T = 2 ** a.zoom, 256
    size = n * T
    elev = np.empty((size, size), np.float32)
    for x in range(n):
        for y in range(n):
            p = ROOT / 'vendor' / 'terrain' / str(a.zoom) / str(x) / f'{y}.png'
            rgb = np.asarray(Image.open(p).convert('RGB'), np.float32)
            elev[y * T:(y + 1) * T, x * T:(x + 1) * T] = rgb[..., 0] * 256 + rgb[..., 1] + rgb[..., 2] / 256 - 32768

    # Web Mercator → 等距圓柱：每一列緯度取對應的 Mercator 列（>85.05° 沿用邊界列）
    W, H = a.width, a.width // 2
    lat = 90 - (np.arange(H) + 0.5) * 180 / H
    phi = np.radians(np.clip(lat, -85.0511, 85.0511))
    rows = np.clip(((1 - np.log(np.tan(np.pi / 4 + phi / 2)) / np.pi) / 2 * size).astype(int), 0, size - 1)
    cols = ((np.arange(W) + 0.5) * size / W).astype(int)
    e = elev[rows][:, cols]
    del elev

    # Mercator 圖磚沒有涵蓋 85.05° 以外：北極當海洋、南極當冰原高地，不沿用邊緣像素（會出現條紋）
    e[lat > 85.0511] = -3000
    e[lat < -85.0511] = 2800

    # 地形陰影：以實際地面距離計算坡度，垂直誇大 10 倍讓起伏看得出來
    R = 6371000.0
    dx = np.maximum(R * np.cos(np.radians(lat))[:, None] * math.radians(360 / W), 1.0)
    dy = R * math.radians(180 / H)
    gy, gx = np.gradient(e)
    sx, sy = gx / dx * 10, -gy / dy * 10
    az, alt = math.radians(315), math.radians(45)
    lx, ly, lz = math.sin(az) * math.cos(alt), math.cos(az) * math.cos(alt), math.sin(alt)
    rel = np.clip((-sx * lx - sy * ly + lz) / np.sqrt(sx * sx + sy * sy + 1), 0, 1) / lz  # 平地 = 1

    land = e >= 0
    color = np.where(land[..., None], ramp(e, LAND), ramp(e, SEA))
    k = np.where(land, np.clip(0.5 + 0.5 * rel, 0.38, 1.1), np.clip(0.84 + 0.16 * rel, 0.68, 1.06))
    img = np.clip(color * k[..., None], 0, 255).astype(np.uint8)
    out = ROOT / 'vendor' / 'relief.jpg'
    Image.fromarray(img).save(out, quality=88, optimize=True, progressive=True)
    print(f'{out}：{W}×{H}，{out.stat().st_size / 1e6:.1f} MB')


if __name__ == '__main__':
    main()
