// ephem.js 自我檢查：跟 JPL Horizons 的地心天體位置（astrometric RA/Dec，2026-11-07 查詢）比對角距離。
// 執行：node tools/check_ephem.mjs
import { bodies } from '../ephem.js';
import { subsolar, capRing } from '../stars.js';

const DATES = ['2010-01-01T00:00Z', '2026-11-07T00:00Z', '2040-06-15T12:00Z'];
const REF = {
  sun: [[281.21751, -23.03733], [221.75628, -16.10233], [83.94589, 23.31745]],
  moon: [[104.30307, 23.51343], [194.71565, -10.52771], [151.3364, 17.31301]],
  mercury: [[290.17608, -20.49177], [216.56527, -14.01228], [99.4084, 21.47363]],
  venus: [[278.42319, -23.64939], [200.47214, -12.25399], [88.50322, 23.86579]],
  mars: [[142.32706, 18.79903], [144.16571, 16.06659], [146.02854, 14.9785]],
  jupiter: [[328.78547, -13.65642], [147.17049, 13.97958], [173.62013, 4.18096]],
  saturn: [[184.91079, 0.36698], [8.90337, 0.93466], [185.33716, 0.39677]],
};
const TOL = { sun: 0.05, moon: 0.5, mercury: 0.15, venus: 0.15, mars: 0.15, jupiter: 0.2, saturn: 0.2 };  // 度

const R = Math.PI / 180;
const sep = (a1, d1, a2, d2) => Math.acos(Math.min(1, Math.sin(d1 * R) * Math.sin(d2 * R) + Math.cos(d1 * R) * Math.cos(d2 * R) * Math.cos((a1 - a2) * R))) / R;
let bad = 0;
DATES.forEach((d, i) => {
  for (const b of bodies(Date.parse(d))) {
    const [ra, dec] = REF[b.key][i];
    const s = sep(b.ra, b.dec, ra, dec);
    const ok = s <= TOL[b.key];
    if (!ok) bad++;
    console.log(`${ok ? 'OK ' : 'NG '} ${d.slice(0, 10)} ${b.key.padEnd(8)} 誤差 ${s.toFixed(3)}°（容許 ${TOL[b.key]}°）`);
  }
});
// 地球的白天與黑夜：太陽直射點與黑夜球冠
const chk = (ok, msg) => { if (!ok) bad++; console.log(`${ok ? 'OK ' : 'NG '} ${msg}`); };
const ss = subsolar(Date.parse('2026-06-21T12:00Z'));  // 夏至正午：直射北緯約 23.4°、經度接近 0°（均時差約 1.5 分鐘＝0.4°）
chk(Math.abs(ss.lat - 23.43) < 0.1 && Math.abs(ss.lon) < 1, `夏至正午直射點 ${ss.lat.toFixed(2)}°, ${ss.lon.toFixed(2)}°`);
const ring = capRing(-23.4, 180, 89.5);  // 夏至的黑夜半球包住南極
chk(ring.at(-2)[1] === -90 && Math.abs(Math.abs(ring[180][0] - ring[0][0]) - 360) < 1e-6, '黑夜球冠包住南極時經度繞一圈、從南極收回');
chk(capRing(-10, 0, 72).length === 181, '不包極點的球冠不加極點');
console.log(bad ? `${bad} 項超過容許誤差` : '全部通過');
process.exit(bad ? 1 : 0);
