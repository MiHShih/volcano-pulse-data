"""打包移植檔，放在專案資料夾的上一層。內容對應 docs/ 的操作手冊：

  完整檔 volcano-globe.zip：第一次安裝用，約 3.7 GB（含地形圖磚與 B 版近看的預算圖）
  更新包 volcano-update-v版本.zip：已經裝過完整檔的電腦換新版用，約 15 MB（不含 vendor/terrain/ 與 vendor/patches/）
    --update --patches：預算圖有變時（例如 v0.17.0 第一次加入、畫法改版、來源更新）連 vendor/patches/ 一起帶，約 0.4 GB

兩種的最上層都是啟動腳本（Pi 的 start-volcano.sh、Windows 的 start-volcano.bat、Mac 的 start-volcano.command，
加上 Windows 與 Mac 的視窗版 start-volcano-window）
與 3D_Dynamic_Volcano_display/，在同一個資料夾解壓縮（更新包直接覆蓋）就好。
用 Python 的 zipfile 打包：中文檔名會標成 UTF-8，Windows 解壓縮才不會變亂碼（macOS 內建的 zip 不會標）。
排除 Python 快取與虛擬環境 .venv、.DS_Store、算到一半的暫存檔、版本快照 versions/，以及介紹簡報（*.pptx 與 docs/src/deck-img/）。先寫成暫存檔，檢查通過才取代舊檔。

執行：sh tools/pack.sh（完整檔）、sh tools/pack.sh --update（更新包）、sh tools/pack.sh --update --patches
"""
import os
import re
import sys
import zipfile
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
NAME = PROJ.name
LAUNCHERS = ('pi/start-volcano.sh', 'win/start-volcano.bat', 'mac/start-volcano.command',
             'win/start-volcano-window.bat', 'mac/start-volcano-window.command')  # 後兩支是視窗版（v0.19.16）


def files(update, patches):
    for root, dirs, names in os.walk(PROJ):
        rel = Path(root).relative_to(PROJ)
        dirs[:] = sorted(d for d in dirs if d not in ('__pycache__', '.venv', '.update') and not (rel == Path('.') and d == 'versions')
                         and not (rel == Path('docs/src') and d == 'deck-img')  # 介紹簡報的截圖，展示機用不到
                         and not (update and rel == Path('vendor') and (d == 'terrain' or (d == 'patches' and not patches))))
        for n in sorted(names):
            if n != '.DS_Store' and not n.endswith(('.zip.new', '.tmp', '.pptx')):
                yield Path(root) / n


def main(argv):
    update, patches = '--update' in argv, '--patches' in argv
    ver = re.search(r"^const VERSION = '(.+)';", (PROJ / 'app.js').read_text('utf-8'), re.M).group(1)
    out = PROJ.parent / (f'volcano-update-v{ver}.zip' if update else 'volcano-globe.zip')
    tmp = out.with_name(out.name + '.new')
    for s in LAUNCHERS:
        os.chmod(PROJ / s, 0o755)  # 解壓縮後可以直接執行
    # 完整檔大多是地形 PNG，壓縮也不會變小，只打包比較快
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED if update else zipfile.ZIP_STORED) as z:
        n = 0
        for p in files(update, patches):
            z.write(p, f'{NAME}/{p.relative_to(PROJ).as_posix()}')
            n += 1
        for s in LAUNCHERS:
            z.write(PROJ / s, Path(s).name)
    with zipfile.ZipFile(tmp) as z:
        bad = z.testzip()
        names = z.namelist()
        utf8 = all(i.flag_bits & 0x800 for i in z.infolist() if not i.filename.isascii())
    terrain = any('/vendor/terrain/' in x for x in names)
    ok = bad is None and utf8 and all(Path(s).name in names for s in LAUNCHERS) and terrain != update and f'{NAME}/http_server.py' in names  # 啟動腳本要用
    if not ok:
        tmp.unlink()
        sys.exit(f'檢查不通過，保留舊檔：損壞 {bad}、UTF-8 檔名 {utf8}、地形圖磚 {terrain}')
    os.replace(tmp, out)
    print(f'{out}：v{ver}，{n:,} 個檔案加 {len(LAUNCHERS)} 支啟動腳本，{out.stat().st_size / 1e6:,.0f} MB')
    if out.stat().st_size >= 2 ** 32:
        print('注意：超過 FAT32 的單檔上限 4 GB，隨身碟要格式化成 exFAT')


if __name__ == '__main__':
    main(sys.argv[1:])
