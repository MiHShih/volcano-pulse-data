#!/usr/bin/env python3
"""B 版近看用的火山周邊地形圖：資料站預先算好存起來，展示機只讀圖、不計算。

每座火山 3 層，以火山為中心、1024×1024 像素、等距圓柱投影（globe.gl 貼圖的投影）、外圈漸淡的 WebP：
  z8 約 600 km 見方、z10 約 150 km、z12 約 40 km（赤道的大小，越往高緯越小）
存在 vendor/patches/{vnum}-{z}.webp；清單 vendor/patches/index.json 記每座火山的位置、各層經緯度範圍、
用到的來源圖磚指紋（src）與畫法版本（rev）。配色與光源同 B 版底圖（tools/make_relief_texture.py）。

算過就不再算，只有這些情況才重算：
  新火山、火山位置改了、檔案不見了；畫法改了（RENDER_REV 加 1）；
  每 28 天問一次 AWS 用到的圖磚有沒有變（HEAD 比對 ETag，AWS 的 ETag 就是檔案的 MD5），有變才重算用到它的火山。
來源圖磚先讀 vendor/terrain（A 版的本機圖磚），沒有的才向 AWS 下載，用完不保留。
需要 numpy 與 Pillow：python3 -m venv .venv && .venv/bin/pip install numpy pillow

用法：
  .venv/bin/python tools/make_patches.py              每天：補新的與改版的，到期順便檢查來源
  .venv/bin/python tools/make_patches.py --check      立刻檢查來源有沒有變
  .venv/bin/python tools/make_patches.py --only 282080,211060   重算這幾座（調畫法時用）
  .venv/bin/python tools/make_patches.py --selftest
"""
import argparse
import hashlib
import io
import json
import math
import os
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np
from PIL import Image

from make_relief_texture import LAND, SEA, ramp

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'vendor' / 'patches'
LOCAL = ROOT / 'vendor' / 'terrain'
URL = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'
LEVELS = (8, 10, 12)
N = 1024  # 每層的邊長（像素）
FADE = 64  # 外圈漸淡的寬度（像素），跟底圖或下一層接起來看不出邊界
EXAG = {8: 5, 10: 3.5, 12: 2.5}  # 陰影的垂直誇大：越精細越小，起伏感跟 B 版底圖（z5、10 倍）接近
RENDER_REV = 1  # 改了畫法（配色、陰影、範圍）就加 1，下次全部重算
CHECK_DAYS = 28
PNG = b'\x89PNG\r\n\x1a\n'
pool = ThreadPoolExecutor(16)
cache = {}  # 這次執行下載過的圖磚，鄰近火山共用；不存檔


def merc_y(lat, size):
    lat = np.clip(lat, -85.0511, 85.0511)
    return (1 - np.log(np.tan(np.pi / 4 + np.radians(lat) / 2)) / np.pi) / 2 * size


def lat_of(y, size):
    return np.degrees(np.arctan(np.sinh(np.pi * (1 - 2 * np.asarray(y, float) / size))))


def window(lat, lon, z):
    """以火山為中心的 N×N Mercator 視窗：左上角像素 (x0, y0)，與輸出圖的範圍 [南, 西, 北, 東]（度）。"""
    size = 256 * 2 ** z
    x0 = round((lon + 180) / 360 * size - N / 2)
    y0 = min(max(round(float(merc_y(lat, size)) - N / 2), 0), size - N)
    box = [float(lat_of(y0 + N, size)), x0 / size * 360 - 180, float(lat_of(y0, size)), (x0 + N) / size * 360 - 180]
    return x0, y0, [round(b, 6) for b in box]


def tile_list(lat, lon):
    """三層用到的圖磚 (z, x, y)，x 已換算到 0..2^z-1（跨換日線）。"""
    out = []
    for z in LEVELS:
        x0, y0, _ = window(lat, lon, z)
        out += [(z, tx % 2 ** z, ty) for ty in range(y0 // 256, (y0 + N - 1) // 256 + 1)
                for tx in range(x0 // 256, (x0 + N - 1) // 256 + 1)]
    return out


def download(z, x, y):
    key = (z, x, y)
    if key in cache:
        return cache[key]
    for attempt in range(3):
        try:
            with urllib.request.urlopen(URL.format(z=z, x=x, y=y), timeout=30) as r:
                data = r.read()
            if data[:8] != PNG:
                raise ValueError(f'{z}/{x}/{y} 不是 PNG')
            break
        except (OSError, ValueError):
            if attempt == 2:
                raise
            time.sleep(2)
    if len(cache) > 4000:
        cache.pop(next(iter(cache)))
    cache[key] = data
    return data


def source(z, x, y, etags=None):
    """來源圖磚：本機有、而且（有 ETag 時）跟 AWS 一樣就讀本機，否則下載。"""
    p = LOCAL / str(z) / str(x) / f'{y}.png'
    if p.exists():
        data = p.read_bytes()
        h = hashlib.md5(data).hexdigest()
        if etags is None or etags.get((z, x, y), h) == h:  # 這次沒問 AWS 的圖磚（例如新火山的）照樣讀本機
            return data
    return download(z, x, y)


def render(lat, lon, z, datas):
    """一層：Mercator 圖磚接起來，算陰影與配色，轉成等距圓柱，外圈漸淡。datas：{(x, y): PNG bytes}，x 未換算。"""
    size = 256 * 2 ** z
    x0, y0, box = window(lat, lon, z)
    tx0, ty0 = x0 // 256, y0 // 256
    big = np.zeros(((((y0 + N - 1) // 256) - ty0 + 1) * 256, (((x0 + N - 1) // 256) - tx0 + 1) * 256), np.float32)
    for (tx, ty), data in datas.items():
        rgb = np.asarray(Image.open(io.BytesIO(data)).convert('RGB'), np.float32)
        big[(ty - ty0) * 256:(ty - ty0 + 1) * 256, (tx - tx0) * 256:(tx - tx0 + 1) * 256] = \
            rgb[..., 0] * 256 + rgb[..., 1] + rgb[..., 2] / 256 - 32768
    e = big[y0 - ty0 * 256:y0 - ty0 * 256 + N, x0 - tx0 * 256:x0 - tx0 * 256 + N]

    # 陰影：同 B 版底圖的算法；Mercator 每個像素在地面上是正方形，邊長隨緯度變
    m = 40075016.686 * np.cos(np.radians(lat_of(y0 + np.arange(N) + 0.5, size))) / size
    gy, gx = np.gradient(e)
    sx, sy = gx / m[:, None] * EXAG[z], -gy / m[:, None] * EXAG[z]
    az, alt = math.radians(315), math.radians(45)
    lx, ly, lz = math.sin(az) * math.cos(alt), math.cos(az) * math.cos(alt), math.sin(alt)
    rel = np.clip((-sx * lx - sy * ly + lz) / np.sqrt(sx * sx + sy * sy + 1), 0, 1) / lz
    land = e >= 1  # z11 以上海面一律是 0 m（沒有水深），同 A 版：0 m 算水域
    color = np.where(land[..., None], ramp(e, LAND), ramp(np.minimum(e, -1), SEA))
    k = np.where(land, np.clip(0.5 + 0.5 * rel, 0.38, 1.1), np.clip(0.84 + 0.16 * rel, 0.68, 1.06))
    img = color * k[..., None]

    # Mercator → 等距圓柱：輸出每一列的緯度等距，取對應的 Mercator 列（線性內插）
    s, _, n, _ = box
    yr = merc_y(n - (np.arange(N) + 0.5) * (n - s) / N, size) - y0 - 0.5
    i0 = np.clip(np.floor(yr).astype(int), 0, N - 1)
    f = np.clip(yr - i0, 0, 1)[:, None, None]
    img = img[i0] * (1 - f) + img[np.minimum(i0 + 1, N - 1)] * f

    r = np.hypot(*(np.mgrid[0:N, 0:N] + 0.5 - N / 2))
    alpha = np.clip((N / 2 - r) / FADE, 0, 1) * 255
    return box, Image.fromarray(np.dstack([img, alpha]).clip(0, 255).astype(np.uint8), 'RGBA')


def build(v, etags=None):
    """算一座火山的三層，回傳清單項目；來源指紋是三層所有圖磚 MD5 的雜湊。"""
    tiles = tile_list(v['lat'], v['lon'])
    datas = dict(zip(tiles, pool.map(lambda t: source(*t, etags), tiles)))
    src = hashlib.sha1('\n'.join(f'{z}/{x}/{y}={hashlib.md5(d).hexdigest()}' for (z, x, y), d in sorted(datas.items())).encode()).hexdigest()
    boxes = []
    for z in LEVELS:
        x0, y0, _ = window(v['lat'], v['lon'], z)
        mine = {(tx, ty): datas[(z, tx % 2 ** z, ty)] for ty in range(y0 // 256, (y0 + N - 1) // 256 + 1)
                for tx in range(x0 // 256, (x0 + N - 1) // 256 + 1)}
        box, im = render(v['lat'], v['lon'], z, mine)
        p = OUT / f"{v['vnum']}-{z}.webp"
        tmp = p.with_suffix('.tmp')
        im.save(tmp, 'WEBP', quality=80, method=4)
        os.replace(tmp, p)
        boxes.append(box)
    return {'lat': v['lat'], 'lon': v['lon'], 'rev': RENDER_REV, 'src': src, 'b': boxes}


def head_etags(tiles):
    def one(t):
        req = urllib.request.Request(URL.format(z=t[0], x=t[1], y=t[2]), method='HEAD')
        for attempt in range(3):
            try:
                with urllib.request.urlopen(req, timeout=30) as r:
                    return t, r.headers.get('ETag', '').strip('"')
            except OSError:
                if attempt == 2:
                    return t, None
                time.sleep(2)
    return dict(pool.map(one, tiles))


def save(idx):
    p = OUT / 'index.json'
    tmp = p.with_suffix('.tmp')
    tmp.write_text(json.dumps(idx, ensure_ascii=False, separators=(',', ':')), 'utf-8')
    os.replace(tmp, p)


def main(argv):
    ap = argparse.ArgumentParser()
    ap.add_argument('--check', action='store_true')
    ap.add_argument('--only', default='')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args(argv)
    if a.selftest:
        return selftest()
    OUT.mkdir(parents=True, exist_ok=True)
    vols = {str(v['vnum']): v for v in json.loads((ROOT / 'data' / 'volcanoes.json').read_text('utf-8'))}
    try:
        idx = json.loads((OUT / 'index.json').read_text('utf-8'))
    except (OSError, ValueError):
        idx = {}
    idx.update(rev=RENDER_REV, levels=list(LEVELS), n=N)
    have = idx.setdefault('volcanoes', {})

    gone = [k for k in have if k not in vols]
    for k in gone:
        del have[k]
        for z in LEVELS:
            (OUT / f'{k}-{z}.webp').unlink(missing_ok=True)

    def stale(k, v):
        p = have.get(k)
        return (not p or p.get('rev') != RENDER_REV or (p['lat'], p['lon']) != (v['lat'], v['lon'])
                or not all((OUT / f'{k}-{z}.webp').exists() for z in LEVELS))
    only = set(a.only.split(',')) - {''}
    todo = [k for k in only if k in vols] if only else [k for k, v in vols.items() if stale(k, v)]

    etags, changed = None, 0
    last = idx.get('checked_utc')
    due = a.check or not last or datetime.now(timezone.utc) - datetime.fromisoformat(last.replace('Z', '+00:00')) > timedelta(days=CHECK_DAYS)
    if due and have:
        lists = {k: tile_list(vols[k]['lat'], vols[k]['lon']) for k in have if k not in todo}
        tiles = sorted({t for ts in lists.values() for t in ts})
        print(f'地形預算圖：檢查來源，向 AWS 確認 {len(tiles):,} 張圖磚（約 25 分鐘）', flush=True)
        etags = head_etags(tiles)
        if any(e is None for e in etags.values()):
            print(f'地形預算圖：有 {sum(e is None for e in etags.values())} 張圖磚問不到 AWS，這次不檢查來源', flush=True)
            etags = None
        else:
            for k, ts in lists.items():
                src = hashlib.sha1('\n'.join(f'{z}/{x}/{y}={etags[(z, x, y)]}' for z, x, y in sorted(ts)).encode()).hexdigest()
                if src != have[k]['src']:
                    todo.append(k)
                    changed += 1
            idx['checked_utc'] = datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')

    # 第一次全部算的時候用的就是當下的來源，當作檢查過
    idx.setdefault('checked_utc', datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'))
    # 鄰近的火山排在一起，下載過的圖磚可以共用
    todo.sort(key=lambda k: (round(vols[k]['lon'] / 5), vols[k]['lat']))
    done, fails, t0 = 0, 0, time.time()
    for i, k in enumerate(todo, 1):
        try:
            have[k] = build(vols[k], etags)
            done += 1
            fails = 0
        except (OSError, ValueError) as e:
            fails += 1
            print(f'地形預算圖：{k} {vols[k]["name"]} 失敗（{e}），明天再試', flush=True)
            if fails >= 5:
                print('地形預算圖：連續 5 座失敗，可能沒有網路，先停下', flush=True)
                break
        if i % 20 == 0 or i == len(todo):
            save(idx)
        if i % 50 == 0:
            print(f'地形預算圖：{i}/{len(todo)}，{time.time() - t0:.0f} 秒', flush=True)
    if gone or not todo:
        save(idx)
    print(f'地形預算圖：新算 {done} 座、移除 {len(gone)} 座' + (f'、來源有變 {changed} 座' if etags else '')
          + f'，共 {len(have)} 座', flush=True)


def selftest():
    for lat, lon in ((31.593, 130.657), (-77.53, 167.17), (51.93, 179.58), (19.421, -155.287)):
        for z in LEVELS:
            x0, y0, (s, w, n, e) = window(lat, lon, z)
            assert s < n and w < e and abs((e - w) - N / (256 * 2 ** z) * 360) < 1e-6
            if abs(lat) < 80:
                assert s < lat < n and w < lon < e, (lat, lon, z)
        assert all(0 <= x < 2 ** z and 0 <= y < 2 ** z for z, x, y in tile_list(lat, lon))
    assert abs(float(lat_of(merc_y(46.85, 4096), 4096)) - 46.85) < 1e-9
    assert 48 <= len(tile_list(31.593, 130.657)) <= 75  # 每層 4×4 或 5×5 張
    print('make_patches 自我檢查通過')


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
