"""產生待機星空的兩張銀河圖（設定頁「銀河樣式」用），都是 2048×1024 的發光圖：黑色＝沒有光，
等距圓柱投影，x＝赤經 0°→360°、y＝赤緯 +90°→-90°（跟 vendor/milkyway.png 一樣）。

  vendor/milkyway-nasa.jpg  真實銀河：NASA SVS Deep Star Maps 2020 的 milkyway_2020_4k.exr（只有銀河、拿掉亮星的全天圖），
                            來源 https://svs.gsfc.nasa.gov/4851 ，公有領域，出處要寫
                            「NASA/Goddard Space Flight Center Scientific Visualization Studio. Gaia DR2: ESA/Gaia/DPAC」
  vendor/milkyway-glow.jpg  星塵光帶的光帶：由 d3-celestial 的銀河輪廓 vendor/milkyway.png 加上柔和外光、暖色核心與淡暗帶
                            （暗帶與紋理是模擬的，不是真實結構；星點由 stars.js 在網頁打開時依亮度撒上）

用專案的 .venv（numpy、Pillow）執行：.venv/bin/python tools/make_milkyway.py 下載的milkyway_2020_4k.exr
"""
import struct
import sys
import zlib
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
W, H = 2048, 1024
D = np.pi / 180
# J2000 赤道座標轉銀道座標
GAL = np.array([[-0.0548755604, -0.8734370902, -0.4838350155], [0.4941094279, -0.4448296300, 0.7469822445],
                [-0.8676661490, -0.1980763734, 0.4559837762]])


def read_exr(path):
    """最小的 OpenEXR 讀取：只支援 scanline、ZIP/ZIPS 壓縮、HALF/FLOAT 通道（Deep Star Maps 的格式），回傳 {通道: 陣列}。"""
    b = Path(path).read_bytes()
    assert b[:4] == b'\x76\x2f\x31\x01', '不是 OpenEXR 檔'
    p, attrs = 8, {}
    while b[p] != 0:
        e = b.index(b'\0', p); name = b[p:e].decode(); p = e + 1
        e = b.index(b'\0', p); p = e + 1  # 屬性型別
        n = struct.unpack_from('<i', b, p)[0]; p += 4
        attrs[name] = b[p:p + n]; p += n
    p += 1
    ch, q, raw = [], 0, attrs['channels']
    while raw[q] != 0:
        e = raw.index(b'\0', q); nm = raw[q:e].decode(); q = e + 1
        ch.append((nm, struct.unpack_from('<i', raw, q)[0])); q += 16
    comp = attrs['compression'][0]
    assert comp in (2, 3), f'壓縮方式 {comp} 不支援（只支援 ZIP）'
    x0, y0, x1, y1 = struct.unpack('<4i', attrs['dataWindow'])
    w, h = x1 - x0 + 1, y1 - y0 + 1
    lines = 16 if comp == 3 else 1
    nb = (h + lines - 1) // lines
    size = {1: 2, 2: 4}  # HALF、FLOAT
    out = {nm: np.zeros((h, w), np.float32) for nm, _ in ch}
    for o in struct.unpack_from(f'<{nb}Q', b, p):
        y, n = struct.unpack_from('<ii', b, o)
        d = np.frombuffer(zlib.decompress(b[o + 8:o + 8 + n]), np.uint8).astype(np.int64)
        d = ((np.cumsum(d - 128) + 128) % 256).astype(np.uint8)  # 反預測：t[i] = t[i-1] + d[i] - 128
        half = (d.size + 1) // 2
        t = np.empty(d.size, np.uint8); t[0::2] = d[:half]; t[1::2] = d[half:]  # 前半是偶數位元組、後半是奇數
        q = 0
        for r in range(min(lines, y1 + 1 - y)):
            for nm, pt in ch:  # 每一列依通道名稱順序存放
                k = size[pt] * w
                out[nm][y - y0 + r] = np.frombuffer(t[q:q + k].tobytes(), '<f2' if pt == 1 else '<f4'); q += k
    return out


def radec():
    ra = (np.arange(W) + 0.5) / W * 360
    de = 90 - (np.arange(H) + 0.5) / H * 180
    return np.meshgrid(ra, de)


def galactic(ra, de):
    v = np.stack([np.cos(de * D) * np.cos(ra * D), np.cos(de * D) * np.sin(ra * D), np.sin(de * D)], -1) @ GAL.T
    return np.degrees(np.arctan2(v[..., 1], v[..., 0])), np.degrees(np.arcsin(np.clip(v[..., 2], -1, 1)))


def at(img, ra, de, r=12):
    """某個天球座標附近（約 ±2°）的平均亮度（0～1，三色最大值）；單點可能剛好落在暗帶上。"""
    y, x = int((90 - de) / 180 * H), int(ra / 360 * W)
    return img[max(0, y - r):y + r + 1].take(range(x - r, x + r + 1), axis=1, mode='wrap').max(-1).mean() / 255


def nasa(path):
    c = read_exr(path)
    rgb = np.dstack([c['R'], c['G'], c['B']])  # 0～1，跟 NASA 自己的預覽 JPG 一樣是顯示用的數值
    s = np.where(rgb <= 0.0031308, 12.92 * rgb, 1.055 * np.clip(rgb, 0, 1) ** (1 / 2.4) - 0.055)  # 轉成 sRGB 再調亮度
    # NASA 圖的赤經 0° 在正中間、往左增加；換成 0° 在左邊、往右增加
    h0, w0 = s.shape[:2]
    cols = (np.floor((0.5 - (np.arange(w0) + 0.5) / w0) * w0) % w0).astype(int)
    s = s[:, cols]
    # 扣掉銀河外的底光（遠處暗星），只留銀河本身；中間調稍微壓暗，核心保留
    e = np.clip((s - 0.11) / (0.82 - 0.11), 0, 1) ** 1.15 * 0.8
    img = Image.fromarray((e * 255 + 0.5).astype(np.uint8)).resize((W, H), Image.LANCZOS)
    return np.asarray(img)


def glow():
    t = Image.open(ROOT / 'vendor' / 'milkyway.png').convert('L')
    up = lambda r: np.asarray(t.resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(r)), np.float32) / 255
    ra, de = radec()
    L, B = galactic(ra, de)
    rng = np.random.default_rng(1)

    def fbm(octaves):  # 多層隨機雜訊，做出雲氣的明暗
        n = sum(0.62 ** k * np.asarray(Image.fromarray((rng.random((h, w)) * 255).astype(np.uint8)).resize((W, H), Image.BICUBIC), np.float32)
                for k, (w, h) in enumerate(octaves))
        return (n - n.min()) / (n.max() - n.min())

    n1 = fbm([(24, 12), (48, 24), (96, 48), (192, 96), (384, 192)])
    n2 = fbm([(64, 32), (128, 64), (256, 128), (512, 256)])
    lane = ((L > -28) & (L < 75)) * np.clip(1 - np.abs(L - 25) / 55, 0, 1) ** 0.5  # 天鷹座到人馬座的大暗隙
    dust = 1 - 0.45 * lane * np.exp(-((B - 1.2 - 2.5 * (n2 - .5)) / 1.5) ** 2 / 2) * (0.55 + 0.45 * n2)
    bulge = 0.45 * np.exp(-(L ** 2 / (2 * 14 ** 2) + B ** 2 / (2 * 7 ** 2)))
    i = np.clip(((up(5) ** 0.9 * (0.55 + 0.9 * n1) + 0.45 * up(16)) * dust + bulge * (0.6 + 0.6 * n1) * dust) * 0.85, 0, 1)
    warm = np.exp(-(L / 38) ** 2 / 2)[..., None]
    col = warm * np.array([246, 226, 200]) + (1 - warm) * np.array([196, 208, 240])
    return np.clip(i[..., None] * col * 0.7, 0, 255).astype(np.uint8)  # 最亮處約 70% 不透明


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    for name, img in (('nasa', nasa(sys.argv[1])), ('glow', glow())):
        # 自我檢查：銀河中心（RA 266.4°、Dec -28.9°）要亮，銀河北極（RA 192.9°、Dec +27.1°）要暗
        core, pole = at(img, 266.4, -28.9), at(img, 192.9, 27.1)
        assert core > 0.2 and pole < 0.02, f'{name}：銀河中心 {core:.2f}、銀河北極 {pole:.2f}，方向可能反了'
        out = ROOT / 'vendor' / f'milkyway-{name}.jpg'
        Image.fromarray(img).save(out, quality=88, optimize=True)
        print(f'{out.name} {W}x{H}，{out.stat().st_size / 1024:.0f} KB（銀河中心 {core:.2f}、銀河北極 {pole:.2f}）')
    lmc = at(np.asarray(Image.open(ROOT / 'vendor' / 'milkyway-nasa.jpg')), 80.9, -69.8)
    assert lmc > 0.1, f'大麥哲倫雲亮度 {lmc:.2f}，赤經方向可能反了'


if __name__ == '__main__':
    main()
