#!/usr/bin/env python3
"""下載 AWS Terrain Tiles（Terrarium 格式）到 vendor/terrain/{z}/{x}/{y}.png，供離線使用。

用法：
  python3 tools/fetch_terrain.py                          全球 z0–z6
  python3 tools/fetch_terrain.py --volcanoes 10           另外下載每座火山周邊（半徑 30 km）z7–z10
  python3 tools/fetch_terrain.py --maxzoom 6 --volcanoes 10 --radius 30 --fine 12 --fine-radius 15
                                                          再加上火山周邊 15 km 的 z11–z12

已存在的圖磚會略過，中斷後重跑即可續傳。最後寫出 vendor/terrain/local.json，
讓網頁知道全球下載到哪一層，以及哪些更精細的圖磚在本機。只用標準函式庫。
"""
import argparse
import json
import math
import os
import sys
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
URL = 'https://s3.amazonaws.com/elevation-tiles-prod/terrarium/{z}/{x}/{y}.png'
OUT = ROOT / 'vendor' / 'terrain'


def get(tile):
    z, x, y = tile
    p = OUT / str(z) / str(x) / f'{y}.png'
    if p.exists():
        return 0
    p.parent.mkdir(parents=True, exist_ok=True)
    for attempt in range(3):
        try:
            with urllib.request.urlopen(URL.format(z=z, x=x, y=y), timeout=60) as r:
                data = r.read()
            break
        except OSError:
            if attempt == 2:
                raise
    if data[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError('回傳內容不是 PNG')
    tmp = p.with_suffix('.tmp')
    tmp.write_bytes(data)
    os.replace(tmp, p)
    return len(data)


def tile_xy(lat, lon, z):
    n = 2 ** z
    lat = max(min(lat, 85.0511), -85.0511)
    x = int((lon + 180) / 360 * n) % n
    y = int((1 - math.log(math.tan(math.pi / 4 + math.radians(lat) / 2)) / math.pi) / 2 * n)
    return x, min(max(y, 0), n - 1)


def around(vols, z, km):
    """每座火山周邊 km 公里方框涵蓋的圖磚（處理換日線）。"""
    n, tiles = 2 ** z, set()
    for v in vols:
        dlat = km / 111.0
        dlon = km / (111.0 * max(math.cos(math.radians(v['lat'])), 0.05))
        x0, y1 = tile_xy(v['lat'] - dlat, v['lon'] - dlon, z)
        x1, y0 = tile_xy(v['lat'] + dlat, v['lon'] + dlon, z)
        xs = range(x0, x1 + 1) if x0 <= x1 else [*range(x0, n), *range(0, x1 + 1)]
        tiles |= {(z, x, y) for x in xs for y in range(y0, y1 + 1)}
    return tiles


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--maxzoom', type=int, default=6, help='全球下載到哪一層')
    ap.add_argument('--volcanoes', type=int, default=0, metavar='Z', help='火山周邊下載到哪一層（0＝不下載）')
    ap.add_argument('--radius', type=float, default=30, help='火山周邊半徑（公里）')
    ap.add_argument('--fine', type=int, default=0, metavar='Z', help='火山周邊更精細的層級下載到哪一層（0＝不下載）')
    ap.add_argument('--fine-radius', type=float, default=15, help='精細層級的火山周邊半徑（公里）')
    args = ap.parse_args()
    tiles = {(z, x, y) for z in range(args.maxzoom + 1) for x in range(2 ** z) for y in range(2 ** z)}
    if args.volcanoes > args.maxzoom:
        vols = json.loads((ROOT / 'data' / 'volcanoes.json').read_text('utf-8'))
        for z in range(args.maxzoom + 1, args.volcanoes + 1):
            tiles |= around(vols, z, args.radius)
        for z in range(args.volcanoes + 1, args.fine + 1):
            tiles |= around(vols, z, args.fine_radius)
    tiles = sorted(tiles)
    size = fails = 0
    with ThreadPoolExecutor(8) as ex:
        for i, (tile, fut) in enumerate(zip(tiles, [ex.submit(get, t) for t in tiles]), 1):
            try:
                size += fut.result()
            except Exception as e:
                fails += 1
                print('失敗', tile, e, file=sys.stderr)
            if i % 1000 == 0:
                print(f'{i}/{len(tiles)}，本次已下載 {size / 1e6:.0f} MB', flush=True)

    # 清單：全球完整的層級，以及本機有的更精細圖磚
    extra = sorted(f'{p.parent.parent.name}/{p.parent.name}/{p.stem}' for p in OUT.glob('*/*/*.png')
                   if int(p.parent.parent.name) > args.maxzoom)
    manifest = {'maxzoom': args.maxzoom, 'extraMaxzoom': max([args.maxzoom] + [int(t.split('/')[0]) for t in extra]),
                'extra': extra}
    tmp = OUT / 'local.json.tmp'
    tmp.write_text(json.dumps(manifest, separators=(',', ':')), 'utf-8')
    os.replace(tmp, OUT / 'local.json')
    print(f'共 {len(tiles)} 張，失敗 {fails} 張，本次下載 {size / 1e6:.1f} MB；清單列出 {len(extra)} 張精細圖磚')
    return 1 if fails else 0


if __name__ == '__main__':
    sys.exit(main())
