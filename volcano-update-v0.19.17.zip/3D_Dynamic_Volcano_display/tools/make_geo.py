#!/usr/bin/env python3
"""板塊邊界、國界與國名：資料站整理一次，存成 vendor/geo/ 下的小檔，展示機只讀（離線也能用）。

來源（都很少更新，不排程重抓；要更新時重跑這支）：
  板塊邊界：Bird (2003) PB2002，Hugo Ahlenius（Nordpil）轉成 GeoJSON 的版本，ODC-By 1.0（要標出處）
    https://github.com/fraxen/tectonicplates
    用 PB2002_steps 的每一小段（約 30 到 100 km）的類型，接成 4 類線：
      div 張裂（OSR 海洋擴張脊、CRB 大陸裂谷）、sub 隱沒（SUB）、col 碰撞與其他聚合（CCB、OCB）、tra 錯動（OTF、CTF 轉形斷層）
  國界：Natural Earth 1:10m 陸地國界（公有領域）；國名：Natural Earth 1:50m 國家的繁中欄位，改成台灣用語
  板塊名稱：手動選的位置，自我檢查會確認每個位置真的在 PB2002 那個板塊裡面
  地震：USGS ComCat（公有領域）1976 年起規模 5.5 以上的地震（約 2 萬多筆），每次重跑會抓到最新

輸出：
  vendor/geo/plates.json   GeoJSON 線，properties.t = div / sub / col / tra
  vendor/geo/borders.json  GeoJSON 線，properties.d = 1 表示有爭議、未定或實際控制線（畫虛線）
  vendor/geo/labels.json   {"countries": [[名稱, 經度, 緯度, 最小縮放級數], ...], "plates": [[名稱, 經度, 緯度], ...]}
  vendor/geo/quakes.json   {"from", "to", "minmag", "q": [[經度, 緯度, 深度 km, 規模], ...]}，小的在前（畫的時候大的蓋在上面）

用法：
  python3 tools/make_geo.py              下載來源（約 20 MB，用完不保留）並輸出；地震目錄要更新時重跑（例如每年一次）
  python3 tools/make_geo.py --src DIR    改用 DIR 裡已經下載好的來源檔
  python3 tools/make_geo.py --selftest
"""
import argparse
import json
import math
import sys
import tempfile
import urllib.request
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / 'vendor' / 'geo'
SRC = {
    'PB2002_steps.json': 'https://raw.githubusercontent.com/fraxen/tectonicplates/master/GeoJSON/PB2002_steps.json',
    'PB2002_plates.json': 'https://raw.githubusercontent.com/fraxen/tectonicplates/master/GeoJSON/PB2002_plates.json',
    'ne_10m_admin_0_boundary_lines_land.geojson': 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_10m_admin_0_boundary_lines_land.geojson',
    'ne_50m_admin_0_countries.geojson': 'https://raw.githubusercontent.com/nvkelso/natural-earth-vector/master/geojson/ne_50m_admin_0_countries.geojson',
}
QUAKE_URL = ('https://earthquake.usgs.gov/fdsnws/event/1/query?format=csv&eventtype=earthquake&orderby=time-asc'
             '&minmagnitude={m}&starttime={a}-01-01&endtime={b}-01-01')
QUAKE_FROM, QUAKE_MIN = 1976, 5.5  # 1976 年起有全球一致的矩規模（GCMT）；5.5 以上每年約 450 筆
KIND = {'OSR': 'div', 'CRB': 'div', 'SUB': 'sub', 'CCB': 'col', 'OCB': 'col', 'OTF': 'tra', 'CTF': 'tra'}
# Natural Earth 的繁中名稱大多是台灣用語，這些改掉；台灣一律顯示（原本 4.5 級才出現）
ZH_FIX = {
    'Taiwan': '台灣', 'China': '中國', 'Australia': '澳洲', 'Indonesia': '印尼', 'New Zealand': '紐西蘭',
    'South Korea': '南韓', 'North Korea': '北韓', 'Ecuador': '厄瓜多', 'Rwanda': '盧安達', 'Croatia': '克羅埃西亞',
    'Czechia': '捷克', 'Mali': '馬利', 'Malta': '馬爾他', 'Guyana': '蓋亞那', 'Mongolia': '蒙古', 'Palestine': '巴勒斯坦',
}
MIN_FIX = {'Taiwan': 1.0}
# 不標國名：政治地位有爭議的分離地區，以及很小的爭議冰川（國界線照畫）
NO_LABEL = {'Somaliland', 'Northern Cyprus', 'Siachen Glacier'}
# 板塊名稱的位置（經度、緯度）與 PB2002 的板塊代碼。PB2002 把歐亞板塊東邊再分成揚子、阿穆爾等小板塊，
# 教科書通稱歐亞板塊，所以揚子板塊（YA）上也標「歐亞板塊」
PLATES = [
    ('PA', '太平洋板塊', -150, 0), ('PA', '太平洋板塊', 160, 28), ('NA', '北美板塊', -100, 50), ('SA', '南美板塊', -55, -12),
    ('EU', '歐亞板塊', 60, 55), ('YA', '歐亞板塊', 112, 30), ('AF', '非洲板塊', 15, 5), ('SO', '索馬利亞板塊', 50, -5),
    ('IN', '印度板塊', 77, 15), ('AU', '澳洲板塊', 133, -25), ('AN', '南極板塊', 30, -80), ('NZ', '納斯卡板塊', -90, -20),
    ('CO', '可可斯板塊', -93, 8), ('PS', '菲律賓海板塊', 134, 20), ('AR', '阿拉伯板塊', 46, 23), ('CA', '加勒比板塊', -75, 15),
    ('JF', '胡安德富卡板塊', -128, 46),
]


def fetch(src_dir):
    d = Path(src_dir) if src_dir else Path(tempfile.mkdtemp(prefix='geo-'))
    for name, url in SRC.items():
        if not (d / name).exists():
            print('下載', name)
            with urllib.request.urlopen(url, timeout=120) as r:
                (d / name).write_bytes(r.read())
    return {k: json.loads((d / k).read_text(encoding='utf-8')) for k in SRC}


def quakes():
    """USGS 每次最多回 2 萬筆，每 5 年抓一次。"""
    rows, end = [], date.today().year + 1
    for a in range(QUAKE_FROM, end, 5):
        url = QUAKE_URL.format(m=QUAKE_MIN, a=a, b=min(a + 5, end))
        print('下載 USGS 地震', a, '到', min(a + 5, end) - 1)
        with urllib.request.urlopen(url, timeout=180) as r:
            lines = r.read().decode('utf-8').splitlines()
        head = lines[0].split(',')
        i = {k: head.index(k) for k in ('time', 'latitude', 'longitude', 'depth', 'mag')}
        for ln in lines[1:]:
            c = ln.split(',')  # 前幾欄沒有引號，地名（place）在後面，不用解析
            if c[i['mag']] and c[i['depth']]:
                rows.append([round(float(c[i['longitude']]), 2), round(float(c[i['latitude']]), 2),
                             round(float(c[i['depth']])), round(float(c[i['mag']]), 1), c[i['time']][:10]])
    assert len(rows) > 15000, f'地震筆數太少（{len(rows)}），USGS 可能沒有回完整資料'
    last = max(r[4] for r in rows)
    rows.sort(key=lambda r: r[3])
    return {'from': f'{QUAKE_FROM}-01-01', 'to': last, 'minmag': QUAKE_MIN, 'q': [r[:4] for r in rows]}


def split_dateline(line):
    """跨過經度 ±180 的線切成兩段，接點補在 ±180 上；不切的話地圖會把線拉過整個地球。"""
    out, cur = [], [line[0]]
    for (x0, y0), (x1, y1) in zip(line, line[1:]):
        if abs(x1 - x0) > 180:
            edge = 180 if x0 > 0 else -180
            x1u = x1 + 360 if x0 > 0 else x1 - 360  # 接在同一側的經度
            y = y0 + (y1 - y0) * (edge - x0) / (x1u - x0)
            cur.append([edge, round(y, 3)])
            out.append(cur)
            cur = [[-edge, round(y, 3)]]
        cur.append([x1, y1])
    out.append(cur)
    return [c for c in out if len(c) >= 2]


def densify(line, step=1.0):
    """超過 step 度的線段中間補點：B 版的線是直線連接的 3D 點，太長會穿進地球裡面。"""
    out = [line[0]]
    for (x0, y0), (x1, y1) in zip(line, line[1:]):
        n = max(0, math.ceil(max(abs(x1 - x0), abs(y1 - y0)) / step) - 1)
        out += [[round(x0 + (x1 - x0) * k / (n + 1), 3), round(y0 + (y1 - y0) * k / (n + 1), 3)] for k in range(1, n + 1)]
        out.append([x1, y1])
    return out


def simplify(pts, tol):
    """Douglas-Peucker（經緯度直接當平面座標，tol 單位是度）。"""
    if len(pts) < 3:
        return pts
    keep = [False] * len(pts)
    keep[0] = keep[-1] = True
    stack = [(0, len(pts) - 1)]
    while stack:
        a, b = stack.pop()
        (ax, ay), (bx, by) = pts[a], pts[b]
        dx, dy = bx - ax, by - ay
        L = (dx * dx + dy * dy) ** 0.5
        best, bi = 0.0, -1
        for i in range(a + 1, b):
            px, py = pts[i]
            d = abs(dy * (px - ax) - dx * (py - ay)) / L if L else ((px - ax) ** 2 + (py - ay) ** 2) ** 0.5
            if d > best:
                best, bi = d, i
        if best > tol:
            keep[bi] = True
            stack += [(a, bi), (bi, b)]
    return [p for p, k in zip(pts, keep) if k]


def feature(coords, props):
    return {'type': 'Feature', 'properties': props, 'geometry': {'type': 'LineString', 'coordinates': coords}}


def plates(steps):
    """每一小段的起點、終點，同一條邊界、同一類、首尾相接的接成一條線。"""
    lines, cur, key, last = [], None, None, None
    for f in steps['features']:
        q = f['properties']
        k = (q['PLATEBOUND'], KIND[q['STEPCLASS']])
        a, b = [round(q['STARTLONG'], 3), round(q['STARTLAT'], 3)], [round(q['FINALLONG'], 3), round(q['FINALLAT'], 3)]
        if k == key and last == a:
            cur.append(b)
        else:
            cur = [a, b]
            lines.append((k[1], cur))
        key, last = k, b
    return [feature(densify(part), {'t': t}) for t, line in lines for part in split_dateline(line)]


def borders(ne):
    out = []
    for f in ne['features']:
        g = f['geometry']
        parts = g['coordinates'] if g['type'] == 'MultiLineString' else [g['coordinates']]
        d = 0 if f['properties']['FEATURECLA'].startswith('International') else 1
        # Natural Earth 把一條國界切成很多小段，首尾相接的先接回一條再簡化
        chains = []
        for p in parts:
            if chains and chains[-1][-1] == p[0]:
                chains[-1] += p[1:]
            else:
                chains.append(list(p))
        for p in chains:
            line = [[round(x, 3), round(y, 3)] for x, y in simplify(p, 0.005)]
            out += [feature(densify(s), {'d': d} if d else {}) for s in split_dateline(line)]
    return out


def countries(ne):
    out = []
    for f in ne['features']:
        q = f['properties']
        if q['ADMIN'] in NO_LABEL:
            continue
        name = ZH_FIX.get(q['ADMIN'], q['NAME_ZHT'])
        out.append([name, round(q['LABEL_X'], 2), round(q['LABEL_Y'], 2), MIN_FIX.get(q['ADMIN'], q['MIN_LABEL']), q['LABELRANK']])
    out.sort(key=lambda r: (r[3], r[4]))  # 大國在前，地圖照這個順序放、避免重疊
    return [r[:4] for r in out]


def inside(lon, lat, geom):
    """點是否在多邊形裡（射線法；PB2002 的太平洋板塊跨 180°，經度加減 360 再試）。"""
    polys = geom['coordinates'] if geom['type'] == 'MultiPolygon' else [geom['coordinates']]
    for x in (lon, lon + 360, lon - 360):
        for poly in polys:
            ring, hit = poly[0], False
            for (x0, y0), (x1, y1) in zip(ring, ring[1:] + ring[:1]):
                if (y0 > lat) != (y1 > lat) and x < x0 + (lat - y0) * (x1 - x0) / (y1 - y0):
                    hit = not hit
            if hit:
                return True
    return False


def plate_labels(pb):
    by = {}
    for f in pb['features']:
        by.setdefault(f['properties']['Code'], []).append(f['geometry'])
    for code, name, lon, lat in PLATES:
        assert any(inside(lon, lat, g) for g in by[code]), f'{name}（{code}）的標籤位置 {lon},{lat} 不在板塊裡'
    return [[name, lon, lat] for _, name, lon, lat in PLATES]


def cjk_only(s):
    # A 版的文字由瀏覽器字型直接畫（MapLibre 的 localIdeographFontFamily），只支援中日韓文字，不能有英文或符號
    return all(0x4E00 <= ord(c) <= 0x9FFF or 0x3400 <= ord(c) <= 0x4DBF for c in s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--src')
    ap.add_argument('--selftest', action='store_true')
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    s = fetch(a.src)
    data = {
        'plates.json': {'type': 'FeatureCollection', 'features': plates(s['PB2002_steps.json'])},
        'borders.json': {'type': 'FeatureCollection', 'features': borders(s['ne_10m_admin_0_boundary_lines_land.geojson'])},
        'labels.json': {'countries': countries(s['ne_50m_admin_0_countries.geojson']), 'plates': plate_labels(s['PB2002_plates.json'])},
        'quakes.json': quakes(),
    }
    bad = [r[0] for r in data['labels.json']['countries'] + data['labels.json']['plates'] if not cjk_only(r[0])]
    assert not bad, f'名稱有非中文字元：{bad}'
    OUT.mkdir(parents=True, exist_ok=True)
    for name, d in data.items():
        (OUT / name).write_text(json.dumps(d, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
        print(f'{name}：{(OUT / name).stat().st_size / 1024:.0f} KB')
    q = data['quakes.json']
    print(f"板塊邊界 {len(data['plates.json']['features'])} 條、國界 {len(data['borders.json']['features'])} 條、國名 {len(data['labels.json']['countries'])} 個、"
          f"地震 {len(q['q'])} 筆（{q['from']} 到 {q['to']}，規模 {q['minmag']} 以上）")


def selftest():
    # 跨 180° 的線切成兩段，接點在 ±180、緯度內插
    parts = split_dateline([[179.0, 10.0], [-179.0, 12.0]])
    assert parts == [[[179.0, 10.0], [180, 11.0]], [[-180, 11.0], [-179.0, 12.0]]], parts
    assert split_dateline([[10, 0], [20, 0]]) == [[[10, 0], [20, 0]]]
    # 直線上的點會被簡化掉，轉角留著
    assert simplify([[0, 0], [1, 0.001], [2, 0], [2, 1]], 0.01) == [[0, 0], [2, 0], [2, 1]]
    # 射線法：正方形內外，以及跨 180° 的板塊
    sq = {'type': 'Polygon', 'coordinates': [[[0, 0], [10, 0], [10, 10], [0, 10], [0, 0]]]}
    assert inside(5, 5, sq) and not inside(15, 5, sq)
    assert inside(-175, 5, {'type': 'Polygon', 'coordinates': [[[170, 0], [190, 0], [190, 10], [170, 10], [170, 0]]]})
    # 同一條邊界首尾相接的小段接成一條，類型不同就分開
    st = {'features': [{'properties': {'PLATEBOUND': 'A-B', 'STEPCLASS': c, 'STARTLONG': x, 'STARTLAT': 0, 'FINALLONG': x + 1, 'FINALLAT': 0}}
                       for x, c in ((0, 'OSR'), (1, 'OSR'), (2, 'OTF'))]}
    got = plates(st)
    assert [(f['properties']['t'], len(f['geometry']['coordinates'])) for f in got] == [('div', 3), ('tra', 2)], got
    assert densify([[0, 0], [2.5, 0]]) == [[0, 0], [0.833, 0.0], [1.667, 0.0], [2.5, 0]]
    assert densify([[0, 0], [0.5, 0.5]]) == [[0, 0], [0.5, 0.5]] and densify([[0, 0], [1, 0]]) == [[0, 0], [1, 0]]
    assert cjk_only('台灣') and not cjk_only('Taiwan') and not cjk_only('聖・露西亞')
    print('make_geo 自我檢查通過')


if __name__ == '__main__':
    sys.exit(main())
