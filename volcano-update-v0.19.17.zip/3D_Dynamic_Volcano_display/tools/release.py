#!/usr/bin/env python3
"""發佈新版給各台展示端自動更新（updater.py 讀，v0.19.12 起）。在資料站（Mac mini）執行：

  python3 tools/release.py          打包公開版、寫 latest.json、強制推到資料 repo 的 release 分支
  python3 tools/release.py --dry    只做出檔案、不推送，印出放在哪裡

1. 讀 app.js 的 VERSION，用上一層的 volcano-update-v版本.zip（沒有就先打包更新包）。
2. 公開版去掉不該公開的檔案：專案最上層的工作筆記（日期_*.md、*.yaml）、publish.json（資料站的電腦名稱與路徑）、
   data/ 裡的執行紀錄（*.log）。release 分支在公開的資料 repo，任何人都下載得到。
3. latest.json：版本、更新包檔名（含版本，網址每版不同，不會拿到快取的舊檔）、SHA-256、大小、最低可直接升級的版本。
4. 在暫存資料夾建一個只有一個 commit 的 release 分支，強制推上去：只留最新一版，repo 不會越來越大。
   地形預算圖（vendor/patches/，約 0.4 GB）超過 GitHub 單檔 100 MB 的限制，那種更新照舊用手動更新包。
"""
import hashlib
import json
import re
import subprocess
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
PREFIX = PROJ.name + '/'
MIN_VERSION = '0.17.0'  # 比這更舊的機器沒有地形預算圖，要先手動裝 v0.17.0 更新包
PRIVATE = (re.compile(r'\d{4}-\d{2}-\d{2}_[^/]+'), re.compile(r'[^/]+\.yaml'), re.compile(r'publish\.json'), re.compile(r'data/[^/]+\.log'))


def public_zip(src, dst):
    """src 更新包去掉不公開的檔案寫到 dst；回傳去掉的檔名。"""
    dropped = []
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zo:
        for i in zi.infolist():
            rel = i.filename[len(PREFIX):] if i.filename.startswith(PREFIX) else None
            if rel is not None and any(p.fullmatch(rel) for p in PRIVATE):
                dropped.append(rel)
                continue
            zo.writestr(i, zi.read(i.filename))
    return dropped


def main(argv):
    dry = '--dry' in argv
    ver = re.search(r"^const VERSION = '(.+)';", (PROJ / 'app.js').read_text('utf-8'), re.M).group(1)
    pack = PROJ.parent / f'volcano-update-v{ver}.zip'
    if not pack.exists():
        subprocess.run([sys.executable, str(PROJ / 'tools' / 'pack.py'), '--update'], check=True)
    out = Path(tempfile.mkdtemp(prefix='volcano-release-'))
    name = f'volcano-update-v{ver}.zip'
    dropped = public_zip(pack, out / name)
    data = (out / name).read_bytes()
    info = {'version': ver, 'date': datetime.now(timezone.utc).strftime('%Y-%m-%d'), 'file': name,
            'sha256': hashlib.sha256(data).hexdigest(), 'size': len(data), 'min_version': MIN_VERSION}
    (out / 'latest.json').write_text(json.dumps(info, ensure_ascii=False, indent=1), 'utf-8')
    (out / 'README.md').write_text('# release 分支\n\n火山脈動展示端自動更新用（updater.py 讀 latest.json），由資料站的 '
                                   '`tools/release.py` 產生並強制覆蓋，只留最新一版。請勿手動修改。\n', 'utf-8')
    print(f'公開版 {name}：{len(data) / 1e6:.1f} MB，去掉 {len(dropped)} 個不公開的檔案：{"、".join(dropped)}')
    if dry:
        print(f'只做出檔案、沒有推送：{out}')
        return 0
    repo = Path(json.loads((PROJ / 'publish.json').read_text('utf-8'))['repo']).expanduser()
    remote = subprocess.run(['git', '-C', str(repo), 'remote', 'get-url', 'origin'], capture_output=True, text=True, check=True).stdout.strip()
    ident = ['-c', f"user.name={subprocess.run(['git', '-C', str(repo), 'config', 'user.name'], capture_output=True, text=True).stdout.strip() or 'Volcano Pulse'}",
             '-c', f"user.email={subprocess.run(['git', '-C', str(repo), 'config', 'user.email'], capture_output=True, text=True).stdout.strip() or 'volcano@localhost'}"]
    g = lambda *a: subprocess.run(['git', '-C', str(out), *a], capture_output=True, text=True, check=True, timeout=600)
    g('init', '-q', '-b', 'release')
    g('add', '-A')
    g(*ident, 'commit', '-q', '-m', f'release v{ver}')
    g('push', '-q', '--force', remote, 'release:release')
    print(f'已發佈 v{ver} 到 release 分支；各台下次開機會自動更新')
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
