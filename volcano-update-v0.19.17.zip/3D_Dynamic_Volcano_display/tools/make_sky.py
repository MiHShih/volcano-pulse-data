"""把 d3-celestial 的星圖資料轉成星空背景用的精簡檔（只用標準函式庫）。

來源：d3-celestial（Olaf Frohn，BSD-3-Clause），https://github.com/ofrohn/d3-celestial 的 data/
  mw.json                    銀河亮度輪廓（5 層）
  constellations.lines.json  星座連線
  constellations.json        星座名稱與標籤位置（含中文名）

輸出：
  vendor/milkyway.png  全天銀河亮度圖，等距圓柱投影，x＝赤經 0°→360°、y＝赤緯 +90°→-90°，灰階 0～255
  vendor/sky.json      { lines: [[ra, dec, ra, dec, ...], ...], names: [{ id, zh, ra, dec }, ...] }

執行：python3 tools/make_sky.py 下載的data資料夾
"""
import bisect
import json
import math
import os
import struct
import sys
import zlib

W, H = 1024, 512
STEP = 360 / W
# d3-celestial 中文名的錯字與簡體字（依維基百科、天文學名詞資料庫）
ZH_FIX = {'Cha': '蝘蜓座', 'Vol': '飛魚座'}


def raster_mw(mw):
    """每一層用「從南天極往上數穿越輪廓幾次」判斷在不在裡面（南天極在銀河外），五層疊加成亮度 0～5。"""
    img = [[0] * W for _ in range(H)]
    for f in mw['features']:
        cols = [[] for _ in range(W)]
        for poly in f['geometry']['coordinates']:
            for ring in poly:
                for (a, la), (b, lb) in zip(ring, ring[1:]):
                    if b - a > 180:
                        b -= 360
                    elif a - b > 180:
                        b += 360
                    lo, hi = min(a, b), max(a, b)
                    if lo == hi:
                        continue
                    # 欄中心在 [lo, hi) 之間的才算，避免頂點重複計算
                    for i in range(math.ceil(lo / STEP - 0.5), math.ceil(hi / STEP - 0.5)):
                        c = (i + 0.5) * STEP
                        cols[i % W].append(la + (lb - la) * (c - a) / (b - a))
        odd = sum(1 for c in cols if len(c) % 2)
        if odd:
            print(f'警告：{f["id"]} 有 {odd} 欄穿越次數是奇數，該欄可能填錯')
        for x, c in enumerate(cols):
            c.sort()
            for y in range(H):
                if bisect.bisect_left(c, 90 - (y + 0.5) * 180 / H) % 2:  # 這一點以南的穿越次數
                    img[y][x] += 1
    return img


def blur(img, r=2, passes=2):
    """可分離的盒狀模糊（x 方向環繞），讓輪廓的階梯變柔和。"""
    for _ in range(passes):
        img = [[sum(row[(x + d) % W] for d in range(-r, r + 1)) / (2 * r + 1) for x in range(W)] for row in img]
        img = [[sum(img[min(H - 1, max(0, y + d))][x] for d in range(-r, r + 1)) / (2 * r + 1) for x in range(W)] for y in range(H)]
    return img


def write_png(path, img):
    raw = b''.join(b'\x00' + bytes(row) for row in img)
    chunk = lambda t, d: struct.pack('>I', len(d)) + t + d + struct.pack('>I', zlib.crc32(t + d) & 0xFFFFFFFF)
    with open(path, 'wb') as f:
        f.write(b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 0, 0, 0, 0))
                + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''))


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    src = sys.argv[1]
    root = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..')
    load = lambda n: json.load(open(os.path.join(src, n), encoding='utf-8'))

    lvl = raster_mw(load('mw.json'))
    # 自我檢查：銀河中心（人馬座，RA 266.4°、Dec -28.9°）要在最亮的幾層，銀河北極（RA 192.9°、Dec +27.1°）不在銀河裡
    px = lambda ra, dec: lvl[int((90 - dec) / 180 * H)][int(ra / STEP)]
    assert px(266.4, -28.9) >= 3, f'銀河中心亮度 {px(266.4, -28.9)}'
    assert px(192.9, 27.1) == 0, f'銀河北極亮度 {px(192.9, 27.1)}'
    img = [[min(255, round(v / 5 * 255)) for v in row] for row in blur(lvl)]
    write_png(os.path.join(root, 'vendor', 'milkyway.png'), img)

    r2 = lambda v: round(v, 2)
    lines = [[r2(v) for p in seg for v in p] for f in load('constellations.lines.json')['features'] for seg in f['geometry']['coordinates']]
    names = [{'id': f['id'], 'zh': ZH_FIX.get(f['id'], f['properties']['zh']),
              'ra': r2(f['geometry']['coordinates'][0] % 360), 'dec': r2(f['geometry']['coordinates'][1])}
             for f in load('constellations.json')['features']]
    assert len(names) == 89 and all(n['zh'].endswith('座') for n in names)  # 88 星座，巨蛇座分頭尾兩塊
    out = {'source': 'd3-celestial (Olaf Frohn, BSD-3-Clause) https://github.com/ofrohn/d3-celestial', 'lines': lines, 'names': names}
    with open(os.path.join(root, 'vendor', 'sky.json'), 'w', encoding='utf-8') as f:
        json.dump(out, f, ensure_ascii=False, separators=(',', ':'))
    print(f'milkyway.png {W}x{H}；sky.json 連線 {len(lines)} 段、名稱 {len(names)} 個')


if __name__ == '__main__':
    main()
