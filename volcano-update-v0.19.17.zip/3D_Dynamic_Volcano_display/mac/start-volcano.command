#!/bin/sh
# 火山脈動展示端（macOS）：開本機伺服器，再用 Chrome 全螢幕開 A 版（3D 地形）。在 Finder 雙擊執行。
# 放在 3D_Dynamic_Volcano_display 資料夾旁邊，例如 ~/volcano/start-volcano.command（見移植操作手冊）。
# 離開全螢幕：Cmd+Q。關掉本機伺服器：在終端機輸入 pkill -f http.server
cd "$(dirname "$0")/3D_Dynamic_Volcano_display" || { echo "找不到 3D_Dynamic_Volcano_display 資料夾"; exit 1; }
command -v python3 >/dev/null || { echo "找不到 python3，請先照手冊安裝命令列開發者工具"; exit 1; }
# 先檢查有沒有新版（v0.19.12 起）：有就下載套用，沒網路或失敗就照舊版
python3 updater.py || true
# 已經開著的話這行會因為連接埠被占用而結束，沿用原本的伺服器；nohup 讓關掉終端機視窗也不會停
nohup python3 http_server.py >/dev/null 2>&1 &
sleep 3
URL=http://localhost:8000
# 另開一個專用的 Chrome 設定檔，全螢幕參數才不會被已經開著的 Chrome 忽略；待機設定也會記在這個設定檔
if open -Ra "Google Chrome" 2>/dev/null; then
  open -na "Google Chrome" --args --user-data-dir="$HOME/Library/Application Support/volcano-kiosk" --kiosk --no-first-run "$URL"
else
  echo "找不到 Google Chrome，改用預設瀏覽器（未測試）"; open "$URL"
fi
