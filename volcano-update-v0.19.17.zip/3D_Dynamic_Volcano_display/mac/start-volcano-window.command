#!/bin/sh
# 火山脈動展示端（macOS）視窗版（v0.19.16）：一般視窗，可以關閉、縮到 Dock、拖拉大小、拖到第二個螢幕；頁面右上角有「全螢幕」與「離開」。
# 跟 start-volcano.command 一樣放在 3D_Dynamic_Volcano_display 資料夾旁邊，在 Finder 雙擊執行。
# 自動更新只會把這支放進程式資料夾的 mac/ 裡，第一次要自己複製出來。
# 按「離開」會關掉視窗和本機伺服器；Chrome 要完全結束再按 Cmd+Q。
cd "$(dirname "$0")/3D_Dynamic_Volcano_display" || { echo "找不到 3D_Dynamic_Volcano_display 資料夾：請把這支檔案複製到它旁邊"; exit 1; }
command -v python3 >/dev/null || { echo "找不到 python3，請先照手冊安裝命令列開發者工具"; exit 1; }
python3 updater.py || true
nohup python3 http_server.py >/dev/null 2>&1 &
sleep 3
URL='http://localhost:8000/?win=1'
# 跟全螢幕版用同一個專用設定檔，待機等設定兩邊一樣；--app 是沒有分頁與網址列的視窗，Chrome 會記住上次的位置與大小
if open -Ra "Google Chrome" 2>/dev/null; then
  open -na "Google Chrome" --args --user-data-dir="$HOME/Library/Application Support/volcano-kiosk" --app="$URL" --no-first-run
else
  echo "找不到 Google Chrome，改用預設瀏覽器（未測試）"; open "$URL"
fi
