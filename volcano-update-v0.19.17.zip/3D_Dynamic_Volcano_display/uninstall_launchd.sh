#!/bin/bash
# 移除每日自動更新（macOS launchd）。資料檔不會被刪除。
set -euo pipefail
LABEL="local.volcano-globe.update"
PLIST="$HOME/Library/LaunchAgents/$LABEL.plist"
launchctl bootout "gui/$(id -u)/$LABEL" 2>/dev/null || true
rm -f "$PLIST"
echo "已移除排程 $LABEL"
