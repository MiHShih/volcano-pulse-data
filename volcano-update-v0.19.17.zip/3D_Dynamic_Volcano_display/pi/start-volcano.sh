#!/bin/sh
# 火山脈動展示端（Raspberry Pi）：開本機伺服器，再用 Chromium 全螢幕開 A 版（3D 地形，點火山可以近看火山外貌）。
# 太卡的話把最後一行的網址改成 http://localhost:8000/relief.html（B 版，地形貼圖，比較輕）。
# 打包時放在 zip 最上層：在 ~/volcano/ 解壓縮後是 ~/volcano/start-volcano.sh，
# 程式資料夾是旁邊的 ~/volcano/3D_Dynamic_Volcano_display（見操作說明）。
cd "$(dirname "$0")/3D_Dynamic_Volcano_display" || { echo "找不到 3D_Dynamic_Volcano_display 資料夾"; exit 1; }
# 先檢查有沒有新版（v0.19.12 起）：有就下載套用，沒網路或失敗就照舊版，最多等約 1 分鐘
python3 updater.py || true
# 已經開著的話這行會因為連接埠被占用而結束，沿用原本的伺服器
python3 http_server.py >/dev/null 2>&1 &
sleep 3
# Debian 13 Trixie 起指令叫 chromium，舊版叫 chromium-browser
BROWSER=$(command -v chromium || command -v chromium-browser) || { echo "找不到 Chromium"; exit 1; }
# --password-store=basic 避免自動登入時跳出「密碼鑰匙圈」視窗
exec "$BROWSER" --kiosk --noerrdialogs --disable-infobars --no-first-run --password-store=basic http://localhost:8000/
