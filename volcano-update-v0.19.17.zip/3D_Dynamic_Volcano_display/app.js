// 全球火山活動：兩個版本共用的介面（狀態判定、右側面板、詳細卡）。
// 地圖引擎由頁面傳入：map-terrain.js（3D 地形）或 map-relief.js（地形貼圖）。
import { PLATE_KINDS, QUAKE_DEPTHS, GEO_CREDIT } from './geo.js';
import { DIAGRAM } from './teach.js';

// 版本：測試開發期間是 0.x.y，加功能時 x 加 1（y 歸 0），修正或小調整時 y 加 1；每版內容記在 README「版本紀錄」
const VERSION = '0.19.17';
const VERSION_DATE = '2026-11-13';
// A 版 3D 地形在這台電腦整片透明、連關掉 3D 起伏也不行時，map-terrain.js 會換到 relief.html?auto=3d（設定頁最下面註明）
const AUTO_3D = new URLSearchParams(location.search).get('auto') === '3d';
// 視窗版啟動腳本（start-volcano-window）開的網址帶 ?win=1：記在這個分頁，切換 3D 與貼圖版後也記得；全螢幕展示機不會有
const WIN = (() => {
  const has = new URLSearchParams(location.search).has('win');
  try { if (has) sessionStorage.setItem('volcano-pulse.win', '1'); return !!sessionStorage.getItem('volcano-pulse.win'); } catch { return has; }
})();
// 問題回報的 Google 表單：在表單「取得預先填入的連結」裡，「系統資訊」那一題填 DIAG，複製的連結貼在這裡；空的就只顯示系統資訊
const REPORT_FORM = 'https://docs.google.com/forms/d/e/1FAIpQLScCVVqiIrtbVjQIn29doFHLgb7J771tjSon_uRTdntXq4q4iQ/viewform?usp=pp_url&entry.1283677282=DIAG';

// 固定標示的火山：大屯火山群（TVO 監測的火山），比照十年火山一直顯示圖釘與名稱
const HOME = new Set([281032]);
// 全球視角時和鄰近十年火山標籤重疊，拉近後才顯示
const QUIET = new Set([300090, 282100, 211020]);
// 區域快捷鍵：中心點、globe.gl 高度、MapLibre 縮放層級
export const REGIONS = [
  { key: 'world', label: '全球', lat: 15, lon: 150, alt: 2.4, zoom: 1.4 },
  { key: 'ea', label: '東亞', lat: 42, lon: 145, alt: 0.55, zoom: 3.5 },
  { key: 'sea', label: '東南亞', lat: 4, lon: 117, alt: 0.6, zoom: 3.5 },
  { key: 'oc', label: '大洋洲', lat: -20, lon: 168, alt: 0.65, zoom: 3.3 },
  { key: 'na', label: '北美', lat: 45, lon: -150, alt: 0.8, zoom: 2.8 },
  { key: 'la', label: '中南美', lat: -5, lon: -80, alt: 0.85, zoom: 2.8 },
  { key: 'eu', label: '歐洲・非洲', lat: 25, lon: 15, alt: 0.9, zoom: 2.6 },
];
// 顏色代表來源（紅 官方警戒、橘官方週報與火山灰警報、紫網路來源）；噴發另用噴煙圖示＋脈動光環，噴發中是紅底白煙
// 狀態顏色（v0.19.6 起，每一類一種顏色，跟概況清單的區塊同一套）：噴發紅、7 天內噴發琥珀、警戒紫、官方週報青綠、資料來源石板灰。
// 地圖圖示用深一階的色調，放在白底的圖釘上也夠清楚；其他火山用岩褐
const COL = { erupt_now: '#C92A2A', alert: '#6250D6', erupt_yday: '#D63B3A', erupt_off: '#C98500', erupt_unv: '#64748B', weekly: '#14996A', claude: '#64748B', none: '#8A6A50' };
const ORDER = ['erupt_now', 'alert', 'erupt_yday', 'erupt_off', 'erupt_unv', 'weekly', 'claude', 'none'];
const ERUPT = new Set(['erupt_now', 'erupt_yday', 'erupt_off', 'erupt_unv']);
const ST = {
  erupt_now: { short: '噴發中', long: '噴發中（連續 2 天以上）', bg: '#C92A2A', fg: '#FFFFFF' },
  alert: { short: '警戒升高', long: '警戒升高（官方警戒等級）', bg: '#F3F1FD', fg: '#4B3BB0' },
  erupt_yday: { short: '昨天噴發', long: '昨天噴發', bg: '#FFE3E3', fg: '#A51D1D' },
  erupt_off: { short: '7 天內噴發', long: '7 天內噴發', bg: '#FFF6DB', fg: '#6E4A00' },
  // 圖例（short）要跟官方的 7 天內噴發分開，所以寫來源；詳細卡的標籤（long）不寫
  erupt_unv: { short: '7 天內噴發（資料來源）', long: '7 天內噴發', bg: '#EEF1F5', fg: '#475569' },
  weekly: { short: '官方週報', long: '官方週報', bg: '#E6F7EF', fg: '#0B6E4B' },
  claude: { short: '資料來源', long: '資料來源', bg: '#EEF1F5', fg: '#475569' },
  none: { short: '近期無活動', long: '近期無活動紀錄', bg: '#F1F3F5', fg: '#4A515C' },
};
const AVC = { RED: ['#FFE3E3', '#9B1111', '#E03131'], ORANGE: ['#FFE8CC', '#8A3B00', '#F76707'],
  YELLOW: ['#FFF3BF', '#6B4F00', '#F2B705'], GREEN: ['#D3F9D8', '#1E6B2C', '#2F9E44'] };
const CAT = { '未經官方確認': '資料來源', 'New Eruptive Activity': '新噴發活動', 'Continuing Eruptive Activity': '持續噴發活動' };
const SRC = { hans: 'HANS', rss: '週報', claude: 'Claude' };
// 各國官方警戒等級的機構（levels.json 的 agency），各國等級制度不同，不能直接比較
const AGENCY = { JMA: '日本氣象廳', PHIVOLCS: '菲律賓 PHIVOLCS', GeoNet: '紐西蘭 GeoNet' };
const DIR = { N: '北', NNE: '北北東', NE: '東北', ENE: '東北東', E: '東', ESE: '東南東', SE: '東南', SSE: '南南東',
  S: '南', SSW: '南南西', SW: '西南', WSW: '西南西', W: '西', WNW: '西北西', NW: '西北', NNW: '北北西' };
// 灰雲高度：SIGMET 用英呎，換成公尺取到百位
const ashM = (ft) => `約 ${(Math.round(ft * 0.3048 / 100) * 100).toLocaleString('en-US')} 公尺`;
// 劇烈噴發：灰雲海拔 9 公里以上（民航機巡航高度），或比山頂高出 3 公里以上；本日關注與 30 天活動圖共用
const isBigAsh = (ft, elev) => ft * 0.3048 >= 9000 || (elev != null && ft * 0.3048 - elev >= 3000);
const ashTop = (ft) => (ft ? `${ashM(ft)}（${ft.toLocaleString('en-US')} ft）` : '高度未提供');
const DEC_ICO = '<svg width="15" height="15" viewBox="0 0 14 14" aria-hidden="true"><polygon points="7,1.6 12.8,11.8 1.2,11.8" fill="currentColor"/></svg>';

// 資料包三層讀取：線上資料包（config.json 的 bundle_url）、本機快取（上次抓到的線上資料包）、安裝時附的 data/，取資料時間最新的一份
const CACHE_KEY = 'volcano-pulse.bundle';
const FROM = { remote: '線上資料包', cache: '本機快取（上次抓到的線上資料包）', local: '安裝時附的 data/' };
// 對照檔（名稱對照 names.json、十年火山 decade.json、中文簡介 intro.json）：放在資料包旁邊，可以直接在 GitHub 網頁編輯，不用等每日發布。
// 讀取順序：線上、本機快取、安裝時附的 data/，取第一份格式正確的
const sideFrom = (f, k) => ({ remote: `線上 ${f}`, cache: `本機快取（上次抓到的線上 ${f}）`, local: `安裝時附的 data/${f}`, none: '沒有' }[k]);
async function loadData() {
  const json = (u, o) => fetch(u, o).then((r) => (r.ok ? r.json() : null)).catch(() => null);
  const get = (n, fb) => json(`data/${n}`, { cache: 'no-store' }).then((x) => x ?? fb);
  const online = (u) => json(u, { cache: 'no-cache', signal: AbortSignal.timeout(8000) });
  const confP = json('config.json', { cache: 'no-store' });
  const remoteP = confP.then((c) => (c?.bundle_url ? online(c.bundle_url).then((b) => ({ b })) : null));
  const sideP = (f) => confP.then((c) => (c?.bundle_url ? online(new URL(f, new URL(c.bundle_url, location.href)).href).then((x) => ({ x })) : null));
  const [volcanoes, alerts, activity, meta, media, ash, levels, obs, daily, localNames, localDecade, localIntro, rem, remNames, remDecade, remIntro] = await Promise.all([
    get('volcanoes.json', []), get('alerts.json', []), get('activity.json', []), get('meta.json', {}), get('media.json', {}),
    get('ash.json', []), get('levels.json', []), get('obs.json', []), get('daily.json', []),
    get('names.json', null), get('decade.json', null), get('intro.json', null),
    remoteP, sideP('names.json'), sideP('decade.json'), sideP('intro.json')]);
  // schema 不是 1 的資料包是不相容的新格式，忽略
  const ok = (b) => b?.schema === 1 && b.volcanoes?.length > 0 && Array.isArray(b.alerts) && Array.isArray(b.activity) && !!b.meta;
  const r = ok(rem?.b) ? rem.b : null;
  let cached = null;
  try { cached = JSON.parse(localStorage.getItem(CACHE_KEY) || 'null'); } catch { /* 私密視窗等情況讀不到 */ }
  if (r) try { localStorage.setItem(CACHE_KEY, JSON.stringify(r)); } catch { /* 存不了就只在這次有效 */ }
  const t = (b) => b.meta.updated_utc || '';
  // 時間相同時依線上、快取、本機的順序
  const [b, from] = [[r, 'remote'], [ok(cached) ? cached : null, 'cache'], [{ volcanoes, alerts, activity, meta, media, ash, levels, obs, daily }, 'local']]
    .filter(([x]) => x).reduce((best, c) => (t(c[0]) > t(best[0]) ? c : best));
  const side = (got, key, local) => {
    const okv = (x) => (x && typeof x.volcanoes === 'object' && !Array.isArray(x.volcanoes) ? x : null);
    const rv = okv(got?.x);
    let cv = null;
    try { cv = okv(JSON.parse(localStorage.getItem(key) || 'null')); } catch { /* 讀不到就略過 */ }
    if (rv) try { localStorage.setItem(key, JSON.stringify(rv)); } catch { /* 存不了就只在這次有效 */ }
    const [data, from] = rv ? [rv, 'remote'] : cv ? [cv, 'cache'] : okv(local) ? [local, 'local'] : [null, 'none'];
    return { data, from, remote: !got ? 'none' : rv ? 'ok' : 'fail' };
  };
  // 火山灰警報與各國警戒等級是 v0.19 加的、每日動態是 v0.19.6 加的，舊的資料包沒有這些欄位。
  // 資料包的 ash 只有最近 7 天（給舊版展示端），30 天在 ash30；本機 data/ash.json 本身就是 30 天
  const arr = (x) => (Array.isArray(x) ? x.filter((r) => Number.isInteger(r?.vnum)) : []);
  return { V: b.volcanoes, alerts: b.alerts, activity: b.activity, meta: b.meta, media: b.media || {}, ash: arr(b.ash30 ?? b.ash), levels: arr(b.levels), obs: arr(b.obs), daily: arr(b.daily), from,
    remote: !rem ? 'none' : r ? 'ok' : 'fail',
    names: side(remNames, 'volcano-pulse.names', localNames), decade: side(remDecade, 'volcano-pulse.decade', localDecade),
    intro: side(remIntro, 'volcano-pulse.intro', localIntro) };
}
// AWS Terrain Tiles 規定的出處（tilezen/joerd docs/attribution.md）
const TERRAIN_CREDITS = [
  'ArcticDEM terrain data DEM(s) were created from DigitalGlobe, Inc., imagery and funded under National Science Foundation awards 1043681, 1559691, and 1542736',
  'Australia terrain data © Commonwealth of Australia (Geoscience Australia) 2017',
  'Austria terrain data © offene Daten Österreichs – Digitales Geländemodell (DGM) Österreich',
  'Canada terrain data contains information licensed under the Open Government Licence – Canada',
  'Europe terrain data produced using Copernicus data and information funded by the European Union - EU-DEM layers',
  'Global ETOPO1 terrain data U.S. National Oceanic and Atmospheric Administration',
  'Mexico terrain data source: INEGI, Continental relief, 2016',
  'New Zealand terrain data Copyright 2011 Crown copyright (c) Land Information New Zealand and the New Zealand Government (All rights reserved)',
  'Norway terrain data © Kartverket',
  'United Kingdom terrain data © Environment Agency copyright and/or database right 2015. All rights reserved',
  'United States 3DEP (formerly NED) and global GMTED2010 and SRTM terrain data courtesy of the U.S. Geological Survey',
];

export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
// 列表用的名稱：英文名後面接中文名
const nm = (v) => esc(v.name) + (v.zh ? ` <span class="zh">${esc(v.zh)}</span>` : '');
const $ = (s) => document.querySelector(s);
// 外部連結：展示機不開出去，點了在畫面裡顯示 QR code（openExt），所以標 QR code 小圖示，不用「↗」
const QR_ICO = '<svg class="qr-ico" width="13" height="13" viewBox="0 0 13 13" aria-hidden="true"><path d="M1 1h4v4H1zM8 1h4v4H8zM1 8h4v4H1z" fill="none" stroke="currentColor" stroke-width="1.3"/><path d="M2.5 2.5h1v1h-1zM9.5 2.5h1v1h-1zM2.5 9.5h1v1h-1zM8 8h2v2H8zM10 10h2v2h-2z" fill="currentColor"/></svg>';
const link = (url, text) => (/^https?:\/\//.test(url || '') ? `<a class="ext" href="${esc(url)}" target="_blank" rel="noopener" title="顯示 QR code，用手機看原文">${text.replace(/\s*↗/, '')}${QR_ICO}</a>` : '');
const daysAgo = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
const md = (d) => d.slice(5, 10).replace('-', '/');
// 列表裡的日期：小日曆（上面月份、下面日），日期是 UTC
const dchip = (d) => `<span class="dchip num" title="${d}（UTC）"><i>${+d.slice(5, 7)} 月</i><b>${d.slice(8, 10)}</b></span>`;
const utc = (s) => (s ? s.slice(0, 16).replace('T', ' ') + ' UTC' : '無');
const fmtN = (n) => n.toLocaleString('en-US');

// 噴煙圖示：三團煙加火山錐；line 是火山錐的外框屬性
const smoke = (c, line = '') => `<circle cx="5" cy="4.6" r="2" fill="${c}" fill-opacity=".55"/><circle cx="7.6" cy="3.1" r="2.4" fill="${c}" fill-opacity=".55"/><circle cx="10.2" cy="4.5" r="1.8" fill="${c}" fill-opacity=".55"/><path d="M1.6 13.2 L5.2 7.4 H8.8 L12.4 13.2 Z" fill="${c}"${line}/>`;
// 狀態圖示：彩色噴煙＝噴發，灰色小噴煙＝其他火山（白框讓它在深色海面上看得到），三角形＝十年火山；空心＝網路來源
export function ico(s, dec, size = 14, c = COL[s]) {
  const body = s === 'erupt_now' ? `<circle cx="7" cy="7" r="7" fill="${c}"/><g transform="translate(2.1 1.6) scale(.7)">${smoke('#FFFFFF')}</g>`
    : ERUPT.has(s) ? smoke(c)
    : dec
    ? `<polygon points="7,1.6 12.8,11.8 1.2,11.8" fill="${s === 'alert' || s === 'weekly' ? c : '#FFFFFF'}" stroke="#1F2328" stroke-width="1.2" stroke-linejoin="round"/>`
    : s === 'claude' ? `<circle cx="7" cy="7" r="4.2" fill="#FFFFFF" stroke="${c}" stroke-width="2"/>`
    : s === 'none' ? `<g transform="translate(2.1 2.1) scale(.7)">${smoke(c, ' stroke="#FFFFFF" stroke-width="1.4" stroke-linejoin="round" paint-order="stroke"')}</g>`
    : `<circle cx="7" cy="7" r="${s === 'alert' ? 5.6 : 4.8}" fill="${c}"/>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" class="ico" width="${size}" height="${size}" viewBox="0 0 14 14" aria-hidden="true">${body}</svg>`;
}

// 地圖上的圖釘（兩個引擎共用同一個 DOM 元素）
function pinEl(v, onSelect) {
  const el = document.createElement('div');
  // Koryaksky 與 Avachinsky 只差 0.1°，標籤永遠重疊：只在滑過或選取時顯示
  el.className = `pin s-${v.s}${v.dec ? ' dec' : ''}${HOME.has(v.vnum) ? ' home' : ''}${QUIET.has(v.vnum) ? ' quiet' : ''}${v.vnum === 300090 ? ' twin' : ''}`;
  el.dataset.v = v.vnum;
  el.title = `${v.name}${v.zh ? ` ${v.zh}` : ''}（${ST[v.s].short}）`;
  const pulse = ERUPT.has(v.s) ? '<span class="pulse"></span>' : '';
  el.innerHTML = `<div class="pin-in"><div class="pin-stem"></div><div class="pin-head">${pulse}${ico(v.s, !!v.dec, 12)}</div></div><div class="pin-label">${esc(v.dec || v.name)}${v.zh ? ` ${esc(v.zh)}` : ''}</div>`;
  el.addEventListener('click', (e) => { e.stopPropagation(); onSelect(v.vnum); });
  return el;
}

// 拉近時其他火山只顯示名稱：名稱提到火山上方，用細線連到火山位置的小圓點，不擋住山體（元素的底部對齊火山位置）
function nameEl(v, onSelect) {
  const d = document.createElement('button');
  d.type = 'button';
  d.className = 'vname';
  d.innerHTML = '<span></span><i></i><b></b>';
  d.firstChild.textContent = v.zh ? `${v.name} ${v.zh}` : v.name;
  d.addEventListener('click', (e) => { e.stopPropagation(); onSelect(v.vnum); });
  return d;
}

export async function start(createMap, cfg) {
  document.body.innerHTML = `
<div class="app">
  <header class="top">
    <div class="brand">
      <svg width="34" height="34" viewBox="0 0 34 34" aria-hidden="true"><rect width="34" height="34" rx="9" fill="#14171C"/><path d="M7 25 L14 12.5 H20 L27 25 Z" fill="none" stroke="#FFFFFF" stroke-width="1.8" stroke-linejoin="round"/><circle cx="17" cy="8" r="2" fill="#E8590C"/></svg>
      <div><div class="brand-t"><b>全球火山活動</b><span class="today" id="today"></span></div><span class="muted" id="sub" style="display:block"></span></div>
    </div>
    <div class="spacer"></div>
    <nav class="switch" aria-label="地圖版本">
      <a href="index.html"${cfg.variant === 'terrain' ? ' aria-current="page"' : ''}>3D 地形</a>
      <a href="relief.html"${cfg.variant === 'relief' ? ' aria-current="page"' : ''}>地形貼圖</a>
    </nav>
    <button class="fresh" id="fresh" type="button"></button>
    <button class="refresh" id="refresh" type="button" aria-label="立即檢查新資料" title="立即檢查新資料"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M23 4 V10 H17"/><path d="M20.5 15 A9 9 0 1 1 18.4 5.6 L23 10"/></svg></button>
    <button class="hbtn" id="help" type="button" aria-haspopup="dialog"><b aria-hidden="true">?</b>使用說明</button>
    ${WIN ? '<button class="hbtn" id="full" type="button">全螢幕</button><button class="hbtn" id="quit" type="button" aria-haspopup="dialog">離開</button>' : ''}
    <img class="tvo" src="img/logot_TVO.png" alt="大屯火山觀測站 TVO" width="146" height="32">
  </header>
  <div class="body">
    <main class="mapcol">
      <div class="toolbar"><span id="regions" style="display:contents"></span>
        <span class="spacer"></span><span class="muted" id="hint"></span></div>
      <div class="mapbox" id="mapbox">
        <div id="map"></div>
        <div class="ctrl" id="ctrl"></div>
        <div class="palmenu" id="palmenu" role="menu" aria-label="地形配色" hidden></div>
        <div class="palmenu idlemenu" id="idlemenu" role="menu" aria-label="待機模式" hidden></div>
        <div class="palmenu geomenu" id="geomenu" role="menu" aria-label="圖層與教學" hidden></div>
        <div class="palmenu teachmenu" id="teachmenu" role="menu" aria-label="教學火山" hidden></div>
        <div class="setp" id="setp" hidden></div>
        <div class="setp" id="helpp" hidden></div>
        <div class="setp" id="quitp" hidden><div class="setp-box quit-box" role="alertdialog" aria-modal="true" aria-labelledby="quit-title" aria-describedby="quit-msg">
          <div class="setp-head"><div><h2 id="quit-title">關閉火山脈動？</h2></div></div>
          <p class="quit-msg" id="quit-msg">會關掉這個視窗和本機伺服器。要再看時，重新執行 start-volcano-window。</p>
          <div class="quit-act"><button type="button" class="hbtn" data-quit="no">取消</button><button type="button" class="ext-back" data-quit="yes">關閉</button></div></div></div>
        <div class="legend" id="legend"></div>
        <section class="card" id="card" hidden aria-label="火山詳細資訊"></section>
        <div class="yt" id="yt" hidden><div class="yt-box" role="dialog" aria-modal="true" aria-labelledby="yt-title">
          <div class="yt-head"><div class="yt-meta"><b id="yt-title"></b><span class="muted" id="yt-ch"></span></div>
            <button class="close" type="button" id="yt-close" aria-label="關閉影片"><svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3 3 L11 11 M11 3 L3 11" stroke="#14171C" stroke-width="1.8" stroke-linecap="round"/></svg></button></div>
          <div class="yt-frame"><iframe id="yt-if" title="YouTube 直播" sandbox="allow-scripts allow-same-origin" allow="autoplay; encrypted-media; fullscreen 'none'; picture-in-picture 'none'" referrerpolicy="strict-origin-when-cross-origin"></iframe></div>
          <p class="muted" id="yt-note"></p></div></div>
        <div class="yt" id="ext" hidden><div class="yt-box ext-box" role="dialog" aria-modal="true" aria-labelledby="ext-title">
          <div class="yt-head"><div class="yt-meta"><b id="ext-title"></b><span class="muted" id="ext-host"></span></div>
            <button class="ext-back" type="button" id="ext-close">回到展示畫面</button></div>
          <div class="ext-body"><div class="ext-qr" id="ext-qr"></div>
            <div class="ext-txt"><p class="ext-lead" id="ext-lead"></p><p class="muted" id="ext-note"></p><p class="ext-url" id="ext-url"></p></div></div></div></div>
        <div class="msg" id="msg" hidden></div>
      </div>
    </main>
    <aside class="panel"><div class="panel-in">
      <div class="panel-top">
        <label class="search">
          <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><circle cx="7" cy="7" r="4.8" fill="none" stroke="#5A6170" stroke-width="1.6"/><path d="M10.6 10.6 L14 14" stroke="#5A6170" stroke-width="1.6" stroke-linecap="round"/></svg>
          <input id="q" type="search" placeholder="搜尋火山（中英文）或國家" aria-label="搜尋火山或國家">
        </label>
        <div class="tabs" id="tabs"></div>
      </div>
      <div class="panel-body" id="pbody"></div>
    </div></aside>
  </div>
  <footer class="foot" id="foot"></footer>
</div>`;
  // 視窗版切換 3D 與貼圖版不留瀏覽紀錄：分頁只有一筆紀錄時，瀏覽器才讓網頁自己關掉視窗（「離開」）。要在讀資料之前掛上，剛開就點也算
  if (WIN) $('.switch').addEventListener('click', (e) => {
    const a = e.target.closest('a');
    if (a) { e.preventDefault(); location.replace(a.href); }
  });

  const msg = (html) => { $('#msg').hidden = false; $('#msg').innerHTML = html; };
  const { V, alerts, activity, meta, media, ash: ash30, levels, obs, daily, from, remote, names, decade, intro } = await loadData();
  // ash.json 從 v0.19.6 起保留 30 天（詳細卡的活動圖用）；噴發判斷與卡片上的警報清單照舊只看最近 7 天
  const ash = ash30.filter((a) => a.to >= `${daysAgo(7)}T${new Date().toISOString().slice(11, 19)}Z`);
  // 教學模式的內容（專案裡的 teach.json，不放資料 repo，離線也能用）；讀不到或格式不對就不提供教學模式
  const TEACH = await fetch('teach.json', { cache: 'no-cache' }).then((r) => (r.ok ? r.json() : null))
    .then((t) => (Array.isArray(t?.types) && t.volcanoes && t.ring ? t : null)).catch(() => null);
  // 名稱對照（key 是 GVP 編號）：name 取代英文名、zh 接在後面。有問題的筆數列在「來源」分頁
  const NAME = {}, ZH = {}, namesWarn = [];
  const gvpName = new Map(V.map((v) => [String(v.vnum), v.name]));
  const str = (x) => (typeof x === 'string' && x.trim() && x.length <= 60 ? x.trim() : '');
  for (const [k, x] of Object.entries(names.data?.volcanoes || {})) {
    if (!gvpName.has(k)) { namesWarn.push(`${k}（編號不在 GVP 資料）`); continue; }
    if (!x || typeof x !== 'object' || !(str(x.name) || str(x.zh))) { namesWarn.push(`${k}（沒有 name 或 zh）`); continue; }
    if (x.gvp && x.gvp !== gvpName.get(k)) namesWarn.push(`${k}（GVP 原名是 ${gvpName.get(k)}，不是 ${x.gvp}）`);
    if (str(x.name)) NAME[k] = str(x.name);
    if (str(x.zh)) ZH[k] = str(x.zh);
  }
  // 十年火山（decade.json）：GVP 編號 → 地圖上的常駐標籤「GVP 名稱 (通稱)」；名稱對照改過英文名時改用那個名稱
  const DECADE = {}, decadeWarn = [];
  for (const [k, x] of Object.entries(decade.data?.volcanoes || {})) {
    if (!gvpName.has(k)) { decadeWarn.push(`${k}（編號不在 GVP 資料）`); continue; }
    if (x?.gvp && x.gvp !== gvpName.get(k)) decadeWarn.push(`${k}（GVP 原名是 ${gvpName.get(k)}，不是 ${x.gvp}）`);
    DECADE[k] = str(x?.label) || gvpName.get(k);
  }
  // 中文簡介（intro.json）：GVP 地質摘要整理的 2 到 3 句中文；checked 為 true 表示人工校對過
  const INTRO = {};
  for (const [k, x] of Object.entries(intro.data?.volcanoes || {})) {
    if (gvpName.has(k) && typeof x?.zh === 'string' && x.zh.trim()) INTRO[k] = { zh: x.zh.trim(), checked: x.checked === true };
  }
  // YouTube 直播清單：火山編號 → 最多 3 支；影片編號再檢查一次格式，才拿來組網址
  const LIVE = {};
  for (const [vn, list] of Object.entries(media.live || {})) LIVE[vn] = (Array.isArray(list) ? list : []).filter((x) => /^[\w-]{11}$/.test(x?.id));
  const liveBy = new Map(Object.values(LIVE).flat().map((x) => [x.id, x]));
  if (!V.length) {
    msg('讀不到 data/ 裡的資料。<br>請在專案資料夾執行 <code>python3 http_server.py</code>，再開 <a href="http://localhost:8000">http://localhost:8000</a>。<br>第一次使用請先執行 <code>python3 update.py</code>。');
    return;
  }

  // ---- 狀態判定 ----
  const alertBy = new Map(alerts.map((a) => [a.vnum, a]));
  // 其他國家的官方警戒等級（JMA、PHIVOLCS、GeoNet）：高於各機構的平常等級，跟 HANS 一樣算「警戒升高」
  const lvlBy = new Map(levels.map((l) => [l.vnum, l]));
  const elevated = new Set([...alertBy.keys(), ...levels.filter((l) => l.elevated).map((l) => l.vnum)]);
  // 航空火山灰警報（各國火山灰 SIGMET，ash.json 已依時間新到舊）：警報生效的那一天（UTC）算這座火山有噴發。
  // 不用效期結束日：一則跨過午夜的警報不算兩天；持續噴發的火山每天都會有新的警報
  const ashBy = new Map();
  ash.forEach((a) => (ashBy.get(a.vnum) || ashBy.set(a.vnum, []).get(a.vnum)).push(a));
  const ashRecs = [...ashBy].flatMap(([vnum, list]) => [...new Set(list.map((a) => a.from.slice(0, 10)))].map((date) => {
    const same = list.filter((a) => a.from.slice(0, 10) === date);
    return { vnum, date, source: 'ash', agency: [...new Set(same.map((a) => a.fir))].join('、'), top_ft: Math.max(0, ...same.map((a) => a.top_ft || 0)) || null };
  }));
  const weekEnd = meta.rss?.report_end || '';
  const weekly = activity.filter((r) => r.source === 'rss' && r.date === weekEnd);
  const weeklySet = new Set(weekly.map((r) => r.vnum));
  const claude = activity.filter((r) => r.source === 'claude' && r.date >= daysAgo(30)).sort((a, b) => b.date.localeCompare(a.date));
  const claudeSet = new Set(claude.map((r) => r.vnum));
  // 7 天內噴發：官方週報（類別都是 Eruptive Activity，日期為報告期間最後一天）、航空火山灰警報，或 Claude 判定為噴發的補充
  // 同一天先列官方的火山灰警報，再來週報、Claude。最近 7 天有火山灰警報的火山以官方為準，不用 Claude 的報導判斷噴發日
  // （同一次噴發常被隔天的報導再提一次，會被誤算成連續噴發）；墨西哥等 SIGMET 沒涵蓋到的火山照舊參考 Claude
  const RANK = { ash: 0, rss: 1, claude: 2 };
  const erupt7 = [...activity.filter((r) => r.date >= daysAgo(7)
    && ((r.source === 'rss' && /Eruptive/.test(r.title)) || (r.source === 'claude' && r.eruption === true && !ashBy.has(r.vnum)))),
  ...ashRecs.filter((r) => r.date >= daysAgo(7) && r.date <= daysAgo(0))]
    .sort((a, b) => b.date.localeCompare(a.date) || RANK[a.source] - RANK[b.source]);
  const eruptOff = new Set(erupt7.filter((r) => r.source !== 'claude').map((r) => r.vnum));
  // 7 天內噴發的發布單位（詳細卡色帶的第二行）：這座火山最新一筆官方紀錄。航空火山灰警報寫飛航情報區
  // （SIGMET 由負責該區的航空氣象單位發布，資料只有區名，例如 SKED BOGOTA → Bogota），週報寫 GVP 與 USGS
  const firName = (f) => f.split('、').map((x) => x.replace(/^[A-Z]{4}\s+/, '').toLowerCase().replace(/(^|[\s-])\S/g, (c) => c.toUpperCase())).join('、');
  const offSrc = (vn) => {
    const r = erupt7.find((x) => x.vnum === vn && x.source !== 'claude');
    return !r ? '' : r.source === 'ash' ? `${firName(r.agency)} 飛航情報區` : 'Smithsonian GVP 與 USGS 週報';  // 警報種類下面的標籤已經寫了
  };
  const eruptUnv = new Set(erupt7.filter((r) => r.source === 'claude').map((r) => r.vnum));
  // 昨天噴發：昨天（UTC）有火山灰警報或發布、判定為噴發的報導。週報是一週的彙整，看不出是哪一天，不列入
  const yday = daysAgo(1);
  const ydayRecs = erupt7.filter((r) => r.source !== 'rss' && r.date === yday);
  const eruptYday = new Set(ydayRecs.map((r) => r.vnum));
  // 噴發中：從今天（今天沒有就從昨天）往回數，連續有噴發的天數（UTC）2 天以上
  const eDays = new Map();
  erupt7.filter((r) => r.source !== 'rss').forEach((r) => (eDays.get(r.vnum) || eDays.set(r.vnum, new Set()).get(r.vnum)).add(r.date));
  const runDays = (vn) => {
    const s = eDays.get(vn);
    if (!s) return 0;
    let i = s.has(daysAgo(0)) ? 0 : 1, n = 0;
    while (s.has(daysAgo(i))) { n += 1; i += 1; }
    return n;
  };
  const eruptNow = new Set([...eDays.keys()].filter((vn) => runDays(vn) >= 2));
  // 資料只有最近 7 天，數到 7 天以上就不再細分
  const runTxt = (n) => (n >= 7 ? '7 天以上' : `${n} 天`);
  const actBy = new Map();
  [...activity].sort((a, b) => b.date.localeCompare(a.date)).forEach((r) => (actBy.get(r.vnum) || actBy.set(r.vnum, []).get(r.vnum)).push(r));
  const vols = V.map((v) => {
    const n = v.vnum;
    const s = eruptNow.has(n) ? 'erupt_now' : elevated.has(n) ? 'alert' : eruptYday.has(n) ? 'erupt_yday' : eruptOff.has(n) ? 'erupt_off' : eruptUnv.has(n) ? 'erupt_unv'
      : weeklySet.has(n) ? 'weekly' : claudeSet.has(n) ? 'claude' : 'none';
    const dec = DECADE[n] ? NAME[n] || DECADE[n] : '';
    return { ...v, name: NAME[n] || v.name, gvp: v.name, zh: ZH[n] || '', s, dec, pin: s !== 'none' || !!dec || HOME.has(n) };
  }).sort((a, b) => ORDER.indexOf(a.s) - ORDER.indexOf(b.s) || a.name.localeCompare(b.name));
  const byV = new Map(vols.map((v) => [v.vnum, v]));

  // ---- 詳細卡：近 30 天活動圖（v0.19.11 起分兩列）。灰雲高度＝航空火山灰警報的最高灰雲（深藍＝劇烈、淺藍＝一般，虛線＝山頂）；
  // 每日活動＝每日報告寫的最主要活動（火山灰噴發＞熔岩＞小規模噴煙＞其他），不再把有灰雲警報的日子也塗成火山灰；
  // 警戒帶＝官方警戒等級（USGS 依 HANS 變動紀錄，日本氣象廳依發布時間，其他機構從記錄到改變那天起）；黑色三角形＝有災害的日子。
  // 活動類型來自每日報告（V1，obs.json，meta.obs.since 起保存），之前的日子除了火山灰警報以外不知道，畫成斜線 ----
  const ACT_DAYS = [...Array(30)].map((_, i) => daysAgo(29 - i));
  const ACT_MIN_DAYS = 5, ACT_QUIET_DAYS = 10;  // 噴發 5 天以上才畫活動圖，超過 10 天沒噴發就不畫
  const OBS_SINCE = meta.obs?.since || '9999';
  const KIND = { ash: ['#495057', '火山灰噴發'], lava: ['#E8590C', '熔岩'], minor: ['#ADB5BD', '小規模噴煙'], other: ['#12B886', '其他活動或報導'] };  // 其他＝地震、變形、氣體增強（v0.19.13 起實心青綠，原本是空心框）
  const ASH_BIG = '#1864AB', ASH_MID = '#74C0FC';  // 灰雲柱：劇烈深藍、一般淺藍（跟活動列的灰、橘分開）
  const BANDC = { GREEN: '#2F9E44', YELLOW: '#FAB005', ORANGE: '#FD7E14', RED: '#E03131', L1: '#CED4DA', L2: '#FAB005', L3: '#FD7E14', L4: '#E03131', L5: '#862E9C' };
  const USGS_ZH = { GREEN: '綠色', YELLOW: '黃色', ORANGE: '橘色', RED: '紅色' };
  // 每天的灰雲、活動、噴發日、災害讀資料站算好的日統計（daily.json，v0.19.12 起；算法在 update.py 的 daily_rows）
  const dailyBy = new Map();
  for (const r of daily) (dailyBy.get(r.vnum) || dailyBy.set(r.vnum, new Map()).get(r.vnum)).set(r.date, r);
  function act30(vn) {
    const m = dailyBy.get(vn);
    return ACT_DAYS.map((d) => {
      const r = m?.get(d);
      return { d, n: r?.ash_n || 0, top: r?.ash_top_ft || 0, k: r?.kind || null, er: !!r?.eruption, hz: Array.isArray(r?.hazards) ? r.hazards : [] };
    });
  }
  function band30(vn) {
    const out = ACT_DAYS.map(() => null);
    const hans = activity.filter((r) => r.vnum === vn && r.source === 'hans').sort((a, b) => a.date.localeCompare(b.date));
    let cur = null, j = 0;
    if (hans.length) ACT_DAYS.forEach((d, i) => {
      for (; j < hans.length && hans[j].date <= d; j++) cur = /已不在/.test(hans[j].title) ? null : (hans[j].level || hans[j].title.split(/[：→]/).pop().trim()).split('/')[0];
      if (cur) out[i] = cur;
    });
    const l = lvlBy.get(vn), since = l && l.level != null && (l.agency === 'JMA' ? l.time : l.changed_utc);
    if (since) ACT_DAYS.forEach((d, i) => { if (d >= since.slice(0, 10)) out[i] = `L${l.level}`; });
    const name = (b) => (b[0] === 'L' ? `${AGENCY[l.agency] || l.agency} 等級 ${b.slice(1)}` : `USGS ${USGS_ZH[b] || b}`);
    return { days: out, name };
  }
  function act30HTML(v) {
    const days = act30(v.vnum), band = band30(v.vnum);
    const active = days.filter((x) => x.n || x.k).length, hzDays = days.filter((x) => x.hz.length).length;
    // 出現條件：30 天內噴發 ACT_MIN_DAYS 天以上（不必連續），而且最近 ACT_QUIET_DAYS 天內還有噴發；停了超過 ACT_QUIET_DAYS 天就不畫。
    // 最近 ACT_QUIET_DAYS 天有災害的火山就算噴發天數不夠也畫，災害標記才看得到
    const erDays = days.filter((x) => x.er), recent = daysAgo(ACT_QUIET_DAYS);
    const show = (erDays.length >= ACT_MIN_DAYS && erDays[erDays.length - 1].d >= recent) || days.some((x) => x.hz.length && x.d >= recent);
    if (!show) return '';
    const W = 320, L = 40, R = 4, pw = W - L - R, slot = pw / 30, bw = Math.min(7, slot - 3);
    const km = (ft) => ft * 0.3048 / 1000, el = v.elev ?? null, ek = el != null ? el / 1000 : 0;
    const hasAsh = days.some((x) => x.n), maxTop = Math.max(...days.map((x) => x.top));
    const maxKm = Math.max(3, Math.ceil(Math.max(km(maxTop), el != null ? ek + 0.4 : 0) / 3) * 3);
    const hasBand = band.days.some(Boolean), hatched = days.some((x) => !x.k && x.d < OBS_SINCE);
    let y = 0, g = '';
    // 每一列上方的標題：粗體名稱＋淡色的資料來源
    const head = (t, sub, sw) => {
      y += 13;
      const x = sw ? L + 12 : L;
      g += (sw ? `<rect x="${L}" y="${y - 9}" width="9" height="9" rx="2" fill="${sw}"/>` : '')
        + `<text class="h" x="${x}" y="${y}">${t}</text>${sub ? `<text x="${x}" y="${y}" dx="${t.length * 12 + 6}">${sub}</text>` : ''}`;
      y += 6;
    };
    head('灰雲高度', '航空火山灰警報・海拔', ASH_BIG);
    const T = y + 4, bh = hasAsh ? 70 : 0, y0 = T + bh;
    if (hasAsh) {
      for (const k of [0, maxKm]) { const yy = y0 - (k / maxKm) * bh; g += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}" stroke="#EEF0F3"/><text x="${L - 5}" y="${yy + 4}" text-anchor="end">${k ? `${k} 公里` : '0'}</text>`; }
      if (el != null) { const ys = y0 - (ek / maxKm) * bh; g += `<line x1="${L}" x2="${W - R}" y1="${ys}" y2="${ys}" stroke="#868E96" stroke-width="1.2" stroke-dasharray="4 3"/><text x="${W - R}" y="${ys - 3}" text-anchor="end" class="ink halo">山頂 ${el.toLocaleString('en-US')} m</text>`; }
      y = y0;
    } else { g += `<text x="${L}" y="${y + 8}">近 30 天沒有灰雲警報</text>`; y += 12; }
    y += 8;
    head('每日活動', '每日報告（Claude 整理）');
    const laneY = y + 2, laneH = 14;
    y = laneY + laneH;
    const tip = (x, i) => `${md(x.d)}：${[x.n ? `航空火山灰警報 ${x.n} 則，最高灰雲${ashM(x.top)}${el != null && x.top ? (km(x.top) > ek ? `（比山頂高約 ${(km(x.top) - ek).toFixed(1)} 公里）` : '（低於山頂，警報原文可能有誤）') : ''}${isBigAsh(x.top, el) ? '，劇烈' : ''}` : '',
      x.k ? `每日報告：${KIND[x.k][1]}` : '', x.hz.length ? `災害：${x.hz.join('；')}` : '', band.days[i] ? band.name(band.days[i]) : ''].filter(Boolean).join('・')
      || (x.d < OBS_SINCE ? '沒有火山灰警報；這天還沒有每日報告紀錄' : '沒有火山灰警報，每日報告也沒有寫到')}`;
    days.forEach((x, i) => {
      const cx = L + i * slot, bx = cx + (slot - bw) / 2;
      let m = `<rect x="${cx}" y="${T - 6}" width="${slot}" height="${laneY + laneH - T + 6}" fill="transparent"/>`;  // 點選範圍
      if (x.n && hasAsh) { const h = Math.max(4, (km(x.top) / maxKm) * bh), r = 3;
        m += `<path fill="${isBigAsh(x.top, el) ? ASH_BIG : ASH_MID}" d="M${bx},${y0} V${y0 - h + r} Q${bx},${y0 - h} ${bx + r},${y0 - h} H${bx + bw - r} Q${bx + bw},${y0 - h} ${bx + bw},${y0 - h + r} V${y0} Z"/>`; }
      const fill = x.k ? KIND[x.k][0] : x.d < OBS_SINCE ? 'url(#act-hatch)' : '#F1F3F5';
      m += `<rect x="${cx + 1}" y="${laneY}" width="${slot - 2}" height="${laneH}" rx="2.5" fill="${fill}"/>`;
      if (x.hz.length) m += `<path d="M${cx + slot / 2 - 4.5},${laneY - 9} H${cx + slot / 2 + 4.5} L${cx + slot / 2},${laneY - 2} Z" fill="#14171C"/>`;
      g += `<g data-tip="${esc(tip(x, i))}">${m}</g>`;
    });
    if (hasBand) {
      y += 10;
      head('官方警戒', '');
      const bandY = y;
      for (let i0 = 0, i = 1; i <= 30; i++) {
        if (i < 30 && band.days[i] === band.days[i0]) continue;
        const b = band.days[i0], x = L + i0 * slot + 1, w = (i - i0) * slot - 2;
        // 夠寬的段落在中間寫等級；最後一段（目前的等級）不夠寬也寫，靠右對齊
        const lbl = b && (w > 64 ? `<text x="${x + w / 2}" y="${bandY + 18}" text-anchor="middle" class="ink">${esc(band.name(b))}</text>`
          : i === 30 ? `<text x="${x + w}" y="${bandY + 18}" text-anchor="end" class="ink">目前 ${esc(band.name(b))}</text>` : '');
        if (b) g += `<rect x="${x}" y="${bandY}" width="${w}" height="5" rx="2.5" fill="${BANDC[b] || '#868E96'}"/>${lbl}`;
        i0 = i;
      }
      y = bandY + 22;
    }
    y += 16;
    g += `<text x="${L}" y="${y}">${md(ACT_DAYS[0])}</text><text x="${L + 15 * slot + slot / 2}" y="${y}" text-anchor="middle">${md(ACT_DAYS[15])}</text><text x="${W - R}" y="${y}" text-anchor="end">今天</text>`;
    const H = y + 4;
    const cnt = (k) => days.filter((x) => x.k === k).length, ashDays = days.filter((x) => x.n).length, bigDays = days.filter((x) => x.n && isBigAsh(x.top, el)).length;
    const sum = [ashDays ? `灰雲警報 <b>${ashDays}</b> 天` : '', maxTop ? `最高灰雲${ashM(maxTop)}` : '', bigDays ? `劇烈 <b>${bigDays}</b> 天` : '']
      .concat(['ash', 'lava', 'minor', 'other'].filter((k) => cnt(k)).map((k) => `${k === 'other' ? '其他活動' : KIND[k][1]} <b>${cnt(k)}</b> 天`), hzDays ? [`<b class="hz">▲ 災害 ${hzDays} 天</b>`] : []).filter(Boolean).join('・');
    const typ = ['ash', 'minor', 'lava', 'other'].filter((k) => cnt(k)).map((k) => `<span><i style="background:${KIND[k][0]}"></i>${KIND[k][1]}</span>`).join('');
    const leg = (hasAsh ? `<span class="lg-h">灰雲</span><span><i style="background:${ASH_BIG}"></i>劇烈</span><span><i style="background:${ASH_MID}"></i>一般</span>${el != null ? '<span><i class="dash"></i>山頂</span>' : ''}<i class="br"></i>` : '')
      + `<span class="lg-h">活動</span>${typ || '<span>還沒有報告寫到活動類型</span>'}${hatched ? '<span><i class="hatch"></i>還沒有紀錄</span>' : ''}${hzDays ? '<span>▲ 災害</span>' : ''}`;
    return `<div class="act30"><h3>近 30 天活動</h3><p class="act-sum">${sum}</p>
      <svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="近 30 天活動：${active} 天有紀錄">
        <defs><pattern id="act-hatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(45)"><rect width="5" height="5" fill="#F8F9FA"/><line x1="0" y1="0" x2="0" y2="5" stroke="#DEE2E6" stroke-width="2"/></pattern></defs>${g}</svg>
      <p class="act-cap">點圖上的某一天看當天的紀錄</p><div class="act-leg">${leg}</div>
      <p class="act-src">資料：灰雲高度＝NOAA 航空氣象中心彙整的航空火山灰警報（SIGMET），深藍＝劇烈（灰雲海拔 9 公里以上，或比山頂高出 3 公里以上，跟本日關注同一標準）；每日活動＝每日報告（Claude 整理觀測站公告，未經官方確認${OBS_SINCE < '9999' ? `，${md(OBS_SINCE)} 起保存` : ''}）；警戒＝USGS、各國觀測機構</p></div>`;
  }

  // ---- 本日關注火山：昨天與今天（UTC）有特別值得注意的事。一座火山放在最優先的理由那一組，其他理由當小標籤 ----
  const WATCH = [
    ['hazard', '火山災害', '火山造成人員傷亡、撤離、火山泥流、落灰影響生活、航班或設施受影響'],
    ['raise', '警戒提升', '官方 3 天內調高警戒等級'],
    ['big', '劇烈噴發', '灰雲衝到 9 公里以上（民航機巡航高度），或比山頂高出 3 公里以上'],
    ['new', '新噴發', '前 30 天沒有噴發紀錄後又噴發，或 GVP 週報列為新噴發活動'],
    ['news', '全球重大報導', '每日報告列為全球重大：新噴發、警戒變動、撤離或影響航空'],
    ['media', '媒體報導', '國際或各國重要媒體（通訊社、全國性報紙與電視台）有報導'],
    ['near', '鄰近台灣', '台灣、日本、菲律賓等鄰近島弧有新消息'],
  ];
  const watch = new Map(), outlet = new Map();  // vnum → { 理由: 說明 }；vnum → 報導的媒體名稱
  const addW = (vn, k, why) => { if (byV.has(vn)) { const w = watch.get(vn) || watch.set(vn, {}).get(vn); w[k] ||= why; } };
  const AVC_RANK = { GREEN: 0, YELLOW: 1, ORANGE: 2, RED: 3 };
  const firstSentence = (t) => { const x = t.split(/(?<=[。！？])/)[0]; return x.length > 70 ? `${x.slice(0, 68)}…` : x; };
  // 警戒提升：各國等級的改變紀錄（update.py 記下前一級）、HANS 的變動紀錄、每日報告寫到的調升
  for (const l of levels) {
    if (l.changed_utc >= daysAgo(3) && l.level != null && l.prev_level != null && l.level > l.prev_level) {
      addW(l.vnum, 'raise', `${AGENCY[l.agency] || l.agency} 從等級 ${l.prev_level} 調高到 ${l.level}（${l.label.split('：').pop()}）`);
    }
  }
  for (const r of activity) {
    if (r.source !== 'hans' || r.date < daysAgo(3) || !r.level) continue;
    const up = !r.prev || AVC_RANK[r.level.split('/')[0]] > AVC_RANK[r.prev.split('/')[0]];
    if (up) addW(r.vnum, 'raise', `USGS ${r.prev ? `從 ${r.prev} ` : ''}調高到 ${r.level}`);
  }
  // 每日報告（V1 的 obs.json）：災害、寫到的警戒調升；新聞看發布日（pub），災害看活動日或發布日
  for (const n of obs) {
    if (n.hazards.length && (n.date >= yday || n.pub >= yday)) addW(n.vnum, 'hazard', `${n.hazards.join('、')}${n.hazard_note ? `：${n.hazard_note}` : ''}（${md(n.date)}）`);
    if (n.pub >= yday && /調高|調升|提高|提升|升至|升為|上調|raised/i.test(n.alert_change)) addW(n.vnum, 'raise', firstSentence(n.alert_change));
  }
  // 劇烈噴發：昨天與今天的火山灰警報裡最高的灰雲
  const bigAsh = new Map();
  for (const a of ash) if (a.from.slice(0, 10) >= yday && a.top_ft && a.top_ft > (bigAsh.get(a.vnum)?.top_ft || 0)) bigAsh.set(a.vnum, a);
  for (const [vn, a] of bigAsh) {
    const m = a.top_ft * 0.3048, el = byV.get(vn)?.elev, over = el != null ? m - el : null;
    if (isBigAsh(a.top_ft, el)) addW(vn, 'big', `灰雲衝到${ashM(a.top_ft)}${over != null ? `，比山頂高約 ${(over / 1000).toFixed(1)} 公里` : ''}（${md(a.from)}）`);
  }
  // 新噴發：GVP 週報的新噴發（一週內的那一期），或昨天、今天噴發而前 30 天都沒有噴發紀錄
  if (weekEnd >= daysAgo(7)) for (const r of weekly) if (/^New/.test(r.title)) addW(r.vnum, 'new', `GVP 週報列為新噴發活動（${r.period_start ? `${md(r.period_start)}～` : ''}${md(r.date)}）`);
  const erDays = new Map();
  const addD = (vn, d) => (erDays.get(vn) || erDays.set(vn, new Set()).get(vn)).add(d);
  ash30.forEach((a) => addD(a.vnum, a.from.slice(0, 10)));
  activity.forEach((r) => { if (r.eruption === true || (r.source === 'rss' && /Eruptive/.test(r.title))) addD(r.vnum, r.date); });
  for (const r of erupt7) {
    if (r.source === 'rss' || r.date < yday) continue;
    const before = [...(erDays.get(r.vnum) || [])].some((d) => d >= daysAgo(31) && d < yday);
    if (!before) addW(r.vnum, 'new', `前 30 天沒有噴發紀錄，${md(r.date)} 再度噴發`);
  }
  // 全球重大報導、媒體報導、鄰近台灣：每日報告（V1）的分區；媒體區只搜重要媒體，跟其他區可以是同一座火山
  for (const n of obs) {
    if (n.pub < yday || n.section === 'other') continue;
    const k = n.section === 'global' ? 'news' : n.section === 'media' ? 'media' : 'near';
    addW(n.vnum, k, `${firstSentence(n.summary)}${n.agency ? `（${n.agency}）` : ''}`);
    if (k === 'media' && n.agency && !outlet.has(n.vnum)) outlet.set(n.vnum, n.agency);
  }
  const stale = weekEnd ? Math.floor((Date.now() - Date.parse(weekEnd)) / 864e5) : 0;
  // open：概況裡展開的區塊，預設只展開本日關注（最新噴發活動 v0.19.10 起預設收起）；只記在這次載入，重新整理就回到預設
  const S = { tab: 'overview', q: '', filt: 'active', country: '', win: 30, sel: null, allClaude: false, limit: 150, region: 'world', open: new Set(['watch']) };

  // ---- 地圖 ----
  let api;
  try {
    api = await createMap($('#map'), {
      pins: vols.filter((v) => v.pin),
      dots: vols.filter((v) => !v.pin),
      dotIcon: ico('none', false, 32),  // 其他火山的地圖圖示
      makePin: (v) => pinEl(v, select),
      makeName: (v) => nameEl(v, select),
      onSelect: select,
      onFar: (far) => $('#mapbox').classList.toggle('far', far),
      onNear: (near) => $('#mapbox').classList.toggle('near', near),  // 拉近時只顯示火山名稱
      onUserMove: () => { if (S.region) { S.region = ''; renderRegions(); } },
      onFlat: () => renderLegend(),  // A 版 3D 地形貼不上去、自動關掉 3D 起伏時，圖例的說明跟著改
    });
  } catch (e) {
    console.error(e);
    msg(`地圖無法啟動：${esc(e.message)}<br>請確認瀏覽器支援 WebGL。`);
    api = null;
  }

  // 自轉速度（幾分鐘一圈）與鏡頭飛行時間（飛向、飛回火山幾秒）：設定頁可以改，瀏覽器會記住；超出範圍的值不用
  const MOTION_KEY = 'volcano-pulse.motion';
  // 拉近程度：點火山時飛到區域尺度、火山全景，或看得到火山錐的近景；是縮放級數（數字越大越近），B 版換算成同樣的範圍
  // 衛星影像兩版都有；高解析地形只有 A 版、連網時才有（z13 以上，部分地區有方塊色差，預設關）
  const MOTION_DEF = { spinMin: 4, flySec: 3, near: 12.5, sat: true, hidem: false };
  const MOTION_RANGE = { spinMin: [1, 30], flySec: [0.5, 10], near: [6, 14] };
  const NEAR_OPTS = [[6.5, '區域'], [10.5, '火山全景'], [12.5, '近景'], [13.5, '特寫']];
  const okMotion = (k, v) => (k === 'sat' || k === 'hidem' ? typeof v === 'boolean'
    : Number.isFinite(v) && v >= MOTION_RANGE[k][0] && v <= MOTION_RANGE[k][1]);
  const motion = { ...MOTION_DEF };
  try {
    const m = JSON.parse(localStorage.getItem(MOTION_KEY) || '{}');
    for (const k of Object.keys(MOTION_DEF)) if (okMotion(k, m[k])) motion[k] = m[k];
  } catch { /* 讀不到就用預設 */ }
  api?.motion?.(motion);

  // 圖層與教學模式：地圖左上的「圖層」選單（設定頁也有），瀏覽器會記住，預設都關。打開教學模式會一起打開板塊邊界
  const LAYER_KEY = 'volcano-pulse.layers';
  const LAYERS = [['plates', '板塊邊界'], ['quakes', '地震分布'], ['borders', '國界與國名'], ['teach', '教學模式']];
  const LAYER_DEF = { plates: false, quakes: false, borders: false, teach: false };
  const lay = { ...LAYER_DEF };
  try {
    const m = JSON.parse(localStorage.getItem(LAYER_KEY) || '{}');
    for (const [k] of LAYERS) if (typeof m[k] === 'boolean') lay[k] = m[k];
  } catch { /* 讀不到就用預設 */ }
  if (!TEACH) lay.teach = false;
  let teachPin = false;  // 教學火山選單要不要顯示（見「教學火山選單」）
  const saveLay = () => { try { localStorage.setItem(LAYER_KEY, JSON.stringify(lay)); } catch { /* 存不了就只在這次有效 */ } };
  const layerList = () => LAYERS.filter(([k]) => (k === 'teach' ? !!TEACH : !!api?.geo));
  let geoFail = false;
  async function setLayer(k, on) {
    lay[k] = on;
    saveLay();
    if (k === 'teach') {
      if (on && !lay.plates) await setLayer('plates', true);
      if (!on && S.tab === 'teach') S.tab = 'overview';
      // 打開教學模式時跳出教學火山選單；等這次點選處理完再開，不然會被其他選單「點外面就關」的處理收掉
      if (on) setTimeout(() => toggleTeach(true));
      else toggleTeach(false);
      renderTabs();
      renderPanel();
      if (S.sel != null && !$('#card').hidden) renderCard(byV.get(S.sel));
    } else if (api?.geo && !(await api.geo(k, on))) {
      lay[k] = false;  // vendor/geo/ 讀不到（例如更新包沒帶到）
      geoFail = true;
      saveLay();
    }
    renderLegend();
    if (!$('#geomenu').hidden) renderGeo();
  }

  const ICONS = {
    plus: '<path d="M8 3 V13 M3 8 H13"/>', minus: '<path d="M3 8 H13"/>',
    tilt: '<path d="M2 12 L8 4 L14 12 Z"/><path d="M5 12 L8 8 L11 12"/>',
    north: '<path d="M8 2 L11.5 13 L8 10.5 L4.5 13 Z"/>',
    layers: '<path d="M8 2.5 L14 6 L8 9.5 L2 6 Z"/><path d="M2 9.5 L8 13 L14 9.5"/>',
    clock: '<circle cx="8" cy="8" r="5.8"/><path d="M8 4.6 V8 L10.4 9.6"/>',
    globe: '<circle cx="8" cy="8" r="5.8"/><path d="M2.2 8 H13.8"/><path d="M8 2.2 C5.6 4.6 5.6 11.4 8 13.8 C10.4 11.4 10.4 4.6 8 2.2"/>',
    gear: '<circle cx="8" cy="8" r="4.3"/><circle cx="8" cy="8" r="5.6" stroke-width="2.4" stroke-dasharray="2.2 2.2"/><circle cx="8" cy="8" r="1.7"/>',
  };
  const svgI = (k) => `<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true" fill="none" stroke="#14171C" stroke-width="1.6" stroke-linejoin="round" stroke-linecap="round">${ICONS[k]}</svg>`;
  if (api) {
    $('#ctrl').innerHTML = `<button type="button" data-act="in" aria-label="放大">${svgI('plus')}</button><button type="button" data-act="out" aria-label="縮小">${svgI('minus')}</button>`
      + (api.tilt ? `<button type="button" data-act="tilt" aria-label="傾斜視角" aria-pressed="false">${svgI('tilt')}</button><button type="button" data-act="north" aria-label="回到正北、俯視">${svgI('north')}</button>` : '')
      + `<button type="button" data-act="idle" aria-label="待機模式" title="待機模式" aria-haspopup="menu" aria-expanded="false">${svgI('clock')}</button>`
      + (api.palettes ? `<button type="button" data-act="pal" aria-label="地形配色" aria-haspopup="menu" aria-expanded="false">${svgI('layers')}</button>` : '')
      + (layerList().length ? `<button type="button" data-act="geo" aria-label="圖層與教學" title="圖層與教學" aria-haspopup="menu" aria-expanded="false">${svgI('globe')}</button>` : '')
      + `<button type="button" data-act="set" aria-label="設定" title="設定" aria-haspopup="dialog">${svgI('gear')}</button>`;
    $('#ctrl').addEventListener('click', (e) => {
      const b = e.target.closest('button');
      if (!b) return;
      const act = b.dataset.act;
      if (act === 'in' || act === 'out') api.zoomBy(act === 'in' ? 1 : -1);
      if (act === 'tilt') b.setAttribute('aria-pressed', String(api.tilt()));
      if (act === 'north') { api.north(); $('[data-act="tilt"]').setAttribute('aria-pressed', 'false'); }
      if (act === 'pal') togglePal($('#palmenu').hidden);
      if (act === 'idle') toggleIdle($('#idlemenu').hidden);
      if (act === 'geo') toggleGeo($('#geomenu').hidden);
      if (act === 'set') toggleSet(true);
    });
    $('#hint').textContent = api.hint;
  }

  // ---- 地形配色（只有 A 版提供）----
  function renderPal() {
    $('#palmenu').innerHTML = '<div class="palmenu-h">地形配色</div>' + api.palettes.map((p) => `<button type="button" role="menuitemradio" aria-checked="${p.key === api.palette}" data-pal="${p.key}">
      <span class="sw">${p.swatch.map((c) => `<i style="background:${c}"></i>`).join('')}</span>${esc(p.label)}</button>`).join('');
  }
  function togglePal(open) {
    if (open) { toggleIdle(false); toggleGeo(false); }
    $('#palmenu').hidden = !open;
    $('[data-act="pal"]')?.setAttribute('aria-expanded', String(open));
    showTeach();
  }
  if (api?.palettes) {
    renderPal();
    $('#palmenu').addEventListener('click', (e) => {
      const b = e.target.closest('[data-pal]');
      if (!b) return;
      api.setPalette(b.dataset.pal);
      renderPal();
      togglePal(false);
    });
    document.addEventListener('click', (e) => { if (!e.target.closest('#palmenu, [data-act="pal"]')) togglePal(false); });
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') togglePal(false); });
  }

  // ---- 圖層與教學選單 ----
  function renderGeo() {
    const item = ([k, l]) => `<button type="button" role="menuitemcheckbox" aria-checked="${lay[k]}" data-lay="${k}">${l}<span class="idle-on">${lay[k] ? '開' : '關'}</span></button>`;
    const ls = layerList();
    $('#geomenu').innerHTML = (ls.some(([k]) => k !== 'teach') ? '<div class="palmenu-h">圖層</div>' + ls.filter(([k]) => k !== 'teach').map(item).join('') : '')
      + (geoFail ? '<p class="idle-note warn-t">讀不到圖層資料（vendor/geo/），請確認安裝檔是否完整</p>' : '')
      + (TEACH ? '<div class="palmenu-h" style="margin-top:4px">教學</div><p class="idle-note">右側多一個「成因」分頁，詳細卡加上火山成因的說明</p>' + item(['teach', '教學模式']) : '');
  }
  function toggleGeo(open) {
    if (open) { renderGeo(); togglePal(false); toggleIdle(false); }
    $('#geomenu').hidden = !open;
    $('[data-act="geo"]')?.setAttribute('aria-expanded', String(open));
    showTeach();
  }
  $('#geomenu').addEventListener('click', (e) => {
    const b = e.target.closest('[data-lay]');
    if (!b) return;
    e.stopPropagation();  // 選單重畫後被點的按鈕已經不在畫面上，不擋住的話外層會當成點在選單外而關閉
    const k = b.dataset.lay;
    setLayer(k, !lay[k]).then(() => $(`#geomenu [data-lay="${k}"]`)?.focus());
    renderGeo();
    $(`#geomenu [data-lay="${k}"]`).focus();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#geomenu, [data-act="geo"]')) toggleGeo(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggleGeo(false); });

  // ---- 教學火山選單：教學模式打開時一直顯示（在設定頁或左上「圖層與教學」選單打開）；點火山就飛過去、打開詳細卡（最上面是成因說明）。
  // 點火山、點地圖都不收，方便一座接一座切換；選單的 ✕ 與最下面的按鈕都是結束教學模式；
  // 待機、配色、圖層選單打開時暫時讓位（同一個位置），關掉後自己回來；待機時收起，有人操作再出現 ----
  function renderTeach() {
    $('#teachmenu').innerHTML = '<div class="tm-top"><span class="palmenu-h">教學火山</span><button type="button" class="tm-close" data-tend aria-label="結束教學模式" title="結束教學模式"><svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3 3 L11 11 M11 3 L3 11" stroke="#14171C" stroke-width="1.8" stroke-linecap="round"/></svg></button></div>'
      + '<p class="idle-note">點一座火山飛過去，詳細卡最上面有成因說明</p>'
      + TEACH.types.map((t) => `<div class="palmenu-h tm-h">${esc(t.name)}</div>`
        + t.volcanoes.filter((vn) => byV.has(vn)).map((vn) => `<button type="button" role="menuitem" class="${S.sel === vn ? 'sel' : ''}" data-v="${vn}">${nm(byV.get(vn))}</button>`).join('')).join('')
      + '<button type="button" class="tm-end" data-tend>結束教學模式</button>';
  }
  function showTeach() {
    const on = !!TEACH && lay.teach && teachPin && ['#palmenu', '#idlemenu', '#geomenu'].every((m) => $(m).hidden);
    if (on && $('#teachmenu').hidden) renderTeach();
    $('#teachmenu').hidden = !on;
  }
  function toggleTeach(open) {
    teachPin = open && !!TEACH;
    if (teachPin) { togglePal(false); toggleIdle(false); toggleGeo(false); }
    showTeach();
  }
  $('#teachmenu').addEventListener('click', (e) => {
    const b = e.target.closest('[data-v], [data-tend]');
    if (!b) return;
    if (b.dataset.v) select(b.dataset.v);  // 選單留著；選取的火山由 markSel 標成 .sel
    if (b.hasAttribute('data-tend')) setLayer('teach', false);
  });

  // ---- 頁首、圖例、頁尾 ----
  $('#sub').textContent = `Holocene 火山 ${fmtN(vols.length)} 座・頁面上的日期與時間都是世界協調時間（UTC）`;
  // 標題旁的今天日期（UTC，跟頁面上的資料同一個時間基準），每分鐘檢查一次換日
  const today = () => {
    const d = new Date();
    $('#today').innerHTML = `<span class="num">${d.getUTCFullYear()} 年 ${d.getUTCMonth() + 1} 月 ${d.getUTCDate()} 日</span> 週${'日一二三四五六'[d.getUTCDay()]}<i>UTC</i>`;
  };
  today();
  setInterval(today, 60000);
  const age = (Date.now() - Date.parse(meta.updated_utc)) / 864e5; // 資料時間距今幾天，沒有時間時是 NaN
  const warns = [age > 2 && `資料已 ${Math.floor(age)} 天未更新`, stale > 10 && `週報已 ${stale} 天未更新`].filter(Boolean);
  // 頁首只顯示更新時間；過期提醒改成圓點變橘色加滑鼠提示，詳情在「來源」分頁
  $('#fresh').innerHTML = `<span><span class="dot8" style="background:${warns.length ? '#D97706' : '#2F9E44'}"></span>資料更新 ${utc(meta.updated_utc)}</span>`;
  $('#fresh').title = warns.length ? `${warns.join('、')}，點選看來源` : '點選看來源';
  $('#fresh').addEventListener('click', () => { S.tab = 'sources'; renderTabs(); renderPanel(); });
  const cnt = (s) => vols.filter((v) => v.s === s).length;
  // 圖例：火山狀態；打開板塊邊界或地震時，另起一行列出線的種類與地震深度
  function renderLegend() {
    $('#legend').innerHTML = ORDER.filter((s) => s !== 'none' && cnt(s)).map((s) => `<span>${ico(s)}${ST[s].short} <b class="num" style="font-weight:500;color:#5A6170">${cnt(s)}</b></span>`).join('')
      + `<span>${ico('none', true)}十年火山 <b class="num" style="font-weight:500;color:#5A6170">${Object.keys(DECADE).length}</b></span><span>${ico('none')}其他火山</span>`
      + (api?.note ? `<span class="note">${esc(api.note)}</span>` : '')
      + (lay.plates ? '<i class="lg-br"></i><span class="lg-h">板塊邊界</span>' + PLATE_KINDS.map((k) => `<span><i class="lsw" style="background:${k.color}"></i>${k.label}</span>`).join('') : '')
      + (lay.quakes ? '<i class="lg-br"></i><span class="lg-h">地震深度</span>' + QUAKE_DEPTHS.map((d) => `<span><i class="qsw" style="background:${d.color}"></i>${d.label}<span class="note">${d.note}</span></span>`).join('')
        + '<span class="note">規模 5.5 以上・1976 年起・圓越大規模越大</span>' : '');
  }
  renderLegend();
  const g = meta.gvp || {};
  // 頁尾只留一行：聲明、資料來源簡稱、版本；完整出處與授權在「來源」分頁最下面（creditsHTML）
  $('#foot').innerHTML = `<b>本網頁非官方預警，警戒資訊以各國火山觀測機構公告為準。</b>
    <span>資料：Smithsonian GVP・USGS・NOAA・日本氣象廳・PHIVOLCS・GeoNet・AWS 地形・EOX 衛星影像等</span>
    <button type="button" class="linkbtn" id="credits">完整出處與授權（來源分頁）</button>
    <span class="ver">測試開發版 v${VERSION}（${VERSION_DATE}）</span>`;
  $('#credits').addEventListener('click', () => {
    S.tab = 'sources'; renderTabs(); renderPanel();
    $('#pbody .cite')?.scrollIntoView({ block: 'start' });
  });
  const creditsHTML = () => `<div class="cite"><b style="color:#14171C">出處與授權</b>
    <p lang="en">${esc(g.citation || 'Global Volcanism Program, Volcanoes of the World')} ${g.doi ? link(`https://doi.org/${g.doi}`, `https://doi.org/${esc(g.doi)}`) : ''}</p>
    <p>活動：Weekly Volcanic Activity Report・火山灰警報：各國航空氣象單位的 SIGMET（NOAA Aviation Weather Center 彙整）</p>
    <p>警戒等級：USGS HANS・日本氣象廳（出典：気象庁ホームページ，本站翻譯整理）・PHIVOLCS・GeoNet（CC BY 3.0 NZ）</p>
    <p>${esc(api?.credit || '')}</p>${api?.geo ? `<p>${esc(GEO_CREDIT)}</p>` : ''}
    <p>測試開發版 v${VERSION}（${VERSION_DATE}）・功能與畫面仍在調整，資料可能有誤</p></div>`;

  // ---- 區域快捷鍵 ----
  function renderRegions() {
    $('#regions').innerHTML = REGIONS.map((r) => `<button type="button" class="chip" data-r="${r.key}" aria-pressed="${S.region === r.key}">${r.label}</button>`).join('');
  }
  $('#regions').addEventListener('click', (e) => {
    const b = e.target.closest('[data-r]');
    if (!b || !api) return;
    S.region = b.dataset.r;
    renderRegions();
    api.region(REGIONS.find((r) => r.key === S.region));
  });

  // ---- 選取火山 ----
  function markSel() {
    document.querySelectorAll('.sel[data-v]').forEach((e) => e.classList.remove('sel'));
    if (S.sel != null) document.querySelectorAll(`[data-v="${S.sel}"]`).forEach((e) => e.classList.add('sel'));
  }
  function select(vnum) {
    const v = byV.get(+vnum);
    if (!v) return;
    S.sel = v.vnum;
    S.region = '';
    renderRegions();
    renderCard(v);
    markSel();
    if (api) { api.select(v.pin ? null : v); api.flyTo(v, $('#mapbox').clientWidth >= 760, !$('#teachmenu').hidden); }
  }
  function closeCard() {
    S.sel = null;
    $('#card').hidden = true;
    markSel();
    api?.select(null);
  }

  const recHTML = (r) => (r.verified
    ? `<article class="rec"><div class="meta">${r.source === 'rss'
        ? `<span class="cat">${esc(CAT[r.title] || r.title)}</span><span class="num">GVP/USGS 週報 ${r.period_start}～${r.date}</span>`
        : `<span class="cat" style="color:#9B1C14">${esc(r.title)}</span><span class="num">USGS HANS ${r.date}</span>`}</div>
        <p${r.source === 'rss' ? ' lang="en"' : ''}>${esc(r.summary)}</p>
        <div class="meta" style="margin-top:8px">來源：${esc(r.agency || '未註明')} ${link(r.url, '原文 ↗')}</div></article>`
    : `<article class="rec ai"><div class="meta num">${r.date}・Claude 網路搜尋</div><p>${esc(r.summary)}</p>${link(r.url, `${esc(r.agency || '來源')} ↗`)}</article>`);

  // 外部連結（原文、HANS 公告、GVP 等）：展示機是全螢幕模式，開出去的網頁沒有返回按鈕、關不掉，所以一律不開，
  // 改在畫面裡跳出小視窗，顯示網址與 QR code 讓觀眾用手機看。滑鼠中鍵、右鍵選單、拖曳連結也都擋下來
  let qrP = null, extBack = null;
  const loadQR = () => (qrP ||= new Promise((ok) => {
    const s = Object.assign(document.createElement('script'), { src: 'vendor/qrcode.js' });
    s.onload = () => ok(window.qrcode || null);
    s.onerror = () => ok(null);
    document.head.append(s);
  }));
  // 問題回報也用這個小視窗（reportOpen）：換掉說明文字、關閉後焦點回到「回報問題」按鈕
  async function openExt(a, { lead = '用手機掃描 QR code 看原文', note = '展示機不開外部網頁，請用自己的手機或電腦查看。', back = a } = {}) {
    const url = a.href;  // 瀏覽器已經把中文等字元轉成 %xx，QR code 只需要英數字
    extBack = back;
    $('#ext-title').textContent = a.textContent.replace(/↗/g, '').trim() || '外部網站';
    $('#ext-lead').textContent = lead;
    $('#ext-note').textContent = note;
    $('#ext-host').textContent = new URL(url).hostname.replace(/^www\./, '');
    $('#ext-url').textContent = url;
    $('#ext-qr').innerHTML = '';
    $('#ext').hidden = false;
    $('#ext-close').focus();
    const qrcode = await loadQR();
    if (!qrcode || $('#ext').hidden || $('#ext-url').textContent !== url) return;
    try {
      const q = qrcode(0, 'M');
      q.addData(url);
      q.make();
      $('#ext-qr').innerHTML = q.createSvgTag({ cellSize: 4, margin: 16, scalable: true });
    } catch { $('#ext-qr').textContent = '網址太長，無法產生 QR code'; }
  }
  function closeExt() {
    if ($('#ext').hidden) return;
    $('#ext').hidden = true;
    extBack?.focus();
  }
  const extLink = (e) => {
    const a = e.target.closest?.('a[href]');
    return a && /^https?:/i.test(a.href) && new URL(a.href).origin !== location.origin ? a : null;
  };
  for (const ev of ['click', 'auxclick']) {
    document.addEventListener(ev, (e) => {
      const a = extLink(e);
      if (!a) return;
      e.preventDefault();
      if (e.type === 'click') openExt(a);
    }, true);
  }
  for (const ev of ['contextmenu', 'dragstart']) document.addEventListener(ev, (e) => { if (extLink(e)) e.preventDefault(); }, true);
  $('#ext-close').addEventListener('click', closeExt);
  $('#ext').addEventListener('click', (e) => { if (e.target.id === 'ext') closeExt(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeExt(); });

  // 直播視窗：播放器 iframe 加了 sandbox、不允許開新視窗，點播放器裡的 YouTube 標誌或標題也不會另外打開 YouTube 網站，觀眾不會離開展示畫面。
  // 也不給全螢幕與子母畫面的權限（fs=0 拿掉全螢幕按鈕，連點兩下也放不大），影片只在這個小視窗裡播
  let ytBack = null;
  function openYT(x, from) {
    if (!x) return;
    ytBack = from;
    $('#yt-title').textContent = x.title;
    $('#yt-ch').textContent = `${x.channel}・${x.official ? '官方' : '非官方，僅供參考'}`;
    $('#yt-note').textContent = navigator.onLine ? '預設靜音，按播放器的喇叭圖示開聲音。' : '目前離線，需要網路才能播放。';
    $('#yt-if').src = `https://www.youtube-nocookie.com/embed/${x.id}?autoplay=1&mute=1&rel=0&playsinline=1&fs=0`;
    $('#yt').hidden = false;
    $('#yt-close').focus();
  }
  function closeYT() {
    if ($('#yt').hidden) return;
    $('#yt').hidden = true;
    $('#yt-if').src = 'about:blank'; // 停止播放
    ytBack?.focus();
  }
  $('#yt-close').addEventListener('click', closeYT);
  $('#yt').addEventListener('click', (e) => { if (e.target.id === 'yt') closeYT(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeYT(); });
  $('#card').addEventListener('click', (e) => {
    const b = e.target.closest('[data-yt], [data-teach]');
    if (b?.dataset.yt) openYT(liveBy.get(b.dataset.yt), b);
    if (b?.dataset.teach) {  // 跳到「成因」分頁的那一類
      S.tab = 'teach';
      renderTabs();
      renderPanel();
      $(`#teach-${b.dataset.teach}`)?.scrollIntoView({ block: 'start' });
    }
  });
  // 火環：打開板塊邊界與地震，鏡頭轉到太平洋中間的全球視角
  async function showRing() {
    closeCard();
    S.region = '';
    renderRegions();
    api.region({ key: 'world', lat: 5, lon: -165 });
    await Promise.all(['plates', 'quakes'].filter((k) => !lay[k]).map((k) => setLayer(k, true)));
  }

  function renderCard(v) {
    const st = ST[v.s], a = alertBy.get(v.vnum), recs = actBy.get(v.vnum) || [];
    const lv = lvlBy.get(v.vnum), ashes = ashBy.get(v.vnum) || [], run = runDays(v.vnum);
    const official = recs.filter((r) => r.verified).slice(0, 3);
    const ai = recs.filter((r) => !r.verified).slice(0, 3);
    const paren = v.dec.indexOf('(');
    const le = v.last_eruption == null ? `未知（${esc(v.evidence)}）` : v.last_eruption < 0 ? `西元前 ${-v.last_eruption} 年` : `${v.last_eruption} 年`;
    const coord = `${Math.abs(v.lat).toFixed(3)}°${v.lat >= 0 ? 'N' : 'S'}, ${Math.abs(v.lon).toFixed(3)}°${v.lon >= 0 ? 'E' : 'W'}`;
    const c = a ? (AVC[a.color_code] || AVC.YELLOW) : null;
    // 標題：噴發的火山與十年火山最上面一條狀態色帶（噴發用圖例的顏色，十年火山用深青色；兩種都是時以噴發為主，十年火山改成小標章）
    const erupt = ERUPT.has(v.s);
    const band = erupt
      ? `<div class="band b-${v.s}">${v.s === 'erupt_now' ? '<span class="breath" aria-hidden="true"></span>' : ico(v.s, false, 16, '#FFFFFF')}<span>${v.s === 'erupt_now' ? `噴發中・連續 ${runTxt(run)}` : st.long}${v.s === 'erupt_off' && offSrc(v.vnum) ? `<small>發布：${esc(offSrc(v.vnum))}</small>` : ''}</span>${v.dec ? `<span class="pill">${DEC_ICO}十年火山</span>` : ''}</div>`
      : v.dec ? `<div class="band b-dec">${DEC_ICO}<span>十年火山<small>國際重點研究火山</small></span></div>` : '';
    const pill = (t) => (v.s === 'alert'
      ? `<span class="pill" style="background:${COL.alert};color:#FFFFFF">${ico(v.s, !!v.dec, 12, '#FFFFFF')}${t}</span>`
      : `<span class="pill" style="background:${st.bg};color:${st.fg}">${ico(v.s, !!v.dec, 12)}${t}</span>`);
    // # 標籤：這座火山收到的警報，只放有資料的項目；十年火山色帶下面的狀態標章也算，一共最多 4 個
    const ag = lv && (lv.agency === 'JMA' ? '日本氣象廳' : lv.agency);  // 國家已寫在上一行，標籤只寫機構
    const tags = [
      a && `USGS ${a.color_code}／${a.alert_level}`,
      lv?.elevated && (lv.level == null ? `${ag} ${lv.label}` : `${ag} 等級 ${lv.level}`),
      lv?.elevated && lv.level != null && lv.label.split('：')[1],
      ashes.length && `火山灰警報 ${ashes.length} 則`,  // 標籤寫短一點，兩個才排得進一行
      ashes[0]?.top_ft && `灰雲高${ashM(ashes[0].top_ft)}`,
    ].filter(Boolean).slice(0, v.dec && !erupt ? 3 : 4);
    const row = (v.dec && !erupt ? pill(st.short) : '') + tags.map((t) => `<span class="htag"><i>#</i>${esc(t)}</span>`).join('');
    const tagRow = row ? `<div class="htags t-${v.s}">${row}</div>` : '';
    $('#card').innerHTML = `
      <div class="card-head${band ? ` has-band band-${erupt ? v.s : 'dec'}` : ''}">
        ${band}
        <div class="card-id">
          ${band ? '' : `<div class="pills">${pill(st.long)}</div>`}
          <h2>${esc(v.name)}</h2>${v.zh ? `<div class="card-zh">${esc(v.zh)}</div>` : ''}
          <div class="card-meta">${esc(v.country)}・${esc(v.type)}</div>
          ${paren > 0 ? `<div class="card-meta">通稱 ${esc(v.dec.slice(paren + 1, -1))}</div>` : ''}
          ${v.gvp !== v.name ? `<div class="card-meta">GVP 名稱 ${esc(v.gvp)}</div>` : ''}
          ${band ? tagRow : ''}
        </div>
        <button class="close" type="button" id="close" aria-label="關閉詳細資訊"><svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3 3 L11 11 M11 3 L3 11" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg></button>
        ${band ? '' : tagRow}
      </div>
      <div class="card-body">
        ${teachCardHTML(v)}
        ${INTRO[v.vnum] ? `<div class="intro"><p>${esc(INTRO[v.vnum].zh)}</p></div>` : ''}
        <dl class="facts"><div><dt>最近噴發</dt><dd>${le}</dd></div><div><dt>GVP 編號</dt><dd class="num">${v.vnum}</dd></div><div><dt>座標</dt><dd class="num">${coord}</dd></div></dl>
        ${act30HTML(v)}
        ${(LIVE[v.vnum] || []).length ? `<div><h3>直播影像（YouTube）</h3><div class="lives">${LIVE[v.vnum].map((x) => `<button type="button" class="live" data-yt="${x.id}">
          <img src="https://i.ytimg.com/vi/${x.id}/mqdefault.jpg" alt="" loading="lazy" width="96" height="54">
          <span class="live-txt"><span class="live-ch"><span class="live-dot" aria-hidden="true"></span>${esc(x.channel)}<span class="live-tag${x.official ? ' off' : ''}">${x.official ? '官方' : '非官方'}</span></span><span class="live-ti">${esc(x.title)}</span></span></button>`).join('')}</div>
          <p class="muted" style="margin:6px 0 0">點選播放，需要網路。${LIVE[v.vnum].some((x) => !x.official) ? '非官方頻道的畫面僅供參考。' : ''}</p></div>` : ''}
        ${a ? `<div><h3>目前警戒（USGS HANS）</h3><div class="rec"><span class="avc" style="background:${c[0]};color:${c[1]}"><span class="dot8" style="background:${c[2]};margin:0"></span>${esc(a.color_code)} / ${esc(a.alert_level)}</span>
          <div class="meta" style="margin-top:8px">${esc(a.observatory)}・${utc(a.sent_utc)}</div>${link(a.url, '查看 HANS 公告 ↗')}</div></div>` : ''}
        ${lv ? `<div><h3>目前警戒（${esc(AGENCY[lv.agency] || lv.agency)}）</h3><div class="rec"><span class="avc lvl${lv.elevated ? ' up' : ''}">${esc(lv.label)}</span>
          <div class="meta" style="margin-top:8px">${esc(lv.local)}・<span lang="${lv.agency === 'JMA' ? 'ja' : 'en'}">${esc(lv.orig)}</span>${lv.time ? `・${lv.agency === 'PHIVOLCS' ? `公報 ${lv.time.slice(0, 10)}` : `${utc(lv.time)} 起`}` : ''}</div>
          ${link(lv.url, '查看官方公告 ↗')}</div><p class="muted" style="margin:6px 0 0">各國的警戒等級制度不同，不能直接比較${lv.agency === 'JMA' ? '・出典：気象庁ホームページ（本站翻譯整理）' : ''}</p></div>` : ''}
        ${ashes.length ? `<div><h3>航空火山灰警報（最近 7 天 ${ashes.length} 則${run >= 2 ? `・連續 ${runTxt(run)}` : ''}）</h3>${ashes.slice(0, 3).map((x) => `<div class="rec">
          <b>灰雲頂${ashTop(x.top_ft)}</b>${x.dir ? `・往${DIR[x.dir] || esc(x.dir)}飄${x.spd_kt ? `（每小時 ${x.spd_kt} 浬）` : ''}` : ''}
          <div class="meta num">${md(x.from)} ${x.from.slice(11, 16)} 到 ${md(x.to)} ${x.to.slice(11, 16)} UTC・${esc(x.fir)}</div></div>`).join('')}
          <p class="muted" style="margin:6px 0 0">火山灰會損壞飛機引擎，各國航空氣象單位會發布火山灰 SIGMET，劃出灰雲範圍讓飛機避開（NOAA 航空氣象中心彙整）。</p></div>` : ''}
        ${official.length ? `<div><h3>官方紀錄</h3>${official.map(recHTML).join('')}</div>` : ''}
        ${ai.length ? `<div><h3>資料來源</h3>${ai.map(recHTML).join('')}</div>` : ''}
        ${!a && !lv && !ashes.length && !recs.length ? '<p class="empty">目前沒有這座火山的活動紀錄。</p>' : ''}
        ${link(`https://volcano.si.edu/volcano.cfm?vn=${v.vnum}`, '在 GVP 網站查看完整資料 ↗')}
      </div>`;
    $('#card').hidden = false;
    $('#close').addEventListener('click', closeCard);
    // 30 天活動圖：點某一天，在圖下方顯示當天的紀錄（展示機是觸控螢幕，滑鼠移過去的提示看不到）
    $('#card .act30 svg')?.addEventListener('click', (e) => {
      const g = e.target.closest('[data-tip]');
      if (!g) return;
      $('#card .act30 .on')?.classList.remove('on');
      g.classList.add('on');
      $('#card .act-cap').textContent = g.dataset.tip;
    });
  }

  // ---- 教學模式：詳細卡的成因說明、「成因」分頁 ----
  const teachNote = () => (TEACH.checked ? '' : 'Claude 起草，未經人工校對・');
  const fig = (t) => (DIAGRAM[t.diagram] ? `<figure class="teach-fig">${DIAGRAM[t.diagram]}</figure>` : '');
  function teachCardHTML(v) {
    const tv = lay.teach && TEACH?.volcanoes[v.vnum], tt = tv && TEACH.types.find((t) => t.key === tv.type);
    if (!tt) return '';
    return `<div class="teach-card"><div class="teach-h"><span>火山成因</span><b>${esc(tt.name)}</b>${tt.sub ? `<i>${esc(tt.sub)}</i>` : ''}</div>
      ${fig(tt)}<p>${esc(tv.text)}</p>
      <p class="intro-src">${teachNote()}<button type="button" class="linkbtn" data-teach="${tt.key}">看「成因」分頁的說明</button></p></div>`;
  }
  function teachHTML() {
    const T = TEACH, ps = (a) => a.map((x) => `<p>${esc(x)}</p>`).join('');
    const row = (vn) => {
      const v = byV.get(vn);
      return v ? `<button type="button" class="row${isSel(vn)}" data-v="${vn}">${ico(v.s, !!v.dec)}<span class="grow"><b>${nm(v)}</b><span>${esc(v.country)}</span></span></button>` : '';
    };
    return `<div class="teach-tab">
      <p class="teach-lead">${esc(T.intro)}</p>
      <section class="teach-sec ring"><h3>${esc(T.ring.title)}</h3>${ps(T.ring.text)}
        ${api?.geo ? '<button type="button" class="chip" data-act="ring">在地圖上看火環（打開板塊邊界與地震）</button>' : ''}
        <p class="intro-src">${esc(T.ring.source.replace(/ https?:.*/, ''))}・${link(T.ring.source.match(/https?:\S+/)?.[0], '原文 ↗')}</p></section>
      <section class="teach-sec"><h3>板塊邊界的種類</h3>
        <ul class="kinds">${PLATE_KINDS.map((k) => `<li><i class="lsw" style="background:${k.color}"></i><span><b>${k.label}</b>${k.note ? `（${k.note}）` : ''}：${esc(T.boundaries[k.key])}</span></li>`).join('')}</ul>
        <p class="muted">${esc(T.plates_note)}</p></section>
      <section class="teach-sec"><h3>地震的深度</h3>
        <ul class="kinds">${QUAKE_DEPTHS.map((d) => `<li><i class="qsw" style="background:${d.color}"></i><span><b>${d.label}</b>（${d.note}）</span></li>`).join('')}</ul>
        <p>${esc(T.quakes)}</p></section>
      ${T.types.map((t) => `<section class="teach-sec" id="teach-${t.key}"><h3>${esc(t.name)}${t.sub ? `<span class="muted">${esc(t.sub)}</span>` : ''}</h3>
        ${fig(t)}<p>${esc(t.text)}</p>${t.volcanoes.map(row).join('')}</section>`).join('')}
      <p class="intro-src">${teachNote()}參考資料：${T.sources.map(esc).join('；')}</p>
    </div>`;
  }

  // ---- 右側面板 ----
  const TABS = [['overview', '概況'], ['activity', '活動'], ['list', '火山'], ['sources', '來源']];
  const tabs = () => [...TABS, ...(lay.teach && TEACH ? [['teach', '成因']] : [])];
  function renderTabs() {
    $('#tabs').innerHTML = tabs().map(([k, l]) => `<button type="button" data-tab="${k}" aria-pressed="${S.tab === k}">${l}</button>`).join('');
  }
  const isSel = (v) => (S.sel === v ? ' sel' : '');
  const secHead = (title, n, sub) => `<div class="sec-h"><h2>${title}</h2><span class="count num">${n}</span></div>${sub ? `<p class="muted">${sub}</p>` : ''}`;
  // 概況的區塊：點標題列展開或收合
  const fold = (key, cls, title, n, body, badge = '') => {
    const open = S.open.has(key);
    return `<section class="sec tint ${cls}${open ? '' : ' shut'}"><button type="button" class="sec-h fold" data-fold="${key}" aria-expanded="${open}">
      <h2>${title}</h2><span class="count num">${n}</span>${badge}<svg class="chev" width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3 5 L7 9 L11 5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
      <div class="fold-body">${body}</div></section>`;
  };

  function overviewHTML() {
    // 列進本日關注的火山不在下面的噴發與警戒清單重複出現
    const al = alerts.filter((a) => !watch.has(a.vnum)).sort((a, b) => b.sent_utc.localeCompare(a.sent_utc));
    const lvUp = levels.filter((l) => l.elevated && byV.has(l.vnum) && !watch.has(l.vnum));
    const alertRows = al.map((a) => {
      const c = AVC[a.color_code] || AVC.YELLOW;
      const v = byV.get(a.vnum);
      return `<button type="button" class="row${isSel(a.vnum)}" data-v="${a.vnum}">${ico(v?.s || 'alert', !!v?.dec)}<span class="grow"><b>${byV.has(a.vnum) ? nm(byV.get(a.vnum)) : esc(a.name)}</b><span class="num">${esc(a.observatory)}・${md(a.sent_utc)} ${a.sent_utc.slice(11, 16)}</span></span>
        <span class="avc" style="background:${c[0]};color:${c[1]}"><span class="dot8" style="background:${c[2]};margin:0"></span>${esc(a.color_code)} / ${esc(a.alert_level)}</span></button>`;
    }).join('') + lvUp.sort((a, b) => (b.level ?? 0) - (a.level ?? 0)).map((l) => {
      const v = byV.get(l.vnum);
      return `<button type="button" class="row${isSel(l.vnum)}" data-v="${l.vnum}">${ico(v.s, !!v.dec)}<span class="grow"><b>${nm(v)}</b><span>${esc(AGENCY[l.agency] || l.agency)}・${esc(l.label.split('：').pop())}</span></span>
        <span class="avc lvl up">${l.level != null ? `等級 ${l.level}` : '警戒'}</span></button>`;
    }).join('');
    const vol = (r) => byV.get(r.vnum) || { name: String(r.vnum), country: '', s: 'none', dec: '' };
    const srcTxt = (r) => (r.source === 'ash' ? `航空火山灰警報${r.top_ft ? `・灰雲${ashTop(r.top_ft).replace(/（.*/, '')}` : ''}`
      : r.source === 'rss' ? '官方週報' : `資料來源${r.agency ? `：${esc(r.agency)}` : ''}`);
    const news = weekly.filter((r) => /^New/.test(r.title));
    const cont = weekly.filter((r) => !/^New/.test(r.title));
    const shown = S.allClaude ? claude : claude.slice(0, 5);
    // 最新噴發活動：昨天與今天（UTC）有噴發的火山，每座留最新一筆（官方優先）。
    // 噴發中（連續 2 天以上）的排在最上面自成一組，標題列另有紅色標章，不另外開一個清單
    const lLast = new Map();
    erupt7.forEach((r) => r.source !== 'rss' && r.date >= yday && !watch.has(r.vnum) && !lLast.has(r.vnum) && lLast.set(r.vnum, r));
    const lNow = [...lLast.values()].filter((r) => eruptNow.has(r.vnum)).sort((a, b) => runDays(b.vnum) - runDays(a.vnum));
    const lOne = [...lLast.values()].filter((r) => !eruptNow.has(r.vnum));
    const lRow = (r, now) => { const v = vol(r); return `<button type="button" class="row${now ? ' now' : ''}${isSel(r.vnum)}" data-v="${r.vnum}">${ico(v.s, !!v.dec)}<span class="grow"><b>${nm(v)}</b><span>${esc(v.country)}・${srcTxt(r)}</span></span>${now ? `<span class="tag now">連續 ${runTxt(runDays(r.vnum))}</span>` : dchip(r.date)}</button>`; };
    const latestRows = (lNow.length ? `<div class="sub now"><span class="breath" aria-hidden="true"></span>噴發中・連續 2 天以上・${lNow.length}</div>${lNow.map((r) => lRow(r, true)).join('')}` : '')
      + (lOne.length ? `<div class="sub">昨天或今天其中一天噴發・${lOne.length}</div>${lOne.map((r) => lRow(r, false)).join('')}` : '');
    // 7 天內噴發：不重複列出上面已經列出的火山。圖示跟地圖上一樣（顏色代表來源）
    const eLast = new Map();
    erupt7.forEach((r) => watch.has(r.vnum) || lLast.has(r.vnum) || eLast.has(r.vnum) || eLast.set(r.vnum, r));  // 已依日期新到舊排序，留最新一筆
    const eruptRows = [...eLast.values()].map((r) => { const v = vol(r); return `<button type="button" class="row${isSel(r.vnum)}" data-v="${r.vnum}">${ico(v.s, !!v.dec)}<span class="grow"><b>${nm(v)}</b><span>${esc(v.country)}・${srcTxt(r)}</span></span>${dchip(r.date)}</button>`; }).join('');
    const nAlert = al.length + lvUp.length;
    // 本日關注：依理由分組，一座火山放在最優先的那組；其他理由、噴發中天數、有直播當小標籤
    const wRow = (vn, key) => {
      const v = byV.get(vn), w = watch.get(vn), run = eruptNow.has(vn) ? runDays(vn) : 0;
      const tags = WATCH.filter(([k]) => k !== key && w[k]).map(([k, l]) => `<span class="wtag w-${k}">${k === 'media' && outlet.has(vn) ? `媒體・${esc(outlet.get(vn))}` : l}</span>`).join('')
        + (run ? `<span class="wtag w-run">噴發中 ${runTxt(run)}</span>` : '') + ((LIVE[vn] || []).length ? '<span class="wtag w-live"><i></i>可看直播</span>' : '');
      return `<button type="button" class="row wrow${isSel(vn)}" data-v="${vn}">${ico(v.s, !!v.dec)}<span class="grow"><b>${nm(v)}</b><span class="why">${esc(w[key])}</span>${tags ? `<span class="wtags">${tags}</span>` : ''}</span></button>`;
    };
    const top = (vn) => WATCH.find(([k]) => watch.get(vn)[k])[0];
    const watchBody = WATCH.map(([k, l, d]) => {
      const vs = [...watch.keys()].filter((vn) => top(vn) === k);
      return vs.length ? `<div class="wsub"><i class="wdot w-${k}"></i><b>${l}</b><span>${vs.length}</span><em>${d}</em></div>${vs.map((vn) => wRow(vn, k)).join('')}` : '';
    }).join('');
    const movedLatest = erupt7.some((r) => r.source !== 'rss' && r.date >= yday && watch.has(r.vnum));
    return fold('watch', 'watch', '本日關注火山', watch.size, `
        ${watchBody || '<p class="empty">今天沒有特別需要關注的火山。</p>'}
        <p class="sec-foot"><span class="num">${yday}</span> 與今天（UTC）・依官方警戒等級的變化、航空火山灰警報與每日報告（Claude 整理，新聞類未經官方確認）自動挑選；列在這裡的火山不在下面重複出現</p>`)
      + fold('latest', 'yday', '最新噴發活動', lLast.size, `
        ${latestRows || `<p class="empty">${movedLatest ? '昨天與今天有噴發的火山都列在上面的本日關注。' : '昨天與今天沒有噴發紀錄。'}</p>`}
        <p class="sec-foot"><b class="now-txt">噴發中</b>：從今天（今天沒有就從昨天）往回數，連續 2 天以上每天都有噴發紀錄，排在最上面並標出連續天數。<span class="num">${yday}</span> 與今天（UTC）・依航空火山灰警報或報導判斷；週報是一週的彙整，不列入</p>`,
      lNow.length ? `<span class="nowbadge"><span class="breath" aria-hidden="true"></span>噴發中 ${lNow.length}</span>` : '')
      + fold('week', 'week', '7 天內噴發', eLast.size, `
        ${eruptRows || `<p class="empty">${lLast.size ? '除了上面的火山，最近 7 天沒有其他噴發紀錄。' : '最近 7 天沒有噴發紀錄。'}</p>`}
        <p class="sec-foot">最近 7 天（UTC）${lLast.size ? '，不含上面已列出的火山' : ''}・每列註明來源</p>`)
      + fold('alert', 'alert', '警戒升高中', nAlert, `${alertRows || '<p class="empty">目前沒有警戒升高的火山。</p>'}<p class="sec-foot">美國 USGS HANS、日本氣象廳、菲律賓 PHIVOLCS、紐西蘭 GeoNet・各國等級制度不同，不能直接比較；印尼、堪察加等地的官方網站不開放程式讀取，沒有列入</p>`)
      + fold('wk', 'wk', '官方週報', weekly.length, `
        ${stale > 10 ? `<div class="note-amber">已 ${stale} 天沒有新一期週報，以下為最新一期內容。</div>` : ''}
        <div class="sub">新噴發活動・${news.length}</div>
        ${news.map((r) => { const v = vol(r); return `<button type="button" class="row${isSel(r.vnum)}" data-v="${r.vnum}">${ico(v.s, !!v.dec)}<span class="grow"><b>${nm(v)}</b></span><span class="muted">${esc(v.country)}</span></button>`; }).join('') || '<p class="muted">本期沒有新噴發活動。</p>'}
        <div class="sub">持續噴發活動・${cont.length}</div>
        <div class="wrapchips">${cont.map((r) => `<button type="button" class="${isSel(r.vnum).trim()}" data-v="${r.vnum}">${nm(vol(r))}</button>`).join('')}</div>
        <p class="sec-foot"><span class="num">Weekly Volcanic Activity Report・${meta.rss?.report_start || '?'}～${weekEnd || '?'}</span></p>
        <p class="sec-foot">官方週報：Smithsonian 全球火山計畫（GVP）與美國地質調查所（USGS）合作發布的全球火山活動週報，彙整各國火山觀測機構等來源的通報，每週一期，分成新噴發活動與持續噴發活動。內容是初步資訊，之後可能修正。</p>`)
      + fold('unv', 'unv', '資料來源', claude.length, `
        ${shown.map((r) => `<button type="button" class="row top-align${isSel(r.vnum)}" data-v="${r.vnum}">${dchip(r.date)}<span class="grow"><b>${nm(vol(r))}</b><span class="clamp">${esc(r.summary)}</span><span>${esc(r.agency)}</span></span></button>`).join('') || '<p class="empty">近 30 天沒有補充資料。</p>'}
        ${claude.length > 5 ? `<button type="button" class="linkbtn" data-act="claude">${S.allClaude ? '收合' : `顯示全部 ${claude.length} 筆`}</button>` : ''}
        <p class="sec-foot">Claude 網路搜尋・近 30 天官方來源未涵蓋的活動，僅供參考</p>`);
  }

  function activityHTML() {
    const since = S.win ? daysAgo(S.win) : '';
    const rows = activity.filter((r) => r.date >= since)
      .sort((a, b) => b.date.localeCompare(a.date) || 'hans rss claude'.indexOf(a.source) - 'hans rss claude'.indexOf(b.source));
    return `<div class="sec tint plain">
      <div class="filters"><select class="select" id="win" aria-label="時間範圍">${[[7, '最近 7 天'], [30, '最近 30 天'], [90, '最近 90 天'], [0, '全部']].map(([n, l]) => `<option value="${n}"${S.win === n ? ' selected' : ''}>${l}</option>`).join('')}</select></div>
      <p class="muted">${rows.length} 筆・依日期排序（UTC）・週報以報告期間的最後一天計</p>
      ${rows.map((r) => `<button type="button" class="row top-align${isSel(r.vnum)}" data-v="${r.vnum}">${dchip(r.date)}
        <span class="grow"><b>${byV.has(r.vnum) ? nm(byV.get(r.vnum)) : esc(r.vnum)} <span class="tag src-${r.source}" style="display:inline-block;margin-left:4px">${SRC[r.source]}</span></b>
        <span>${esc(CAT[r.title] || r.title)}</span><span class="clamp"${r.source === 'rss' ? ' lang="en"' : ''}>${esc(r.summary)}</span></span></button>`).join('') || '<p class="empty">這段期間沒有活動紀錄。</p>'}
    </div>`;
  }

  function listHTML() {
    const q = S.q.trim().toLowerCase();
    let pool = q ? vols.filter((v) => v.name.toLowerCase().includes(q) || v.gvp.toLowerCase().includes(q) || v.zh.includes(q) || v.country.toLowerCase().includes(q))
      : S.filt === 'decade' ? vols.filter((v) => v.dec) : S.filt === 'active' ? vols.filter((v) => v.s !== 'none') : vols;
    if (S.country) pool = pool.filter((v) => v.country.includes(S.country));
    const countries = [...new Set(vols.map((v) => v.country))].sort();
    const filters = [['active', '有活動', vols.filter((v) => v.s !== 'none').length], ['decade', '十年火山', vols.filter((v) => v.dec).length], ['all', '全部', vols.length]];
    return `<div class="sec tint plain">
      <div class="filters">${filters.map(([k, l, n]) => `<button type="button" class="chip" data-filt="${k}" aria-pressed="${!q && S.filt === k}">${l} <span class="n num">${fmtN(n)}</span></button>`).join('')}
        <select class="select" id="country" aria-label="國家"><option value="">全部國家</option>${countries.map((c) => `<option${S.country === c ? ' selected' : ''}>${esc(c)}</option>`).join('')}</select></div>
      <p class="muted">${q ? `搜尋「${esc(S.q.trim())}」：` : ''}${fmtN(pool.length)} 座</p>
      ${pool.slice(0, S.limit).map((v) => `<button type="button" class="row${isSel(v.vnum)}" data-v="${v.vnum}">${ico(v.s, !!v.dec)}<span class="grow"><b style="font-weight:500">${nm(v)}</b><span>${esc(v.country)}</span></span>${v.dec ? '<span class="tag dec">十年</span>' : ''}</button>`).join('')}
      ${pool.length > S.limit ? `<button type="button" class="more" data-act="more">再顯示 150 座（還有 ${fmtN(pool.length - S.limit)} 座）</button>` : ''}
      ${q && !pool.length ? '<p class="muted">找不到符合的火山，名稱請用英文（例如 Etna、Aira）。</p>' : ''}
    </div>`;
  }

  function sourcesHTML() {
    const r = meta.rss || {}, h = meta.hans || {}, c = meta.claude || {}, dc = meta.decade_check || {};
    const err = (m) => (m?.error ? `<p class="warn">最近一次抓取失敗（${utc(m.error_utc)}）：${esc(m.error)}，目前顯示上一份資料。</p>` : '');
    const viaArchive = (g.citation_source || '').includes('web.archive.org');
    const note = remote === 'none' ? '沒有設定線上資料包（config.json），只讀本機的 data/。'
      : remote === 'fail' ? '這次讀不到線上資料包（可能離線或網址有誤），改用本機的資料。'
        : from === 'remote' ? '已讀到最新的線上資料包。' : '線上資料包讀取成功，但本機這份比較新。';
    return `<div class="sec">
      <div class="src"><h3><span class="dot8" style="background:${remote === 'fail' || age > 2 ? '#D97706' : '#2F9E44'}"></span>資料包</h3>
        <dl><dt>使用</dt><dd>${FROM[from]}</dd><dt>資料時間</dt><dd class="num">${utc(meta.updated_utc)}</dd></dl>
        <p>${note}</p>${age > 2 ? `<p class="warn">資料已 ${Math.floor(age)} 天未更新。</p>` : ''}</div>
      <div class="src"><h3><span class="dot8" style="background:${namesWarn.length || names.remote === 'fail' ? '#D97706' : '#2F9E44'}"></span>名稱對照</h3>
        <dl><dt>使用</dt><dd>${sideFrom('names.json', names.from)}</dd><dt>筆數</dt><dd class="num">英文名 ${Object.keys(NAME).length} 筆、中文名 ${Object.keys(ZH).length} 筆</dd></dl>
        <p>在 GitHub 資料 repo 編輯 names.json，各台重新整理網頁就會套用（GitHub Pages 約 1～10 分鐘）。</p>
        ${names.remote === 'fail' ? '<p class="warn">這次讀不到線上的 names.json（離線，或檔案格式不對），改用上一份。</p>' : ''}
        ${namesWarn.length ? `<p class="warn">有 ${namesWarn.length} 筆需要確認：${esc(namesWarn.slice(0, 5).join('、'))}${namesWarn.length > 5 ? ' 等' : ''}</p>` : ''}</div>
      <div class="src"><h3><span class="dot8" style="background:${decadeWarn.length || decade.remote === 'fail' || dc.status === 'diff' || dc.error ? '#D97706' : '#2F9E44'}"></span>十年火山名單</h3>
        <dl><dt>使用</dt><dd>${sideFrom('decade.json', decade.from)}</dd><dt>火山</dt><dd class="num">${Object.keys(DECADE).length} 個 GVP 編號</dd><dt>每年比對</dt><dd class="num">${dc.checked_utc ? utc(dc.checked_utc) : '尚未比對'}</dd></dl>
        <p>IAVCEI 在 1990 年代選定 16 座。資料站每年比對一次維基百科條目的名單，有差異只提醒、不自動修改；要修改時在 GitHub 資料 repo 編輯 decade.json。</p>
        ${dc.status === 'diff' ? `<p class="warn">維基百科的名單跟上次不同：新增 ${esc((dc.added || []).join('、') || '無')}；移除 ${esc((dc.removed || []).join('、') || '無')}。請確認後再決定要不要修改 decade.json。</p>` : ''}
        ${dc.error ? `<p class="warn">最近一次比對失敗（${utc(dc.error_utc)}）：${esc(dc.error)}，下次更新會再試。</p>` : ''}
        ${decade.remote === 'fail' ? '<p class="warn">這次讀不到線上的 decade.json（離線，或檔案格式不對），改用上一份。</p>' : ''}
        ${decadeWarn.length ? `<p class="warn">有 ${decadeWarn.length} 筆需要確認：${esc(decadeWarn.slice(0, 5).join('、'))}</p>` : ''}</div>
      <div class="src"><h3><span class="dot8" style="background:${intro.remote === 'fail' ? '#D97706' : '#2F9E44'}"></span>中文簡介</h3>
        <dl><dt>使用</dt><dd>${sideFrom('intro.json', intro.from)}</dd><dt>筆數</dt><dd class="num">${fmtN(Object.keys(INTRO).length)} 座，人工校對 ${fmtN(Object.values(INTRO).filter((x) => x.checked).length)} 座</dd></dl>
        <p>詳細卡最上面的中文簡介，依 Smithsonian GVP Volcanoes of the World 的地質摘要，由 Claude API 每月整理一次新增或原文有更新的火山；除了上面人工校對過的，其他都是 Claude 整理、未經人工校對。原文在每張詳細卡最下面的「在 GVP 網站查看完整資料」。</p>
        <p>可以在 GitHub 資料 repo 修改 intro.json，校對過的把 checked 改成 true，之後就不會被覆蓋。</p>
        ${intro.remote === 'fail' ? '<p class="warn">這次讀不到線上的 intro.json（離線，或檔案格式不對），改用上一份。</p>' : ''}</div>
      <div class="src"><h3><span class="dot8" style="background:#2F9E44"></span>GVP Volcanoes of the World</h3>
        <dl><dt>版本</dt><dd>v${esc(g.version || '?')}（${esc(g.version_date || '?')}）</dd><dt>火山數</dt><dd class="num">${fmtN(vols.length)} 座 Holocene 火山</dd><dt>抓取</dt><dd class="num">${utc(g.fetched_utc)}</dd></dl>
        <p>${viaArchive ? 'GVP 官網查核時無法連線，版本資訊取自官網的 Wayback 封存頁。' : '版本資訊取自 GVP 官網。'}</p>${err(g)}</div>
      <div class="src"><h3><span class="dot8" style="background:${stale > 10 ? '#D97706' : '#2F9E44'}"></span>Weekly Volcanic Activity Report</h3>
        <dl><dt>最新一期</dt><dd class="num">${r.report_start || '?'}～${r.report_end || '?'}</dd><dt>筆數</dt><dd class="num">${r.count ?? '?'} 筆</dd><dt>抓取</dt><dd class="num">${utc(r.fetched_utc)}</dd></dl>
        ${stale > 10 ? `<p class="warn">已 ${stale} 天沒有新一期週報。</p>` : '<p>每週四 23:00 UTC 前更新。</p>'}${err(r)}</div>
      <div class="src"><h3><span class="dot8" style="background:#2F9E44"></span>USGS HANS</h3>
        <dl><dt>最新公告</dt><dd class="num">${utc(h.latest_sent_utc)}</dd><dt>警戒升高</dt><dd class="num">${h.count ?? '?'} 座</dd><dt>抓取</dt><dd class="num">${utc(h.fetched_utc)}</dd></dl>
        <p>只涵蓋美國（含北馬利安納群島）的火山。</p>${err(h)}</div>
      <div class="src"><h3><span class="dot8" style="background:${meta.ash?.error ? '#D97706' : '#2F9E44'}"></span>航空火山灰警報（NOAA Aviation Weather Center）</h3>
        <dl><dt>最近 7 天</dt><dd class="num">${meta.ash?.count ?? '?'} 則、${meta.ash?.volcanoes ?? '?'} 座火山</dd><dt>抓取</dt><dd class="num">${utc(meta.ash?.fetched_utc)}</dd></dl>
        <p>各國航空氣象單位發布的火山灰 SIGMET（重要天氣資訊），由美國 NOAA 航空氣象中心彙整，屬於美國政府資料。資料站每天每隔 3 小時查一次當時有效的 SIGMET，用其中的火山位置對到 GVP 火山；有警報的那幾天（UTC）算這座火山有噴發，連續 2 天以上就標「噴發中」。少數 SIGMET 報的是殘留在空中的灰雲，不一定是當天新的噴發。</p>${err(meta.ash)}</div>
      <div class="src"><h3><span class="dot8" style="background:${Object.values(meta.levels || {}).some((x) => x.error) ? '#D97706' : '#2F9E44'}"></span>各國官方警戒等級</h3>
        <dl>${Object.entries(AGENCY).map(([k, n]) => { const x = meta.levels?.[k] || {}; return `<dt>${esc(n)}</dt><dd class="num">${x.fetched_utc ? `${x.count} 座、${x.elevated} 座高於平常・${utc(x.fetched_utc)}` : '尚未抓取'}</dd>`; }).join('')}</dl>
        <p>日本氣象廳（噴火警戒等級，出典：気象庁ホームページ，本站翻譯整理）、菲律賓 PHIVOLCS（公報頁的 Alert Level）、紐西蘭 GeoNet（Volcanic Alert Level，CC BY 3.0 NZ）。高於各機構平常等級的（日本 2 級以上或「火口周邊危險」等警報、菲律賓與紐西蘭 1 級以上）跟 USGS HANS 一樣算「警戒升高」。各國等級制度不同，不能直接比較。印尼 MAGMA、堪察加 KVERT 等網站不開放程式讀取，沒有列入。</p>
        ${Object.entries(meta.levels || {}).filter(([, x]) => x.error).map(([k, x]) => `<p class="warn">${esc(AGENCY[k] || k)} 最近一次抓取失敗（${utc(x.error_utc)}）：${esc(x.error)}，目前顯示上一份資料。</p>`).join('')}</div>
      <div class="src"><h3><span class="dot8" style="background:${COL.claude}"></span>${c.feed_utc ? 'Claude 補充（V1 火山活動日報）' : 'Claude 網路搜尋補充'}</h3>
        <dl><dt>${c.feed_utc ? '補充檔' : '執行'}</dt><dd class="num">${utc(c.feed_utc || c.run_utc || c.error_utc)}</dd><dt>狀態</dt><dd>${c.status === 'ok' || c.status === 'stale' ? `保留 ${c.kept} 筆、丟棄 ${c.dropped} 筆` : c.status === 'skipped' ? '已跳過' : c.status === 'failed' ? '失敗' : '尚未執行'}</dd></dl>
        <p>${c.feed_utc ? '由 V1 火山活動日報以 Claude API 網路搜尋產生（另有一區只搜國際與各國重要媒體），官方來源已涵蓋的火山不另外列出。' : ''}屬於網路來源、未經官方確認，每筆都附來源連結，僅供參考。</p>${c.error ? `<p class="warn">${esc(c.error)}</p>` : ''}</div>
      <div class="src"><h3><span class="dot8" style="background:#5A6170"></span>地形：AWS Terrain Tiles</h3>
        <p>${esc(api?.terrainNote || '')}</p><ul>${TERRAIN_CREDITS.map((t) => `<li lang="en">${esc(t)}</li>`).join('')}</ul></div>
      ${api?.geo ? `<div class="src"><h3><span class="dot8" style="background:#7048E8"></span>板塊邊界、地震、國界與國名</h3>
        <p>板塊邊界：Bird (2003) PB2002 的 52 個板塊，依每一小段的類型分成張裂、隱沒、碰撞與其他聚合、錯動 4 類；Hugo Ahlenius（Nordpil）轉成 GeoJSON 的版本，ODC-By 1.0。</p>
        <p>地震：美國地質調查所（USGS）ANSS 地震目錄（ComCat），1976 年起規模 5.5 以上，顏色是震源深度、大小是規模。</p>
        <p>國界：Natural Earth 1:10m 陸地國界（公有領域），有爭議或未定的界線畫虛線；國名用 Natural Earth 的繁體中文名稱並改成台灣用語。</p>
        <p>都由資料站整理好放在專案裡（vendor/geo/），離線也能用；要更新時在資料站重跑 <code>python3 tools/make_geo.py</code>，地震目錄建議每年更新一次。在地圖左上的「圖層」選單開關。</p></div>` : ''}
      ${TEACH ? `<div class="src"><h3><span class="dot8" style="background:#0CA678"></span>教學模式</h3>
        <p>火山成因的說明與剖面示意圖在專案裡的 teach.json 與 teach.js，選了 13 座代表性的火山。${TEACH.checked ? '內容已人工校對。' : '內容由 Claude 起草，尚未人工校對。'}</p></div>` : ''}
      <div class="src"><h3><span class="dot8" style="background:#2F4FC4"></span>星空背景（全球視角）</h3>
        <p>Yale Bright Star Catalogue 第 5 版（Hoffleit &amp; Warren, 1991）約 9,100 顆肉眼可見的星，取自 SAO Telescope Data Center。依這台電腦的時間計算格林威治平恆星時，把星空轉到跟地球對應的位置，所以會隨時刻與季節改變。</p>
        <p>銀河（設定頁可選樣式）：「真實銀河」是 NASA/Goddard Space Flight Center Scientific Visualization Studio 的 Deep Star Maps 2020（公有領域），Gaia DR2: ESA/Gaia/DPAC，本站調整亮度與方向；「星塵光帶」由 d3-celestial 的銀河輪廓產生，暗帶與紋理是模擬的，星點依銀河亮度隨機撒上。</p>
        <p>星座連線與中文名：d3-celestial（Olaf Frohn，BSD-3-Clause）。太陽、月亮與行星的位置依這台電腦的時間計算：行星用 JPL 行星近似軌道根數（Standish &amp; Williams, 1992），月亮用天文年曆的低精度公式，與 JPL Horizons 比對誤差約 0.1°；月亮不畫圓缺。</p>
        <p>只在待機模式（一段時間沒人操作）顯示；星星、銀河、太陽月亮與行星、星座可以在地圖左上的「待機模式」選單各自開關。</p>
        <p>地球的白天與黑夜（同一個選單開關）：依這台電腦的時間算出太陽直射點，太陽在地平線下的半球變暗，晨昏線到太陽在地平線下 18°（天文曙暮光）之間是漸層；拉近看火山時淡出。跟星空裡畫的太陽位置一致。</p></div>
      ${creditsHTML()}
    </div>`;
  }

  function renderPanel() {
    $('#pbody').innerHTML = { overview: overviewHTML, activity: activityHTML, list: listHTML, sources: sourcesHTML, teach: teachHTML }[S.tab]();
  }

  $('#tabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    S.tab = b.dataset.tab;
    renderTabs();
    renderPanel();
    $('#pbody').scrollTop = 0;
  });
  $('#pbody').addEventListener('click', (e) => {
    const t = e.target.closest('[data-v], [data-filt], [data-act], [data-fold]');
    if (!t || e.target.closest('a')) return;
    if (t.dataset.v) return select(t.dataset.v);
    if (t.dataset.fold) S.open.has(t.dataset.fold) ? S.open.delete(t.dataset.fold) : S.open.add(t.dataset.fold);
    if (t.dataset.filt) { S.filt = t.dataset.filt; S.q = ''; $('#q').value = ''; S.limit = 150; }
    if (t.dataset.act === 'claude') S.allClaude = !S.allClaude;
    if (t.dataset.act === 'more') S.limit += 150;
    if (t.dataset.act === 'ring') return showRing();
    renderPanel();
  });
  $('#pbody').addEventListener('change', (e) => {
    if (e.target.id === 'win') S.win = +e.target.value;
    if (e.target.id === 'country') { S.country = e.target.value; S.limit = 150; }
    renderPanel();
  });
  $('#q').addEventListener('input', (e) => {
    S.q = e.target.value;
    S.limit = 150;
    if (S.tab !== 'list') { S.tab = 'list'; renderTabs(); }
    renderPanel();
  });

  // ---- 待機模式：一段時間沒人操作就回到全球、慢慢轉動、打開星空；有人操作時停下來，把台灣轉到正中間 ----
  // 待機時間在地圖左上的「待機模式」選單設定（瀏覽器會記住，預設 3 分鐘）；網址加 ?idle=秒數 可以暫時覆寫（測試用）
  const IDLE_KEY = 'volcano-pulse.idle';
  const IDLE_OPTS = [[1, '1 分鐘'], [3, '3 分鐘'], [5, '5 分鐘'], [10, '10 分鐘'], [30, '30 分鐘'], [0, '不待機']];
  let idleMin = 3;
  try { const m = localStorage.getItem(IDLE_KEY); if (m !== null && IDLE_OPTS.some(([n]) => n === +m)) idleMin = +m; } catch { /* 讀不到就用預設 */ }
  const urlIdle = +new URLSearchParams(location.search).get('idle');
  const idleMs = () => (urlIdle > 0 ? urlIdle * 1000 : idleMin * 60000);
  const TAIWAN = { key: 'world', lat: 23.7, lon: 121 };
  const still = matchMedia('(prefers-reduced-motion: reduce)').matches;  // 系統設定減少動態時只回到全球、不轉
  let idle = false, idleTimer = 0, spinTimer = 0, lastPoke = 0;
  // 地球的白天與黑夜：跟星空一樣只在待機時顯示（開關在待機背景）
  const syncNight = () => api?.night?.(idle && !!api.stars?.get('night'));

  // 待機導覽：自轉時十年火山或昨天噴發的火山轉到畫面中間的南北線上，就飛過去停 10 秒、打開詳細卡，再飛回全球接著轉。
  // 兩個開關與每座停留秒數在待機選單，開關預設都關、停留預設 10 秒，瀏覽器會記住
  const TOUR_KEY = 'volcano-pulse.tour';
  const TOUR = [['dec', '十年火山介紹'], ['yday', '噴發中與昨天噴發火山介紹']];
  const TOUR_SECS = [5, 10, 15, 20, 30];
  const tour = { dec: false, yday: false, secs: 10 };
  try {
    const t = JSON.parse(localStorage.getItem(TOUR_KEY) || '{}');
    for (const [k] of TOUR) if (typeof t[k] === 'boolean') tour[k] = t[k];
    if (TOUR_SECS.includes(t.secs)) tour.secs = t.secs;
  } catch { /* 讀不到就用預設 */ }
  const saveTour = () => { try { localStorage.setItem(TOUR_KEY, JSON.stringify(tour)); } catch { /* 存不了就只在這次有效 */ } };
  const flyMs = () => api?.flyMs ?? 1800;  // 鏡頭飛行時間由地圖決定
  const wrap = (d) => ((d % 360) + 540) % 360 - 180;
  const tourSkip = new Set();  // 跟剛介紹過的火山很近、這一圈不再停的火山
  let tourWatch = 0, tourTimer = 0, touring = null;
  const stopTour = () => { clearInterval(tourWatch); clearTimeout(tourTimer); };
  // 每 0.25 秒比較畫面中心的經度：地球往東轉（中心經度變小），火山從中線西側跑到東側就算經過
  const watchTour = () => {
    const list = vols.filter((v) => (tour.dec && v.dec) || (tour.yday && (v.s === 'erupt_yday' || v.s === 'erupt_now')));
    if (!list.length || !api.center) return;
    let prev = api.center().lng;
    tourWatch = setInterval(() => {
      const now = api.center().lng;
      const crossed = list.filter((x) => wrap(x.lon - prev) <= 0 && wrap(x.lon - now) > 0);
      prev = now;
      const v = crossed.find((x) => !tourSkip.has(x.vnum));
      crossed.forEach((x) => tourSkip.delete(x.vnum));
      if (!v) return;
      // 很近的火山只停一次（例如 Avachinsky 與 Koryaksky 只差 0.1°）
      list.forEach((x) => { if (x !== v && !crossed.includes(x) && Math.hypot(x.lat - v.lat, wrap(x.lon - v.lon)) < 0.5) tourSkip.add(x.vnum); });
      showTour(v);
    }, 250);
  };
  const showTour = (v) => {
    stopTour();
    api.spin?.(false);
    // 飛回全球時回到剛好越過這座火山的經度接著轉：轉得快時同一次檢查可能經過好幾座，其他還沒停的才不會被跳過
    touring = { lat: api.center().lat, lng: v.lon - 0.01 };
    select(v.vnum);  // 打開詳細卡、圖釘標成選取、飛過去
    tourTimer = setTimeout(() => {
      const c = touring;
      touring = null;
      closeCard();
      S.region = 'world';
      renderRegions();
      api.region({ key: 'world', lat: c.lat, lon: c.lng });
      tourTimer = setTimeout(() => { api.spin?.(true); watchTour(); }, flyMs());
    }, flyMs() + tour.secs * 1000);
  };

  const goIdle = () => {
    if (!api) return;
    idle = true;
    // 收掉所有多餘的視窗：直播播放視窗、選單、詳細卡；面板回到概況最上面
    if (!$('#yt').hidden) closeYT();
    closeExt();
    toggleHelp(false);
    $('#quitp').hidden = true;
    togglePal(false);
    toggleIdle(false);
    toggleGeo(false);
    toggleTeach(false);
    closeCard();
    if (S.tab !== 'overview') { S.tab = 'overview'; renderTabs(); renderPanel(); }
    $('#pbody').scrollTop = 0;
    S.region = 'world';
    renderRegions();
    api.region(REGIONS[0]);
    api.stars?.show(true);
    syncNight();
    // 等飛回全球的動畫結束再轉；轉動當成鏡頭繞著地球飛，星空跟著換成那一面背後此刻真實的天空
    stopTour();
    tourSkip.clear();
    spinTimer = setTimeout(() => { if (!still) { api.spin?.(true); watchTour(); } }, flyMs());
  };
  const wake = () => {
    idle = false;
    if (lay.teach) toggleTeach(true);  // 教學模式中：有人來操作就把教學火山選單叫出來
    clearTimeout(spinTimer);
    stopTour();
    api.spin?.(false);
    api.stars?.show(false);
    syncNight();
    // 導覽停留中有人來操作：留在這座火山、卡片不關，讓人接著看
    if (touring) { touring = null; return; }
    api.region(TAIWAN);
  };
  const poke = () => {
    const now = Date.now();
    if (idle) wake();
    else if (now - lastPoke < 1000) return;  // 滑鼠移動很頻繁，一秒內只重設一次計時
    lastPoke = now;
    clearTimeout(idleTimer);
    if (idleMs()) idleTimer = setTimeout(goIdle, idleMs());
  };
  const SKY = [['stars', '星星'], ['mw', '銀河'], ['planets', '太陽、月亮與行星'], ['lines', '星座連線與名稱'], ['night', '地球的白天與黑夜']];
  function renderIdle() {
    $('#idlemenu').innerHTML = '<div class="palmenu-h">待機時間</div><p class="idle-note">沒人操作多久後回到全球、慢慢轉動；有人操作時停下來，台灣轉到正中間</p>'
      + IDLE_OPTS.map(([n, l]) => `<button type="button" role="menuitemradio" aria-checked="${n === idleMin}" data-idle="${n}">${l}</button>`).join('')
      + (api?.stars ? '<div class="palmenu-h" style="margin-top:4px">待機背景</div>' + SKY.map(([k, l]) => `<button type="button" role="menuitemcheckbox" aria-checked="${api.stars.get(k)}" data-sky="${k}">${l}<span class="idle-on">${api.stars.get(k) ? '開' : '關'}</span></button>`).join('') : '')
      + '<div class="palmenu-h" style="margin-top:4px">待機導覽</div><p class="idle-note">轉到這些火山時飛過去停一下，打開詳細資料</p>'
      + TOUR.map(([k, l]) => `<button type="button" role="menuitemcheckbox" aria-checked="${tour[k]}" data-tour="${k}">${l}<span class="idle-on">${tour[k] ? '開' : '關'}</span></button>`).join('')
      + '<div class="palmenu-h" style="margin-top:4px">每座停留</div><div class="tsecs">'
      + TOUR_SECS.map((n) => `<button type="button" role="menuitemradio" aria-checked="${n === tour.secs}" data-tsec="${n}">${n} 秒</button>`).join('') + '</div>';
  }
  function toggleIdle(open) {
    if (open) { renderIdle(); togglePal(false); toggleGeo(false); }
    $('#idlemenu').hidden = !open;
    $('[data-act="idle"]')?.setAttribute('aria-expanded', String(open));
    showTeach();
  }
  $('#idlemenu').addEventListener('click', (e) => {
    const b = e.target.closest('[data-idle], [data-sky], [data-tour], [data-tsec]');
    if (!b) return;
    // 選單重畫後被點的按鈕已經不在畫面上，不擋住的話外層會當成點在選單外而關閉
    if (b.dataset.sky) { e.stopPropagation(); api.stars.toggle(b.dataset.sky); syncNight(); renderIdle(); $(`#idlemenu [data-sky="${b.dataset.sky}"]`).focus(); return; }
    if (b.dataset.tour || b.dataset.tsec) {
      e.stopPropagation();
      if (b.dataset.tour) tour[b.dataset.tour] = !tour[b.dataset.tour];
      else tour.secs = +b.dataset.tsec;
      saveTour();
      renderIdle();
      $(`#idlemenu [data-${b.dataset.tour ? 'tour' : 'tsec'}="${b.dataset.tour || b.dataset.tsec}"]`).focus();
      return;
    }
    idleMin = +b.dataset.idle;
    try { localStorage.setItem(IDLE_KEY, String(idleMin)); } catch { /* 存不了就只在這次有效 */ }
    toggleIdle(false);
    lastPoke = 0;
    poke();
  });
  document.addEventListener('click', (e) => { if (!e.target.closest('#idlemenu, [data-act="idle"]')) toggleIdle(false); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggleIdle(false); });
  ['pointerdown', 'pointermove', 'wheel', 'keydown', 'touchstart'].forEach((ev) => window.addEventListener(ev, poke, { capture: true, passive: true }));
  poke();

  // ---- 設定頁：可以調整的參數都集中在這裡；時鐘與配色選單照舊保留，兩邊改的是同一份設定 ----
  const SPIN_OPTS = [2, 3, 4, 6, 8], FLY_OPTS = [1.5, 2, 3, 4, 5];
  const MW_STYLES = [['nasa', '真實銀河'], ['glow', '星塵光帶'], ['both', '真實銀河加星塵']];
  const IDLE_DEF = 3, SKY_DEF = { stars: true, mw: true, planets: true, lines: false, night: true, style: 'nasa' }, TOUR_DEF = { dec: false, yday: false, secs: 10 };
  const X_SVG = '<svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M3 3 L11 11 M11 3 L3 11" stroke="#14171C" stroke-width="1.8" stroke-linecap="round"/></svg>';
  const saveMotion = () => { try { localStorage.setItem(MOTION_KEY, JSON.stringify(motion)); } catch { /* 存不了就只在這次有效 */ } };
  const saveIdle = () => { try { localStorage.setItem(IDLE_KEY, String(idleMin)); } catch { /* 存不了就只在這次有效 */ } };
  const chip = (set, v, on, label) => `<button type="button" class="chip" data-set="${set}" data-v="${v}" aria-pressed="${on}">${label}</button>`;
  const swt = (set, k, on, label) => `<button type="button" class="sw-row" data-set="${set}" data-v="${k}" role="switch" aria-checked="${on}"><span>${label}</span><span class="idle-on">${on ? '開' : '關'}</span></button>`;
  const row = (label, note, body) => `<div class="set-row"><div class="set-l"><b>${label}</b>${note ? `<span>${note}</span>` : ''}</div><div class="set-v">${body}</div></div>`;
  const custom = (k, unit) => `<label class="custom">自訂<input type="number" data-custom="${k}" min="${MOTION_RANGE[k][0]}" max="${MOTION_RANGE[k][1]}" step="${k === 'flySec' ? 0.1 : 0.5}" value="${motion[k]}" inputmode="decimal">${unit}</label>`;
  // 設定分成幾個分頁，一頁放得下；分頁只記在這次載入，打開設定時停在上次看的那一頁
  const SET_TABS = [['idle', '待機'], ['cam', '鏡頭'], ['layer', '圖層與教學'], ['pal', '地形配色']];
  let setTab = 'idle';
  function renderSettings() {
    const tabs = SET_TABS.filter(([k]) => (k === 'layer' ? layerList().length : k === 'pal' ? !!api?.palettes : true));
    if (!tabs.some(([k]) => k === setTab)) setTab = tabs[0][0];
    const body = {
      idle: () => `
        ${row('待機時間', '沒人操作多久後回到全球、慢慢轉動', IDLE_OPTS.map(([n, l]) => chip('idle', n, n === idleMin, l)).join(''))}
        ${row('自轉速度', `轉一圈幾分鐘，數字越大越慢；自訂 ${MOTION_RANGE.spinMin.join(' 到 ')} 分鐘`, SPIN_OPTS.map((n) => chip('spinMin', n, n === motion.spinMin, `${n} 分鐘`)).join('') + custom('spinMin', '分鐘一圈'))}
        <h3>待機導覽</h3>
        <div class="set-sw">${TOUR.map(([k, l]) => swt('tour', k, tour[k], l)).join('')}</div>
        ${row('每座停留', '轉到火山時飛過去停留的時間', TOUR_SECS.map((n) => chip('tsec', n, n === tour.secs, `${n} 秒`)).join(''))}
        ${api?.stars ? `<h3>待機背景</h3><div class="set-sw">${SKY.map(([k, l]) => swt('sky', k, api.stars.get(k), l)).join('')}</div>
          ${row('銀河樣式', '真實銀河是 NASA 用 Gaia 巡天資料做的全天圖；星塵光帶由銀河輪廓產生，暗帶是模擬的', MW_STYLES.map(([k, l]) => chip('mwstyle', k, api.stars.get('style') === k, l)).join(''))}` : ''}`,
      cam: () => `
        ${row('飛向與飛回', `點火山、切換區域、進出待機與待機導覽時，鏡頭飛行的時間；自訂 ${MOTION_RANGE.flySec.join(' 到 ')} 秒`, FLY_OPTS.map((n) => chip('flySec', n, n === motion.flySec, `${n} 秒`)).join('') + custom('flySec', '秒'))}
        ${api?.nearRange ? row('拉近程度', `點火山與待機導覽時拉多近（縮放級數，越大越近，越近越傾斜）；自訂 ${MOTION_RANGE.near.join(' 到 ')} 級`, NEAR_OPTS.map(([n, l]) => chip('near', n, n === motion.near, `${l} ${n}`)).join('') + custom('near', '級')) : ''}
        ${api?.sat || api?.hidem ? `<div class="set-sw">${api?.sat ? swt('sat', 'sat', motion.sat, '衛星影像（拉近時顯示，需要網路）') : ''}${api?.hidem ? swt('hidem', 'hidem', motion.hidem, '高解析地形（需要網路，部分地區有方塊色差）') : ''}</div>` : ''}`,
      layer: () => `<div class="set-sw">${layerList().map(([k, l]) => swt('layer', k, lay[k], l)).join('')}</div>
        ${TEACH ? '<p class="muted">教學模式打開時會一起打開板塊邊界，地圖左邊跳出教學火山選單；選單上的 ✕ 或「結束教學模式」可以關閉。</p>' : ''}`,
      pal: () => `<div class="set-v">${api.palettes.map((p) => chip('pal', p.key, p.key === api.palette,
          `<span class="sw">${p.swatch.map((c) => `<i style="background:${c}"></i>`).join('')}</span>${esc(p.label)}`)).join('')}</div>`,
    }[setTab]();
    $('#setp').innerHTML = `<div class="setp-box" role="dialog" aria-modal="true" aria-labelledby="setp-title">
      <div class="setp-head"><div><h2 id="setp-title">設定</h2><span class="muted">改了馬上生效，這台電腦的瀏覽器會記住</span></div>
        <button class="close" type="button" data-set="close" aria-label="關閉設定">${X_SVG}</button></div>
      <div class="tabs setp-tabs">${tabs.map(([k, l]) => `<button type="button" data-set="tab" data-v="${k}" aria-pressed="${k === setTab}">${l}</button>`).join('')}</div>
      <div class="setp-body">${body}</div>
      <div class="setp-foot"><button type="button" class="linkbtn" data-set="reset">恢復預設值</button><span class="muted">v${VERSION}${gpu() ? `・顯示卡 ${esc(gpu())}` : ''}${AUTO_3D ? '・3D 地形在這台電腦顯示不出來，已自動換成地形貼圖' : api?.flat ? '・3D 起伏已自動關閉' : ''}</span></div></div>`;
  }
  // 設定頁最下面顯示顯示卡名稱：3D 地形在某台電腦顯示不出來時，拍設定頁就知道是哪張顯示卡，不用開 F12
  let gpuName;
  function gpu() {
    if (gpuName === undefined) {
      gpuName = '';
      try {
        const c = document.createElement('canvas'), gl = c.getContext('webgl2') || c.getContext('webgl');
        const ext = gl.getExtension('WEBGL_debug_renderer_info');
        gpuName = String(gl.getParameter(ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER) || '');
        gl.getExtension('WEBGL_lose_context')?.loseContext();
      } catch { /* 拿不到就不顯示 */ }
    }
    return gpuName;
  }
  function toggleSet(open) {
    if (open) { toggleIdle(false); togglePal(false); toggleGeo(false); renderSettings(); }
    $('#setp').hidden = !open;
    if (open) $('#setp [data-set="close"]').focus();
  }
  $('#setp').addEventListener('click', (e) => {
    if (e.target.id === 'setp') return toggleSet(false);  // 點面板外面
    const b = e.target.closest('[data-set]');
    if (!b) return;
    const k = b.dataset.set, v = b.dataset.v;
    if (k === 'close') return toggleSet(false);
    if (k === 'tab') setTab = v;
    if (k === 'idle') { idleMin = +v; saveIdle(); lastPoke = 0; poke(); }
    if (k === 'spinMin' || k === 'flySec' || k === 'near') { motion[k] = +v; saveMotion(); api?.motion?.(motion); }
    if (k === 'sat' || k === 'hidem') { motion[k] = !motion[k]; saveMotion(); api?.motion?.(motion); }
    if (k === 'sky') { api.stars.toggle(v); syncNight(); }
    if (k === 'mwstyle') api.stars.style(v);
    if (k === 'layer') {
      if (v === 'teach' && !lay.teach) toggleSet(false);  // 打開教學模式：關掉設定頁，直接看到跳出來的教學火山選單
      setLayer(v, !lay[v]).then(() => { if (!$('#setp').hidden) renderSettings(); });
    }
    if (k === 'tour') { tour[v] = !tour[v]; saveTour(); }
    if (k === 'tsec') { tour.secs = +v; saveTour(); }
    if (k === 'pal') { api.setPalette(v); renderPal(); }
    if (k === 'reset') {
      idleMin = IDLE_DEF; saveIdle(); lastPoke = 0; poke();
      Object.assign(motion, MOTION_DEF); saveMotion(); api?.motion?.(motion);
      if (api?.stars) { for (const [s] of SKY) if (api.stars.get(s) !== SKY_DEF[s]) api.stars.toggle(s); api.stars.style(SKY_DEF.style); syncNight(); }
      Object.assign(tour, TOUR_DEF); saveTour();
      for (const [l] of LAYERS) if (lay[l] !== LAYER_DEF[l]) setLayer(l, LAYER_DEF[l]);
      if (api?.palettes) { api.setPalette(api.palettes[0].key); renderPal(); }
    }
    renderSettings();
    $(`#setp [data-set="${k}"]${v != null ? `[data-v="${v}"]` : ''}`)?.focus();  // 重畫後焦點留在剛按的按鈕
  });
  // 自訂數字：按 Enter 或離開輸入框時套用；超出範圍就恢復成目前的值
  $('#setp').addEventListener('change', (e) => {
    const k = e.target.dataset?.custom;
    if (!k) return;
    const v = Math.round(+e.target.value * 10) / 10;
    if (okMotion(k, v)) { motion[k] = v; saveMotion(); api?.motion?.(motion); }
    renderSettings();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') toggleSet(false); });

  // ---- 使用說明與問題回報（v0.19.16）；視窗版另有全螢幕與離開 ----
  const dpr = Math.round(devicePixelRatio * 100) / 100;
  const diag = () => [`v${VERSION}`, `${cfg.variant}${AUTO_3D ? ' auto3d' : api?.flat ? ' flat' : ''}`, WIN ? 'window' : 'kiosk', `GPU ${gpu().slice(0, 100) || '?'}`,
    `screen ${screen.width}x${screen.height}@${dpr}`, `view ${innerWidth}x${innerHeight}`,
    (navigator.userAgent.match(/(Edg|Chrome|Firefox|Version)\/[\d.]+/) || ['?'])[0], navigator.platform, `${new Date().toISOString().slice(0, 16)}Z`].join(' | ');
  function helpHTML() {
    const btns = [['in', 'plus', '放大'], ['out', 'minus', '縮小'], ['tilt', 'tilt', '切換傾斜視角'], ['north', 'north', '回到正北、俯視'],
      ['idle', 'clock', '待機模式：沒人操作多久後自己轉，也可以開關待機背景與導覽'], ['pal', 'layers', '地形配色'],
      ['geo', 'globe', '圖層與教學：板塊邊界、地震、教學模式'], ['set', 'gear', '設定：待機、鏡頭、圖層等，這台電腦會記住']]
      .filter(([act]) => $(`#ctrl [data-act="${act}"]`));
    return `<div class="setp-box help-box" role="dialog" aria-modal="true" aria-labelledby="help-title">
      <div class="setp-head"><div><h2 id="help-title">使用說明</h2><span class="muted">全球火山的活動狀態，資料每天更新</span></div>
        <button class="close" type="button" data-help="close" aria-label="關閉使用說明">${X_SVG}</button></div>
      <div class="setp-body help">
        <h3>看地圖</h3>
        <ul><li>${esc(api?.hint || '拖曳旋轉・滾輪縮放')}</li>
          <li>地圖上方的區域按鈕（全球、東亞…）直接飛到那一區</li>
          <li>點火山圖釘打開詳細資料：狀態、警戒等級、近期活動、直播影像</li>
          <li>圖釘顏色的意思看地圖上的圖例</li></ul>
        <h3>右側面板</h3>
        <ul><li><b>概況</b>：現在值得注意的火山，例如噴發中、警戒中</li>
          <li><b>活動</b>：近期的活動紀錄，可以選時間範圍</li>
          <li><b>火山</b>：全部火山清單，最上面的搜尋框可以用中英文名稱或國家找</li>
          <li><b>來源</b>：資料出處與更新時間</li></ul>
        ${btns.length ? `<h3>地圖左上角的按鈕</h3><ul class="help-btns">${btns.map(([, k, t]) => `<li><span class="hico">${svgI(k)}</span>${t}</li>`).join('')}</ul>` : ''}
        <h3>其他</h3>
        <ul><li>${idleMin ? `${idleMin} 分鐘沒人操作就回到全球慢慢轉動；有人操作就停下來，台灣轉到正中間` : '目前設定成不待機'}</li>
          <li>外部網站不在這裡開啟，會顯示 QR code，用手機掃描看</li>
          <li>Esc 鍵可以關閉選單和小視窗</li>
          ${WIN ? '<li>右上角「全螢幕」切換全螢幕，「離開」關閉視窗和本機伺服器；不是全螢幕時，視窗可以拖到其他螢幕、拖拉邊緣調整大小、縮到工作列</li>' : ''}</ul>
        <h3>問題回報</h3>
        <p>${REPORT_FORM ? '畫面不正常或資料有誤，請用手機掃描 QR code 填寫回報表單，這台電腦的系統資訊會自動附上。' : '回報表單還沒設定。請把問題和下面的系統資訊拍照，傳給管理者。'}</p>
        ${REPORT_FORM ? '<button type="button" class="ext-back" data-help="report">回報問題</button>' : ''}
        <p class="diag">${esc(diag())}</p>
      </div></div>`;
  }
  function toggleHelp(open) {
    const was = !$('#helpp').hidden;
    if (open) { toggleIdle(false); togglePal(false); toggleGeo(false); toggleSet(false); $('#helpp').innerHTML = helpHTML(); }
    $('#helpp').hidden = !open;
    if (open) $('#helpp [data-help="close"]').focus();
    else if (was) $('#help').focus();
  }
  $('#help').addEventListener('click', () => toggleHelp(true));
  $('#helpp').addEventListener('click', (e) => {
    if (e.target.id === 'helpp') return toggleHelp(false);  // 點面板外面
    const b = e.target.closest('[data-help]');
    if (b?.dataset.help === 'close') toggleHelp(false);
    if (b?.dataset.help === 'report') {
      const a = Object.assign(document.createElement('a'), { href: REPORT_FORM.replace('DIAG', encodeURIComponent(diag())), textContent: '問題回報' });
      openExt(a, { lead: '用手機掃描 QR code 填寫問題回報', note: '表單裡的「系統資訊」已經自動填好，不用修改。', back: b });
    }
  });
  // 先於其他 Esc 處理（capture）：QR code 小視窗開著時只關它，說明留著
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape' || !$('#ext').hidden) return;
    toggleHelp(false);
    $('#quitp').hidden = true;
  }, true);

  if (WIN) {
    const full = $('#full');
    full.addEventListener('click', () => (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen()).catch(() => {}));
    document.addEventListener('fullscreenchange', () => { full.textContent = document.fullscreenElement ? '結束全螢幕' : '全螢幕'; });
    $('#quit').addEventListener('click', () => { $('#quitp').hidden = false; $('#quitp [data-quit="no"]').focus(); });
    $('#quitp').addEventListener('click', (e) => {
      const k = e.target.closest('[data-quit]')?.dataset.quit;
      if (e.target.id === 'quitp' || k === 'no') { $('#quitp').hidden = true; $('#quit').focus(); }
      if (k !== 'yes') return;
      const stopped = fetch('quit', { method: 'POST', keepalive: true }).then((r) => r.ok, () => false);
      window.close();
      // 還在：瀏覽器不讓網頁關視窗，請人自己關
      setTimeout(async () => {
        $('#quit-msg').textContent = (await stopped)
          ? '本機伺服器已經關閉，但瀏覽器不讓網頁自己關掉視窗。請按視窗角落的 ✕ 關閉（Mac 是左上角的紅點）。'
          : '關不掉本機伺服器。請按視窗角落的 ✕ 關閉視窗；Windows 工作列上的「Volcano server」視窗也要關掉。';
        $('#quitp .quit-act').innerHTML = '<button type="button" class="hbtn" data-quit="no">知道了</button>';
      }, 800);
    });
  }

  // ---- 資料自動更新：資料站每天發布一次，但網頁開著不會自己重讀，所以每 30 分鐘問一次線上資料包 ----
  // 有新資料或 UTC 換日（「昨天噴發」要跟著換）時，趁待機中或 2 分鐘沒人操作重新載入網頁；待機中重新載入後直接回到待機
  const RESUME_KEY = 'volcano-pulse.resume-idle';
  const CHECK_MS = 30 * 60000, QUIET_MS = 2 * 60000;
  const day0 = daysAgo(0);
  let pending = false, lastCheck = Date.now(), busy = false;
  // 資料沒變時 GitHub 只回 304，幾乎不用流量
  const checkNew = async () => {
    const json = (u, o) => fetch(u, o).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    const c = await json('config.json', { cache: 'no-store' });
    if (!c?.bundle_url) return 'none';
    const b = await json(c.bundle_url, { cache: 'no-cache', signal: AbortSignal.timeout(8000) });
    if (b?.schema !== 1 || !b.meta?.updated_utc) return 'fail';
    return b.meta.updated_utc > (meta.updated_utc || '') ? 'new' : 'same';
  };
  const reload = () => {
    try { if (idle) sessionStorage.setItem(RESUME_KEY, '1'); } catch { /* 存不了就照一般方式開 */ }
    location.reload();
  };
  setInterval(async () => {
    if (!pending && daysAgo(0) !== day0) pending = true;
    if (!pending && !busy && Date.now() - lastCheck >= CHECK_MS) { lastCheck = Date.now(); pending = (await checkNew()) === 'new'; }
    if (pending && (idle || Date.now() - lastPoke >= QUIET_MS)) reload();
  }, 60000);
  // 手動更新：頁首更新時間旁的按鈕，有新資料就馬上重新載入，沒有就在更新時間的位置顯示結果 4 秒
  const fresh0 = $('#fresh').innerHTML;
  $('#refresh').addEventListener('click', async () => {
    if (busy) return;
    busy = true;
    $('#refresh').classList.add('busy');
    const r = await checkNew();
    lastCheck = Date.now();
    if (r === 'new' || pending) { reload(); return; }
    $('#refresh').classList.remove('busy');
    $('#fresh').innerHTML = `<span role="status">${{ same: '已是最新資料', fail: '連不上資料站，繼續使用目前的資料', none: '沒有設定線上資料包' }[r]}</span>`;
    setTimeout(() => { $('#fresh').innerHTML = fresh0; busy = false; }, 4000);
  });
  try {
    if (sessionStorage.getItem(RESUME_KEY)) { sessionStorage.removeItem(RESUME_KEY); clearTimeout(idleTimer); goIdle(); }
  } catch { /* 讀不到就照一般方式開 */ }

  renderRegions();
  renderTabs();
  renderPanel();
  for (const [k] of LAYERS) if (k !== 'teach' && lay[k]) setLayer(k, true);  // 上次打開的圖層
  if (lay.teach && !idle) toggleTeach(true);
}
