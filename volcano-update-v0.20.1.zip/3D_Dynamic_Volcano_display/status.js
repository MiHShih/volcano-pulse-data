// 狀態判定與本日關注（v0.19.18 從 app.js 拆出來）：只看資料包與基準時間 T0，不碰畫面，也不看這台電腦的時鐘。
// T0 是資料時間（meta.updated_utc），「昨天」「最近 7 天」「本日關注」都從資料時間往回算，所以展示機的時鐘怎麼走、資料停更多久，
// 畫面都停在最後一份資料包算出來的狀態（v0.19.17 以前用展示機時鐘：每天 UTC 換日到新資料包發布前「噴發中」會歸零）。
// app.js 與 tools/test_status.mjs 共用，改規則時跑 node --test tools/test_status.mjs

// 固定標示的火山：大屯火山群（TVO 監測的火山），比照十年火山一直顯示圖釘與名稱
export const HOME = new Set([281032]);
export const ORDER = ['erupt_now', 'alert', 'erupt_yday', 'erupt_off', 'erupt_unv', 'weekly', 'claude', 'none'];
// 各國官方警戒等級的機構（levels.json 的 agency），各國等級制度不同，不能直接比較
export const AGENCY = { JMA: '日本氣象廳', PHIVOLCS: '菲律賓 PHIVOLCS', GeoNet: '紐西蘭 GeoNet' };
// 灰雲高度：SIGMET 用英呎，換成公尺取到百位
export const ashM = (ft) => `約 ${(Math.round(ft * 0.3048 / 100) * 100).toLocaleString('en-US')} 公尺`;
// 劇烈噴發：灰雲海拔 9 公里以上（民航機巡航高度），或比山頂高出 3 公里以上；本日關注與 30 天活動圖共用
export const isBigAsh = (ft, elev) => ft * 0.3048 >= 9000 || (elev != null && ft * 0.3048 - elev >= 3000);
export const md = (d) => d.slice(5, 10).replace('-', '/');
export const firstSentence = (t) => { const x = t.split(/(?<=[。！？])/)[0]; return x.length > 70 ? `${x.slice(0, 68)}…` : x; };
// 從 T0 往回 n 天的日期（UTC，YYYY-MM-DD）
export const daysFrom = (T0) => (n) => new Date(T0 - n * 864e5).toISOString().slice(0, 10);
// 基準時間：資料包的 meta.updated_utc；沒有或格式不對才用這台電腦的時鐘（頁首會顯示資料時間不明）
export const baseTime = (meta) => { const t = Date.parse(meta?.updated_utc); return Number.isFinite(t) ? t : Date.now(); };

// 每一列的必要欄位（v0.19.18）：展示端會直接拿來切字串、排序、畫位置，少了整個畫面會當掉的欄位，另外都要有整數的火山編號。
// 跟 publish.py 的 NEED（發布前檢查）用意相同，但以展示端實際用到的為準：多了火山的名稱、國家、座標與每日報告的 summary，
// 少了展示端用不到的 obs、daily 的 activity
const NEED = {
  volcanoes: { name: 'string', country: 'string', lat: 'number', lon: 'number' },
  alerts: { sent_utc: 'string' },
  activity: { date: 'string', source: 'string', title: 'string' },
  ash: { from: 'string', to: 'string' },
  levels: { label: 'string' },
  obs: { date: 'string', summary: 'string', hazards: 'array' },
  daily: { date: 'string' },
};
const isType = (v, t) => (t === 'array' ? Array.isArray(v) : t === 'number' ? Number.isFinite(v) : typeof v === t);
// 濾掉缺欄位的列：回傳留下的列與丟掉幾列（不是陣列就當成空的）
export function cleanRows(kind, rows) {
  const all = Array.isArray(rows) ? rows : [];
  const need = Object.entries(NEED[kind]);
  const good = all.filter((r) => Number.isInteger(r?.vnum) && need.every(([f, t]) => isType(r[f], t)));
  return { rows: good, dropped: all.length - good.length };
}

// 名稱對照、十年火山、中文簡介（資料包旁邊的 names.json、decade.json、intro.json）
export function nameTables(V, names, decade, intro) {
  // 名稱對照（key 是 GVP 編號）：name 取代英文名、zh 接在後面。有問題的筆數列在「來源」分頁
  const NAME = {}, ZH = {}, namesWarn = [];
  const gvpName = new Map(V.map((v) => [String(v.vnum), v.name]));
  const str = (x) => (typeof x === 'string' && x.trim() && x.length <= 60 ? x.trim() : '');
  for (const [k, x] of Object.entries(names.data?.volcanoes || {})) {
    if (!gvpName.has(k)) { namesWarn.push(`${k}（編號不在 GVP 資料）`); continue; }
    if (!x || typeof x !== 'object' || !(str(x.name) || str(x.zh))) { namesWarn.push(`${k}（沒有 name 或 zh）`); continue; }
    if (x.gvp && x.gvp !== gvpName.get(k)) namesWarn.push(`${k}（GVP 原名是 ${gvpName.get(k)}，不是 ${x.gvp}）`);
    if (str(x.name)) NAME[k] = str(x.name);
    if (str(x.zh)) ZH[k] = str(x.zh);
  }
  // 十年火山（decade.json）：GVP 編號 → 地圖上的常駐標籤「GVP 名稱 (通稱)」；名稱對照改過英文名時改用那個名稱
  const DECADE = {}, decadeWarn = [];
  for (const [k, x] of Object.entries(decade.data?.volcanoes || {})) {
    if (!gvpName.has(k)) { decadeWarn.push(`${k}（編號不在 GVP 資料）`); continue; }
    if (x?.gvp && x.gvp !== gvpName.get(k)) decadeWarn.push(`${k}（GVP 原名是 ${gvpName.get(k)}，不是 ${x.gvp}）`);
    DECADE[k] = str(x?.label) || gvpName.get(k);
  }
  // 中文簡介（intro.json）：GVP 地質摘要整理的 2 到 3 句中文；checked 為 true 表示人工校對過
  const INTRO = {};
  for (const [k, x] of Object.entries(intro.data?.volcanoes || {})) {
    if (gvpName.has(k) && typeof x?.zh === 'string' && x.zh.trim()) INTRO[k] = { zh: x.zh.trim(), checked: x.checked === true };
  }
  return { NAME, ZH, DECADE, INTRO, namesWarn, decadeWarn };
}

// ---- 本日關注火山：昨天與今天（UTC）有特別值得注意的事。一座火山放在最優先的理由那一組，其他理由當小標籤 ----
export const WATCH = [
  ['hazard', '火山災害', '火山造成人員傷亡、撤離、火山泥流、落灰影響生活、航班或設施受影響'],
  ['raise', '警戒提升', '官方 3 天內調高警戒等級'],
  ['big', '劇烈噴發', '灰雲衝到 9 公里以上（民航機巡航高度），或比山頂高出 3 公里以上'],
  ['new', '新噴發', '前 30 天沒有噴發紀錄後又噴發，或 GVP 週報列為新噴發活動'],
  ['news', '全球重大報導', '每日報告列為全球重大：新噴發、警戒變動、撤離或影響航空'],
  ['media', '媒體報導', '國際或各國重要媒體（通訊社、全國性報紙與電視台）有報導'],
  ['near', '鄰近台灣', '台灣、日本、菲律賓等鄰近島弧有新消息'],
];

// 每座火山的狀態、噴發清單、本日關注。data 是 loadData 讀到的資料（ash30 是 30 天的火山灰警報），names 是 nameTables 的結果
export function computeStatus({ V, alerts, activity, meta, ash30, levels, obs }, T0, { NAME, ZH, DECADE }) {
  const daysAgo = daysFrom(T0);
  // ash.json 從 v0.19.6 起保留 30 天（詳細卡的活動圖用）；噴發判斷與卡片上的警報清單照舊只看最近 7 天
  const ash = ash30.filter((a) => a.to >= `${new Date(T0 - 7 * 864e5).toISOString().slice(0, 19)}Z`);
  // ---- 狀態判定 ----
  const alertBy = new Map(alerts.map((a) => [a.vnum, a]));
  // 其他國家的官方警戒等級（JMA、PHIVOLCS、GeoNet）：高於各機構的平常等級，跟 HANS 一樣算「警戒升高」
  const lvlBy = new Map(levels.map((l) => [l.vnum, l]));
  const elevated = new Set([...alertBy.keys(), ...levels.filter((l) => l.elevated).map((l) => l.vnum)]);
  // 航空火山灰警報（各國火山灰 SIGMET，ash.json 已依時間新到舊）：警報生效的那一天（UTC）算這座火山有噴發。
  // 不用效期結束日：一則跨過午夜的警報不算兩天；持續噴發的火山每天都會有新的警報
  const ashBy = new Map();
  ash.forEach((a) => (ashBy.get(a.vnum) || ashBy.set(a.vnum, []).get(a.vnum)).push(a));
  const ashRecs = [...ashBy].flatMap(([vnum, list]) => [...new Set(list.map((a) => a.from.slice(0, 10)))].map((date) => {
    const same = list.filter((a) => a.from.slice(0, 10) === date);
    return { vnum, date, source: 'ash', agency: [...new Set(same.map((a) => a.fir))].join('、'), top_ft: Math.max(0, ...same.map((a) => a.top_ft || 0)) || null };
  }));
  const weekEnd = meta.rss?.report_end || '';
  const weekly = activity.filter((r) => r.source === 'rss' && r.date === weekEnd);
  const weeklySet = new Set(weekly.map((r) => r.vnum));
  const claude = activity.filter((r) => r.source === 'claude' && r.date >= daysAgo(30)).sort((a, b) => b.date.localeCompare(a.date));
  const claudeSet = new Set(claude.map((r) => r.vnum));
  // 7 天內噴發：官方週報（類別都是 Eruptive Activity，日期為報告期間最後一天）、航空火山灰警報，或 Claude 判定為噴發的補充
  // 同一天先列官方的火山灰警報，再來週報、Claude。最近 7 天有火山灰警報的火山以官方為準，不用 Claude 的報導判斷噴發日
  // （同一次噴發常被隔天的報導再提一次，會被誤算成連續噴發）；墨西哥等 SIGMET 沒涵蓋到的火山照舊參考 Claude
  const RANK = { ash: 0, rss: 1, claude: 2 };
  const erupt7 = [...activity.filter((r) => r.date >= daysAgo(7)
    && ((r.source === 'rss' && /Eruptive/.test(r.title)) || (r.source === 'claude' && r.eruption === true && !ashBy.has(r.vnum)))),
  ...ashRecs.filter((r) => r.date >= daysAgo(7) && r.date <= daysAgo(0))]
    .sort((a, b) => b.date.localeCompare(a.date) || RANK[a.source] - RANK[b.source]);
  const eruptOff = new Set(erupt7.filter((r) => r.source !== 'claude').map((r) => r.vnum));
  // 7 天內噴發的發布單位（詳細卡色帶的第二行）：這座火山最新一筆官方紀錄。航空火山灰警報寫飛航情報區
  // （SIGMET 由負責該區的航空氣象單位發布，資料只有區名，例如 SKED BOGOTA → Bogota），週報寫 GVP 與 USGS
  const firName = (f) => f.split('、').map((x) => x.replace(/^[A-Z]{4}\s+/, '').toLowerCase().replace(/(^|[\s-])\S/g, (c) => c.toUpperCase())).join('、');
  const offSrc = (vn) => {
    const r = erupt7.find((x) => x.vnum === vn && x.source !== 'claude');
    return !r ? '' : r.source === 'ash' ? `${firName(r.agency)} 飛航情報區` : 'Smithsonian GVP 與 USGS 週報';  // 警報種類下面的標籤已經寫了
  };
  const eruptUnv = new Set(erupt7.filter((r) => r.source === 'claude').map((r) => r.vnum));
  // 昨天噴發：昨天（UTC）有火山灰警報或發布、判定為噴發的報導。週報是一週的彙整，看不出是哪一天，不列入
  const yday = daysAgo(1);
  const ydayRecs = erupt7.filter((r) => r.source !== 'rss' && r.date === yday);
  const eruptYday = new Set(ydayRecs.map((r) => r.vnum));
  // 噴發中：從今天（今天沒有就從昨天）往回數，連續有噴發的天數（UTC）2 天以上
  const eDays = new Map();
  erupt7.filter((r) => r.source !== 'rss').forEach((r) => (eDays.get(r.vnum) || eDays.set(r.vnum, new Set()).get(r.vnum)).add(r.date));
  const runDays = (vn) => {
    const s = eDays.get(vn);
    if (!s) return 0;
    let i = s.has(daysAgo(0)) ? 0 : 1, n = 0;
    while (s.has(daysAgo(i))) { n += 1; i += 1; }
    return n;
  };
  const eruptNow = new Set([...eDays.keys()].filter((vn) => runDays(vn) >= 2));
  const actBy = new Map();
  [...activity].sort((a, b) => b.date.localeCompare(a.date)).forEach((r) => (actBy.get(r.vnum) || actBy.set(r.vnum, []).get(r.vnum)).push(r));
  const vols = V.map((v) => {
    const n = v.vnum;
    const s = eruptNow.has(n) ? 'erupt_now' : elevated.has(n) ? 'alert' : eruptYday.has(n) ? 'erupt_yday' : eruptOff.has(n) ? 'erupt_off' : eruptUnv.has(n) ? 'erupt_unv'
      : weeklySet.has(n) ? 'weekly' : claudeSet.has(n) ? 'claude' : 'none';
    const dec = DECADE[n] ? NAME[n] || DECADE[n] : '';
    return { ...v, name: NAME[n] || v.name, gvp: v.name, zh: ZH[n] || '', s, dec, pin: s !== 'none' || !!dec || HOME.has(n) };
  }).sort((a, b) => ORDER.indexOf(a.s) - ORDER.indexOf(b.s) || a.name.localeCompare(b.name));
  const byV = new Map(vols.map((v) => [v.vnum, v]));

  // ---- 本日關注火山：昨天與今天（UTC）有特別值得注意的事。一座火山放在最優先的理由那一組，其他理由當小標籤 ----
  const watch = new Map(), outlet = new Map();  // vnum → { 理由: 說明 }；vnum → 報導的媒體名稱
  const addW = (vn, k, why) => { if (byV.has(vn)) { const w = watch.get(vn) || watch.set(vn, {}).get(vn); w[k] ||= why; } };
  const AVC_RANK = { GREEN: 0, YELLOW: 1, ORANGE: 2, RED: 3 };
  // 警戒提升：各國等級的改變紀錄（update.py 記下前一級）、HANS 的變動紀錄、每日報告寫到的調升
  for (const l of levels) {
    if (l.changed_utc >= daysAgo(3) && l.level != null && l.prev_level != null && l.level > l.prev_level) {
      addW(l.vnum, 'raise', `${AGENCY[l.agency] || l.agency} 從等級 ${l.prev_level} 調高到 ${l.level}（${l.label.split('：').pop()}）`);
    }
  }
  for (const r of activity) {
    if (r.source !== 'hans' || r.date < daysAgo(3) || !r.level) continue;
    const up = !r.prev || AVC_RANK[r.level.split('/')[0]] > AVC_RANK[r.prev.split('/')[0]];
    if (up) addW(r.vnum, 'raise', `USGS ${r.prev ? `從 ${r.prev} ` : ''}調高到 ${r.level}`);
  }
  // 每日報告（V1 的 obs.json）：災害、寫到的警戒調升；新聞看發布日（pub），災害看活動日或發布日
  for (const n of obs) {
    if (n.hazards.length && (n.date >= yday || n.pub >= yday)) addW(n.vnum, 'hazard', `${n.hazards.join('、')}${n.hazard_note ? `：${n.hazard_note}` : ''}（${md(n.date)}）`);
    if (n.pub >= yday && /調高|調升|提高|提升|升至|升為|上調|raised/i.test(n.alert_change)) addW(n.vnum, 'raise', firstSentence(n.alert_change));
  }
  // 劇烈噴發：昨天與今天的火山灰警報裡最高的灰雲
  const bigAsh = new Map();
  for (const a of ash) if (a.from.slice(0, 10) >= yday && a.top_ft && a.top_ft > (bigAsh.get(a.vnum)?.top_ft || 0)) bigAsh.set(a.vnum, a);
  for (const [vn, a] of bigAsh) {
    const m = a.top_ft * 0.3048, el = byV.get(vn)?.elev, over = el != null ? m - el : null;
    if (isBigAsh(a.top_ft, el)) addW(vn, 'big', `灰雲衝到${ashM(a.top_ft)}${over != null ? `，比山頂高約 ${(over / 1000).toFixed(1)} 公里` : ''}（${md(a.from)}）`);
  }
  // 新噴發：GVP 週報的新噴發（一週內的那一期），或昨天、今天噴發而前 30 天都沒有噴發紀錄
  if (weekEnd >= daysAgo(7)) for (const r of weekly) if (/^New/.test(r.title)) addW(r.vnum, 'new', `GVP 週報列為新噴發活動（${r.period_start ? `${md(r.period_start)}～` : ''}${md(r.date)}）`);
  const erDays = new Map();
  const addD = (vn, d) => (erDays.get(vn) || erDays.set(vn, new Set()).get(vn)).add(d);
  ash30.forEach((a) => addD(a.vnum, a.from.slice(0, 10)));
  activity.forEach((r) => { if (r.eruption === true || (r.source === 'rss' && /Eruptive/.test(r.title))) addD(r.vnum, r.date); });
  for (const r of erupt7) {
    if (r.source === 'rss' || r.date < yday) continue;
    const before = [...(erDays.get(r.vnum) || [])].some((d) => d >= daysAgo(31) && d < yday);
    if (!before) addW(r.vnum, 'new', `前 30 天沒有噴發紀錄，${md(r.date)} 再度噴發`);
  }
  // 全球重大報導、媒體報導、鄰近台灣：每日報告（V1）的分區；媒體區只搜重要媒體，跟其他區可以是同一座火山
  for (const n of obs) {
    if (n.pub < yday || n.section === 'other') continue;
    const k = n.section === 'global' ? 'news' : n.section === 'media' ? 'media' : 'near';
    addW(n.vnum, k, `${firstSentence(n.summary)}${n.agency ? `（${n.agency}）` : ''}`);
    if (k === 'media' && n.agency && !outlet.has(n.vnum)) outlet.set(n.vnum, n.agency);
  }
  const stale = weekEnd ? Math.floor((T0 - Date.parse(weekEnd)) / 864e5) : 0;
  return { ash, alertBy, lvlBy, elevated, ashBy, ashRecs, weekEnd, weekly, weeklySet, claude, claudeSet, erupt7, eruptOff, eruptUnv, offSrc,
    yday, ydayRecs, eruptYday, eDays, runDays, eruptNow, actBy, vols, byV, watch, outlet, stale };
}
