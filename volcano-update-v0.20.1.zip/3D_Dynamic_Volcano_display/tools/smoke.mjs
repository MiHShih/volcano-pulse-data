// 冒煙測試（v0.19.18）：開一個暫時的本機伺服器與無頭 Chrome，打開 3D 地形版與地形貼圖版，確認畫面起得來：
// 圖釘與圖例出得來、頁首有資料時間、沒有未捕捉的程式錯誤。只讀不寫，不動 data/。需要 Node 22 以上與 Google Chrome。
//
//   node tools/smoke.mjs                       兩版各開一次
//   node tools/smoke.mjs --at=+31              把網頁的時鐘調到資料時間之後 31 小時（看頁首過期提示；-2 是時鐘慢 2 小時）
//   node tools/smoke.mjs --block=tiles         擋掉所有地形與衛星圖磚（3D 版要照常啟動，不能換到貼圖版）
//   node tools/smoke.mjs --block=net           擋掉所有外部網站，模擬離線的展示機（讀本機圖磚與安裝時附的 data/）
//   node tools/smoke.mjs --shots=<資料夾>      另外存截圖：全球視角、拉近大屯火山群
//   CHROME=<路徑> node tools/smoke.mjs         Chrome 不在 macOS 預設位置時
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const PROJ = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');
const arg = (k) => process.argv.find((a) => a.startsWith(`--${k}=`))?.split('=')[1];
const AT = arg('at'), BLOCK = arg('block'), SHOTS = arg('shots');
const CHROME = process.env.CHROME || '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'volcano-smoke-'));
const kids = [];
const quit = () => {
  for (const k of kids) try { k.kill(); } catch { /* 已經結束 */ }
  try { fs.rmSync(tmp, { recursive: true, force: true, maxRetries: 10, retryDelay: 300 }); } catch { /* Chrome 還在寫設定檔，留給系統清 */ }
};
process.on('exit', quit);

// 本機伺服器：隨機挑一個連接埠，起不來就換一個
async function server() {
  for (let i = 0; i < 5; i++) {
    const port = 20000 + Math.floor(Math.random() * 9000);
    const p = spawn('python3', ['http_server.py', String(port)], { cwd: PROJ, stdio: 'ignore' });
    kids.push(p);
    for (let j = 0; j < 20; j++) {
      await sleep(250);
      if (await fetch(`http://127.0.0.1:${port}/index.html`).then((r) => r.ok, () => false)) return port;
    }
    p.kill();
  }
  throw new Error('本機伺服器起不來');
}
// 無頭 Chrome：連接埠由 Chrome 自己挑，寫在設定檔資料夾的 DevToolsActivePort
async function chrome() {
  const p = spawn(CHROME, ['--headless=new', '--remote-debugging-port=0', `--user-data-dir=${tmp}`, '--no-first-run', '--enable-unsafe-swiftshader',
    '--window-size=1920,1080', 'about:blank'], { stdio: 'ignore' });
  kids.push(p);
  for (let i = 0; i < 40; i++) {
    await sleep(250);
    const f = path.join(tmp, 'DevToolsActivePort');
    if (fs.existsSync(f)) return +fs.readFileSync(f, 'utf8').split('\n')[0];
  }
  throw new Error('Chrome 起不來');
}

async function open(cdp, url, { preload = '', block = [] } = {}) {
  const t = await (await fetch(`http://127.0.0.1:${cdp}/json/new?about:blank`, { method: 'PUT' })).json();
  const ws = new WebSocket(t.webSocketDebuggerUrl);
  await new Promise((r, j) => { ws.addEventListener('open', r, { once: true }); ws.addEventListener('error', j, { once: true }); });
  let id = 0;
  const wait = new Map(), errs = [], logs = [];
  ws.addEventListener('message', (e) => {
    const m = JSON.parse(e.data), p = m.params || {};
    if (m.id && wait.has(m.id)) { wait.get(m.id)(m); wait.delete(m.id); return; }
    if (m.method === 'Runtime.exceptionThrown') errs.push((p.exceptionDetails?.exception?.description || p.exceptionDetails?.text || '').split('\n')[0]);
    if (m.method === 'Runtime.consoleAPICalled' && ['error', 'warning'].includes(p.type)) logs.push(`${p.type}: ${(p.args || []).map((a) => a.value ?? a.description ?? '').join(' ')}`.slice(0, 200));
  });
  const send = (method, params = {}) => new Promise((r) => { const i = ++id; wait.set(i, r); ws.send(JSON.stringify({ id: i, method, params })); });
  for (const m of ['Runtime.enable', 'Page.enable', 'Network.enable']) await send(m);
  await send('Emulation.setDeviceMetricsOverride', { width: 1920, height: 1080, deviceScaleFactor: 1, mobile: false });
  if (block.length) await send('Network.setBlockedURLs', { urls: block });
  if (preload) await send('Page.addScriptToEvaluateOnNewDocument', { source: preload });
  await send('Page.navigate', { url });
  const ev = async (expr) => {
    const r = await send('Runtime.evaluate', { expression: expr, awaitPromise: true, returnByValue: true });
    if (r.result?.exceptionDetails) throw new Error(r.result.exceptionDetails.exception?.description || r.result.exceptionDetails.text);
    return r.result?.result?.value;
  };
  const shot = async (file) => fs.writeFileSync(file, Buffer.from((await send('Page.captureScreenshot', { format: 'png' })).result.data, 'base64'));
  return { ev, shot, errs, logs, close: () => fetch(`http://127.0.0.1:${cdp}/json/close/${t.id}`).catch(() => null) };
}

const port = await server();
const cdp = await chrome();
const base = `http://127.0.0.1:${port}/`;
// --at：網頁裡的時鐘改成「資料時間 + N 小時」（資料時間取本機 data/meta.json）
let preload = '';
if (AT) {
  const t0 = Date.parse((await (await fetch(`${base}data/meta.json`)).json()).updated_utc);
  const off = t0 + Number(AT) * 36e5 - Date.now();
  preload = `(() => { const R = Date, OFF = ${off}; globalThis.Date = class extends R { constructor(...a) { if (a.length) super(...a); else super(R.now() + OFF); } static now() { return R.now() + OFF; } }; })();`;
}
const block = { tiles: ['*elevation-tiles-prod*', '*eox.at*', '*/vendor/terrain/*'],
  net: ['*amazonaws.com*', '*eox.at*', '*github*', '*youtube*', '*googleapis*', '*gstatic*', '*google.com*'] }[BLOCK] || [];
if (SHOTS) fs.mkdirSync(SHOTS, { recursive: true });

let fail = 0;
for (const page of ['index.html', 'relief.html']) {
  const tab = await open(cdp, base + page, { preload, block });
  let st = null;
  for (let i = 0; i < 90; i++) {  // 最多等 90 秒（地圖載入逾時是 60 秒）
    await sleep(1000);
    st = await tab.ev(`({ page: location.pathname.slice(1) + location.search, pins: document.querySelectorAll('.pin').length,
      legend: document.querySelectorAll('#legend > span').length, fresh: document.querySelector('#fresh')?.textContent.trim() || '',
      warn: !!document.querySelector('#fresh.warn'), msg: document.querySelector('#msg:not([hidden])')?.textContent || '',
      body: document.body.textContent.slice(0, 80) })`).catch(() => null);
    if (st && (st.pins && st.legend || st.msg || /載入失敗/.test(st.body))) break;
  }
  await sleep(3000);  // 等鏡頭停下來、圖釘位置更新
  const ok = st && st.pins > 0 && st.legend > 0 && st.fresh && !st.msg && !tab.errs.length && st.page.startsWith(page);
  if (!ok) fail += 1;
  console.log(`${ok ? '通過' : '失敗'}  ${page}${st && !st.page.startsWith(page) ? ` → 換到 ${st.page}` : ''}：圖釘 ${st?.pins ?? '?'}、圖例 ${st?.legend ?? '?'} 項、頁首「${st?.fresh ?? ''}」${st?.warn ? '（警示底色）' : ''}`
    + `${st?.msg ? `、訊息：${st.msg.slice(0, 60)}` : ''}${tab.errs.length ? `、程式錯誤：${[...new Set(tab.errs)].join('；')}` : ''}`);
  const warns = [...new Set(tab.logs)].filter((l) => !/圖磚讀不到/.test(l));
  if (warns.length) console.log(`      console：${warns.slice(0, 5).join('；')}`);
  if (SHOTS && ok) {
    const v = page.replace('.html', '');
    await tab.shot(path.join(SHOTS, `${v}-world${AT ? `-at${AT}` : ''}.png`));
    if (!AT) {
      await tab.ev(`document.querySelector('.pin[data-v="281032"]').click()`);  // 大屯火山群：拉近
      await sleep(9000);
      await tab.shot(path.join(SHOTS, `${v}-tatun-near.png`));
    }
  }
  await tab.close();
}
console.log(fail ? `${fail} 版失敗` : '兩版都通過');
process.exitCode = fail ? 1 : 0;
quit();
