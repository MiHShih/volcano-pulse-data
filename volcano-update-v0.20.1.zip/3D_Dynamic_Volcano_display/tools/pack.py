"""打包移植檔，放在專案資料夾的上一層。內容對應 docs/ 的操作手冊：

  展示機完整檔 volcano-globe-v版本.zip：展示機第一次安裝用，約 3.7 GB（含地形圖磚與 B 版近看的預算圖）。2026-11-20 起檔名帶版本，
    新版不會蓋掉舊版；之前沒帶版本的 volcano-globe.zip 是 v0.19.18（0.19 的最後一版）
  資料機完整檔 volcano-station-v版本-web網頁版本.zip（--station，2026-11-23 起）：資料機用，約 3.7 GB。展示機完整檔加上網頁版 web/（原始檔、組好的 web/site/、
    YouTube 影片清單 videos.json，跟 data/media.json 一樣最多存 30 天），再加一個空的 versions/（程式靠它認出資料站，舊版快照不帶）。
    檔名帶兩個版本號，網頁版單獨更新時不會蓋掉舊檔
  更新包 volcano-update-v版本.zip：已經裝過完整檔的電腦換新版用，約 15 MB（不含 vendor/terrain/ 與 vendor/patches/）
    --update --patches：預算圖有變時（例如 v0.17.0 第一次加入、畫法改版、來源更新）連 vendor/patches/ 一起帶，約 0.4 GB

每一種的最上層都是啟動腳本（Pi 的 start-volcano.sh、Windows 的 start-volcano.bat、Mac 的 start-volcano.command，
加上 Windows 與 Mac 的視窗版 start-volcano-window）
與 3D_Dynamic_Volcano_display/，在同一個資料夾解壓縮（更新包直接覆蓋）就好。
用 Python 的 zipfile 打包：中文檔名會標成 UTF-8，Windows 解壓縮才不會變亂碼（macOS 內建的 zip 不會標）。
排除 Python 快取與虛擬環境 .venv、.DS_Store、算到一半的暫存檔、版本快照 versions/，以及介紹簡報（*.pptx 與 docs/src/deck-img/）、
只給私有資料庫用的 data/ash_raw.json 與 data/ash_rejected.json。2026-11-19 起都另外排除 Claude Code 的工作資料夾 .claude/
（可能有本機的權限設定）與專案最上層的工作筆記（檔名以日期開頭的 日期_*，以及 *.yaml；跟 tools/release.py 去掉的一樣，
交接檔寫了內部事項，不該跟著安裝檔到展示機上；docs/ 裡的手冊不受影響）。2026-11-20 起展示機完整檔與更新包也排除網頁版 web/（只放資料站）。
先寫成暫存檔，檢查通過才取代舊檔。
更新包另外排除每台自己的檔案：config.json（手動覆蓋會清掉該台的 auto_update 與 bundle_url 設定）、publish.json、data/*.log；
完整檔照舊帶 config.json（第一次安裝要靠它知道資料包網址）。

執行：sh tools/pack.sh（展示機完整檔）、sh tools/pack.sh --station（資料機完整檔）、sh tools/pack.sh --update（更新包）、sh tools/pack.sh --update --patches
"""
import os
import re
import sys
import zipfile
from pathlib import Path

PROJ = Path(__file__).resolve().parents[1]
NAME = PROJ.name
LAUNCHERS = ('pi/start-volcano.sh', 'win/start-volcano.bat', 'mac/start-volcano.command',
             'win/start-volcano-window.bat', 'mac/start-volcano-window.command')  # 後兩支是視窗版（v0.19.16）


def files(update, patches, station=False):
    for root, dirs, names in os.walk(PROJ):
        rel = Path(root).relative_to(PROJ)
        dirs[:] = sorted(d for d in dirs if d not in ('__pycache__', '.venv', '.update', '.claude') and not (rel == Path('.') and (d == 'versions' or (d == 'web' and not station)))
                         and not (rel == Path('docs/src') and d == 'deck-img')  # 介紹簡報的截圖，展示機用不到
                         and not (update and rel == Path('vendor') and (d == 'terrain' or (d == 'patches' and not patches))))
        for n in sorted(names):
            r = (rel / n).as_posix()
            if n == '.DS_Store' or n.endswith(('.zip.new', '.tmp', '.pptx')) or r in ('data/ash_raw.json', 'data/ash_rejected.json'):
                continue
            if rel == Path('.') and (re.fullmatch(r'\d{4}-\d{2}-\d{2}_.+', n) or n.endswith('.yaml')):
                continue  # 最上層的工作筆記（交接檔、prompt、來源清單），2026-11-19 起不打包
            if update and (r in ('config.json', 'publish.json') or (rel == Path('data') and n.endswith('.log'))):
                continue
            yield Path(root) / n


def main(argv):
    update, patches, station = '--update' in argv, '--patches' in argv, '--station' in argv
    if update and station:
        sys.exit('--station 是資料機的完整檔，不能跟 --update 一起用')
    ver = re.search(r"^const VERSION = '(.+)';", (PROJ / 'app.js').read_text('utf-8'), re.M).group(1)
    if station:  # 網頁版自己有版本號，單獨更新時檔名要不同，才不會蓋掉舊檔
        web = re.search(r"^const WEB_VERSION = '(.+)';", (PROJ / 'web' / 'web.js').read_text('utf-8'), re.M).group(1)
        out = PROJ.parent / f'volcano-station-v{ver}-web{web}.zip'
    else:
        out = PROJ.parent / (f'volcano-update-v{ver}.zip' if update else f'volcano-globe-v{ver}.zip')
    tmp = out.with_name(out.name + '.new')
    for s in LAUNCHERS:
        os.chmod(PROJ / s, 0o755)  # 解壓縮後可以直接執行
    # 完整檔大多是地形 PNG，壓縮也不會變小，只打包比較快
    with zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED if update else zipfile.ZIP_STORED) as z:
        n = 0
        for p in files(update, patches, station):
            z.write(p, f'{NAME}/{p.relative_to(PROJ).as_posix()}')
            n += 1
        for s in LAUNCHERS:
            z.write(PROJ / s, Path(s).name)
        if station:
            z.writestr(f'{NAME}/versions/', '')  # 空資料夾：http_server.py 與 app.js 靠它認資料站，舊版快照不帶
    with zipfile.ZipFile(tmp) as z:
        bad = z.testzip()
        names = z.namelist()
        utf8 = all(i.flag_bits & 0x800 for i in z.infolist() if not i.filename.isascii())
    terrain = any('/vendor/terrain/' in x for x in names)
    has_web, mark = f'{NAME}/web/site/index.html' in names, f'{NAME}/versions/' in names
    ok = (bad is None and utf8 and all(Path(s).name in names for s in LAUNCHERS) and terrain != update
          and f'{NAME}/http_server.py' in names and has_web == mark == station)  # http_server.py 是啟動腳本要用的
    if not ok:
        tmp.unlink()
        sys.exit(f'檢查不通過，保留舊檔：損壞 {bad}、UTF-8 檔名 {utf8}、地形圖磚 {terrain}、網頁版 {has_web}、資料站標記 {mark}')
    os.replace(tmp, out)
    print(f'{out}：v{ver}，{n:,} 個檔案加 {len(LAUNCHERS)} 支啟動腳本，{out.stat().st_size / 1e6:,.0f} MB')
    if out.stat().st_size >= 2 ** 32:
        print('注意：超過 FAT32 的單檔上限 4 GB，隨身碟要格式化成 exFAT')


if __name__ == '__main__':
    main(sys.argv[1:])
