// status.js 的測試（v0.19.18）：狀態只看資料時間，展示機的時鐘換日、停更、慢了都不影響。用合成的小資料，不連網路。
// 執行：node --test tools/test_status.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import { computeStatus, cleanRows, baseTime, daysFrom, firstSentence, HOME } from '../status.js';

const H = 36e5;
const UPDATED = '2026-11-19T01:00:00Z';  // 資料包的時間：每天 01:00 UTC（台灣 09:00）發布
const vol = (vnum, name) => ({ vnum, name, country: 'Testland', lat: 0, lon: 0, elev: 1000 });
const V = [vol(1, 'Alpha'), vol(2, 'Beta'), vol(3, 'Gamma'), vol(4, 'Delta'), vol(5, 'Epsilon'), vol(HOME.values().next().value, 'Tatun')];
// 一則火山灰警報：生效時間 from，當天 03:00 UTC 到期
const sig = (vnum, day, top_ft = 10000) => ({ id: `TEST:${vnum}:${day}`, vnum, from: `${day}T01:00:00Z`, to: `${day}T03:00:00Z`, fir: 'TEST FIR', top_ft });
const DATA = {
  V, alerts: [{ vnum: 4, sent_utc: '2026-11-18T20:00:00Z', color_code: 'ORANGE' }], activity: [], levels: [], obs: [],
  meta: { updated_utc: UPDATED, rss: {} },
  ash30: [
    sig(1, '2026-11-17'), sig(1, '2026-11-18'),  // Alpha：連續 2 天 → 噴發中
    sig(2, '2026-11-18', 40000),                 // Beta：只有昨天，灰雲 12 公里 → 昨天噴發、劇烈噴發、新噴發
    sig(3, '2026-11-14'),                        // Gamma：5 天前 → 7 天內噴發
    sig(5, '2026-11-09'),                        // Epsilon：10 天前，超過 7 天 → 近期無活動
  ],
};
const NAMES = { NAME: {}, ZH: {}, DECADE: {} };

// 把 Date 換成固定在 t 的版本（Date.now 與不帶參數的 new Date）
function atClock(t, fn) {
  const Real = Date;
  globalThis.Date = class extends Real {
    constructor(...a) { if (a.length) super(...a); else super(t); }
    static now() { return t; }
  };
  try { return fn(); } finally { globalThis.Date = Real; }
}
const statusAt = (clock, data = DATA) => atClock(clock, () => computeStatus(data, baseTime(data.meta), NAMES));
const s = (r, vnum) => r.byV.get(vnum).s;

test('狀態判定：噴發中、昨天噴發、7 天內噴發、警戒升高、近期無活動', () => {
  const r = statusAt(Date.parse(UPDATED));
  assert.equal(s(r, 1), 'erupt_now');
  assert.equal(r.runDays(1), 2);
  assert.equal(s(r, 2), 'erupt_yday');
  assert.equal(s(r, 3), 'erupt_off');
  assert.equal(s(r, 4), 'alert');
  assert.equal(s(r, 5), 'none');
  assert.equal(r.yday, '2026-11-18');
});

test('時鐘：UTC 換日後、資料停更 5 天、時鐘慢 3 小時，結果都跟資料時間當下一樣', () => {
  const T = Date.parse(UPDATED);
  const pick = (r) => JSON.stringify(r.vols.map((v) => [v.vnum, v.s]).concat([[...r.watch]]));
  const base = pick(statusAt(T));
  for (const [label, dt] of [['換日後 23.5 小時', 23.5 * H], ['停更 5 天', 120 * H], ['時鐘慢 3 小時', -3 * H]]) {
    assert.equal(pick(statusAt(T + dt)), base, label);
  }
});

test('本日關注：劇烈噴發與新噴發', () => {
  const w = statusAt(Date.parse(UPDATED)).watch;
  assert.ok(w.get(2)?.big, '灰雲 12 公里算劇烈噴發');
  assert.ok(w.get(2)?.new, '前 30 天沒噴發算新噴發');
  assert.ok(!w.has(1) || !w.get(1).new, '前一天也有噴發就不算新噴發');
});

test('大屯火山群一直有圖釘', () => {
  const r = statusAt(Date.parse(UPDATED));
  const home = r.vols.find((v) => HOME.has(v.vnum));
  assert.equal(home.s, 'none');
  assert.equal(home.pin, true);
});

test('cleanRows：缺欄位或沒有整數火山編號的列丟掉', () => {
  const rows = [sig(1, '2026-11-18'), { vnum: 2, from: '2026-11-18T01:00:00Z' }, { ...sig(3, '2026-11-18'), vnum: '3' }, null];
  const c = cleanRows('ash', rows);
  assert.equal(c.rows.length, 1);
  assert.equal(c.dropped, 3);
  assert.deepEqual(cleanRows('obs', 'not an array'), { rows: [], dropped: 0 });
  assert.equal(cleanRows('volcanoes', [vol(1, 'A'), { ...vol(2, 'B'), lat: null }]).dropped, 1);
});

test('baseTime：用資料時間；沒有資料時間才用這台電腦的時鐘', () => {
  assert.equal(baseTime({ updated_utc: UPDATED }), Date.parse(UPDATED));
  assert.equal(atClock(123456789, () => baseTime({})), 123456789);
  assert.equal(atClock(123456789, () => baseTime({ updated_utc: 'bad' })), 123456789);
});

test('daysFrom 與 firstSentence', () => {
  const d = daysFrom(Date.parse(UPDATED));
  assert.equal(d(0), '2026-11-19');
  assert.equal(d(1), '2026-11-18');
  assert.equal(d(30), '2026-10-20');
  assert.equal(firstSentence('第一句。第二句。'), '第一句。');
  assert.equal(firstSentence('長'.repeat(80)).length, 69);
});
