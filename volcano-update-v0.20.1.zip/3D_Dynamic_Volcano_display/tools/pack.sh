#!/bin/sh
# 打包移植檔（放在專案資料夾的上一層），細節見 tools/pack.py：
#   sh tools/pack.sh                      展示機完整檔 volcano-globe-v版本.zip（約 3.7 GB，第一次安裝用；2026-11-20 起檔名帶版本）
#   sh tools/pack.sh --station            資料機完整檔 volcano-station-v版本-web網頁版本.zip（展示機完整檔加網頁版 web/ 與空的 versions/）
#   sh tools/pack.sh --update             更新包 volcano-update-v版本.zip（約 15 MB，不含地形圖磚與預算圖，覆蓋已安裝的電腦）
#   sh tools/pack.sh --update --patches   預算圖有變時用，連 vendor/patches/ 一起帶（約 0.4 GB）
exec python3 "$(dirname "$0")/pack.py" "$@"
