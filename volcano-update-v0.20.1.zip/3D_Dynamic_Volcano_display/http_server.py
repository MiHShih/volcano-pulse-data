"""展示端的本機網頁伺服器：跟 python3 -m http.server 一樣，只多告訴瀏覽器網頁、程式與資料檔每次都要檢查有沒有新版。

原本的 http.server 沒有快取規則，Chrome 會自己估一段時間直接用快取（沒改過越久的檔案估得越久），
套用更新包後可能新的 app.js 配舊的 map-terrain.js。加上 Cache-Control: no-cache 後瀏覽器每次都問一次，
檔案沒變時伺服器只回 304，幾乎不花時間；地形圖磚與圖片照舊交給瀏覽器快取。
檔名用 http_server：操作手冊裡關伺服器的 pkill -f http.server 照樣比對得到。

執行：python3 http_server.py（預設 127.0.0.1:8000，可以加連接埠，例如 python3 http_server.py 8080）
視窗版的「離開」按鈕會送 POST /quit 關掉伺服器（v0.19.16）。
開著的時候每天早上 8 點（這台電腦的時間）在背景跑一次 updater.py（v0.20.0）：開機時啟動腳本已經跑過，這裡補一直開著不關的機器。
資料站（專案資料夾裡有 versions/，安裝檔與更新包都不帶）不跑，只有展示機跑。
"""
import http.server
import subprocess
import sys
import threading
import time
from functools import partial
from pathlib import Path

FRESH = ('/', '.html', '.js', '.mjs', '.css', '.json')
RUN_AT = 8  # 每天幾點檢查新版（這台電腦的時間）
TICK = 60   # 幾秒看一次時鐘


class Handler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        if self.path.split('?', 1)[0].endswith(FRESH):
            self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def do_POST(self):
        """視窗版的「離開」按鈕（v0.19.16）：關掉伺服器。只接受這個網頁送來的（看 Origin），別的網站送來的不理。"""
        port = self.server.server_address[1]
        if self.path != '/quit' or self.headers.get('Origin') not in (f'http://localhost:{port}', f'http://127.0.0.1:{port}'):
            return self.send_error(403)
        self.send_response(204)
        self.end_headers()
        threading.Thread(target=self.server.shutdown).start()  # 在別的執行緒呼叫，serve_forever 才停得下來


def daily_update(root, clock=time.localtime):
    """每天早上 8 點跑一次 updater.py：有新的穩定版就下載、核對、套用，網頁發現 app.js 的版本號變了會自己重新載入。
    每分鐘看一次時鐘，不用長時間 sleep：電腦睡著或調過時間也不會錯過，8 點時睡著或關機的話，醒來或開機後當天補跑一次。
    伺服器啟動時已經過了 8 點，一分鐘後就先跑一次：開機那時剛好沒網路也補得到，已是最新的話只是多問一次。
    用子程序跑磁碟上最新的 updater.py（這支伺服器自己的程式要重新啟動才會換）；失敗或超過 20 分鐘都不影響伺服器。
    資料站與同步的開發用資料夾（有 versions/）直接結束：程式在那裡修改、從那裡發佈，不從網路更新"""
    if (root / 'versions').is_dir():
        return
    day = lambda t: time.strftime('%Y-%m-%d', t)  # noqa: E731
    last = ''
    while True:
        time.sleep(TICK)
        t = clock()
        if t.tm_hour >= RUN_AT and day(t) != last:
            last = day(t)
            try:
                subprocess.run([sys.executable, 'updater.py'], cwd=str(root), timeout=1200,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            except Exception:
                pass


if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    root = Path(__file__).resolve().parent
    print(f'火山脈動：http://localhost:{port}/（{root}）', flush=True)
    threading.Thread(target=daily_update, args=(root,), daemon=True).start()
    http.server.ThreadingHTTPServer(('127.0.0.1', port), partial(Handler, directory=str(root))).serve_forever()
